-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 16, 2019 at 01:26 AM
-- Server version: 5.7.23
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `KWAfood`
--

-- --------------------------------------------------------

--
-- Table structure for table `kwa_commentmeta`
--

CREATE TABLE `kwa_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `kwa_commentmeta`
--

INSERT INTO `kwa_commentmeta` (`meta_id`, `comment_id`, `meta_key`, `meta_value`) VALUES
(1, 1, '_wp_trash_meta_status', '1'),
(2, 1, '_wp_trash_meta_time', '1554683170');

-- --------------------------------------------------------

--
-- Table structure for table `kwa_comments`
--

CREATE TABLE `kwa_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `kwa_comments`
--

INSERT INTO `kwa_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Un Comentarista de WordPress', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2019-03-25 20:42:34', '2019-03-25 23:42:34', 'Hola, este es un comentario.\nPara empezar con la moderación, edición y eliminación de comentarios, por favor visita la pantalla de comentarios en el panel inicial.\nLos Avatares de los comentaristas provienen de <a href=\"https://gravatar.com\">Gravatar</a>.', 0, 'trash', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `kwa_links`
--

CREATE TABLE `kwa_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `kwa_ngg_album`
--

CREATE TABLE `kwa_ngg_album` (
  `id` bigint(20) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `previewpic` bigint(20) NOT NULL DEFAULT '0',
  `albumdesc` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `sortorder` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pageid` bigint(20) NOT NULL DEFAULT '0',
  `extras_post_id` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `kwa_ngg_gallery`
--

CREATE TABLE `kwa_ngg_gallery` (
  `gid` bigint(20) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `path` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `title` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `galdesc` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `pageid` bigint(20) NOT NULL DEFAULT '0',
  `previewpic` bigint(20) NOT NULL DEFAULT '0',
  `author` bigint(20) NOT NULL DEFAULT '0',
  `extras_post_id` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `kwa_ngg_gallery`
--

INSERT INTO `kwa_ngg_gallery` (`gid`, `name`, `slug`, `path`, `title`, `galdesc`, `pageid`, `previewpic`, `author`, `extras_post_id`) VALUES
(1, 'galeria', 'Galeria', 'wp-content/gallery/galeria/', 'Galeria', '', 0, 1, 1, 129);

-- --------------------------------------------------------

--
-- Table structure for table `kwa_ngg_pictures`
--

CREATE TABLE `kwa_ngg_pictures` (
  `pid` bigint(20) NOT NULL,
  `image_slug` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_id` bigint(20) NOT NULL DEFAULT '0',
  `galleryid` bigint(20) NOT NULL DEFAULT '0',
  `filename` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `description` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `alttext` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `imagedate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `exclude` tinyint(4) DEFAULT '0',
  `sortorder` bigint(20) NOT NULL DEFAULT '0',
  `meta_data` longtext COLLATE utf8mb4_unicode_520_ci,
  `extras_post_id` bigint(20) NOT NULL DEFAULT '0',
  `updated_at` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `kwa_ngg_pictures`
--

INSERT INTO `kwa_ngg_pictures` (`pid`, `image_slug`, `post_id`, `galleryid`, `filename`, `description`, `alttext`, `imagedate`, `exclude`, `sortorder`, `meta_data`, `extras_post_id`, `updated_at`) VALUES
(1, 'captura-de-pantalla-2019-04-13-a-las-21-35-47-2', 0, 1, 'Captura-de-pantalla-2019-04-13-a-las-21.35.47.png', '', 'Clientes felices', '2019-04-14 01:37:03', 0, 0, 'eyJhcGVydHVyZSI6ZmFsc2UsImNyZWRpdCI6ZmFsc2UsImNhbWVyYSI6ZmFsc2UsImNhcHRpb24iOmZhbHNlLCJjcmVhdGVkX3RpbWVzdGFtcCI6ZmFsc2UsImNvcHlyaWdodCI6ZmFsc2UsImZvY2FsX2xlbmd0aCI6ZmFsc2UsImlzbyI6ZmFsc2UsInNodXR0ZXJfc3BlZWQiOmZhbHNlLCJmbGFzaCI6ZmFsc2UsInRpdGxlIjpmYWxzZSwia2V5d29yZHMiOmZhbHNlLCJ3aWR0aCI6NTc2LCJoZWlnaHQiOjU2NCwic2F2ZWQiOnRydWUsImJhY2t1cCI6eyJmaWxlbmFtZSI6IkNhcHR1cmEtZGUtcGFudGFsbGEtMjAxOS0wNC0xMy1hLWxhcy0yMS4zNS40Ny5wbmciLCJ3aWR0aCI6NTc2LCJoZWlnaHQiOjU2NCwiZ2VuZXJhdGVkIjoiMC42MjMxMjMwMCAxNTU1MjA1ODIzIn0sIm1kNSI6IjU1NmY0YzliMDBjMmZhZDJlNzc5ZmM4YzY4YWZiZTY0IiwiZnVsbCI6eyJ3aWR0aCI6NTc2LCJoZWlnaHQiOjU2NCwibWQ1IjoiNTU2ZjRjOWIwMGMyZmFkMmU3NzlmYzhjNjhhZmJlNjQifSwidGh1bWJuYWlsIjp7IndpZHRoIjoyNDAsImhlaWdodCI6MTYwLCJmaWxlbmFtZSI6InRodW1ic19DYXB0dXJhLWRlLXBhbnRhbGxhLTIwMTktMDQtMTMtYS1sYXMtMjEuMzUuNDcucG5nIiwiZ2VuZXJhdGVkIjoiMC4wNDcwODcwMCAxNTU1MjA1ODI0In19', 130, 1555265848),
(2, 'captura-de-pantalla-2019-04-13-a-las-21-35-52-2', 0, 1, 'Captura-de-pantalla-2019-04-13-a-las-21.35.52.png', '', 'Clientes felices', '2019-04-14 01:37:04', 0, 0, 'eyJhcGVydHVyZSI6ZmFsc2UsImNyZWRpdCI6ZmFsc2UsImNhbWVyYSI6ZmFsc2UsImNhcHRpb24iOmZhbHNlLCJjcmVhdGVkX3RpbWVzdGFtcCI6ZmFsc2UsImNvcHlyaWdodCI6ZmFsc2UsImZvY2FsX2xlbmd0aCI6ZmFsc2UsImlzbyI6ZmFsc2UsInNodXR0ZXJfc3BlZWQiOmZhbHNlLCJmbGFzaCI6ZmFsc2UsInRpdGxlIjpmYWxzZSwia2V5d29yZHMiOmZhbHNlLCJ3aWR0aCI6NTY4LCJoZWlnaHQiOjU1Niwic2F2ZWQiOnRydWUsImJhY2t1cCI6eyJmaWxlbmFtZSI6IkNhcHR1cmEtZGUtcGFudGFsbGEtMjAxOS0wNC0xMy1hLWxhcy0yMS4zNS41Mi5wbmciLCJ3aWR0aCI6NTY4LCJoZWlnaHQiOjU1NiwiZ2VuZXJhdGVkIjoiMC41NjYwOTAwMCAxNTU1MjA1ODI0In0sIm1kNSI6Ijc4MmY5YTNjZWUzMTVlNzFmYWVlM2M3ODVmMDJhYjI4IiwiZnVsbCI6eyJ3aWR0aCI6NTY4LCJoZWlnaHQiOjU1NiwibWQ1IjoiNzgyZjlhM2NlZTMxNWU3MWZhZWUzYzc4NWYwMmFiMjgifSwidGh1bWJuYWlsIjp7IndpZHRoIjoyNDAsImhlaWdodCI6MTYwLCJmaWxlbmFtZSI6InRodW1ic19DYXB0dXJhLWRlLXBhbnRhbGxhLTIwMTktMDQtMTMtYS1sYXMtMjEuMzUuNTIucG5nIiwiZ2VuZXJhdGVkIjoiMC4yMTA2NzMwMCAxNTU1MjA1ODI1In19', 131, 1555265848),
(3, 'captura-de-pantalla-2019-04-13-a-las-21-36-00-2', 0, 1, 'Captura-de-pantalla-2019-04-13-a-las-21.36.00.png', '', 'Sopa de costillas', '2019-04-14 01:37:05', 0, 0, 'eyJhcGVydHVyZSI6ZmFsc2UsImNyZWRpdCI6ZmFsc2UsImNhbWVyYSI6ZmFsc2UsImNhcHRpb24iOmZhbHNlLCJjcmVhdGVkX3RpbWVzdGFtcCI6ZmFsc2UsImNvcHlyaWdodCI6ZmFsc2UsImZvY2FsX2xlbmd0aCI6ZmFsc2UsImlzbyI6ZmFsc2UsInNodXR0ZXJfc3BlZWQiOmZhbHNlLCJmbGFzaCI6ZmFsc2UsInRpdGxlIjpmYWxzZSwia2V5d29yZHMiOmZhbHNlLCJ3aWR0aCI6NTY0LCJoZWlnaHQiOjU1OCwic2F2ZWQiOnRydWUsImJhY2t1cCI6eyJmaWxlbmFtZSI6IkNhcHR1cmEtZGUtcGFudGFsbGEtMjAxOS0wNC0xMy1hLWxhcy0yMS4zNi4wMC5wbmciLCJ3aWR0aCI6NTY0LCJoZWlnaHQiOjU1OCwiZ2VuZXJhdGVkIjoiMC44NTI1MDYwMCAxNTU1MjA1ODI1In0sIm1kNSI6ImIyM2E3N2RmNTUyNGMwYjZlOTIxMDYzNzAxYmJiNGUxIiwiZnVsbCI6eyJ3aWR0aCI6NTY0LCJoZWlnaHQiOjU1OCwibWQ1IjoiYjIzYTc3ZGY1NTI0YzBiNmU5MjEwNjM3MDFiYmI0ZTEifSwidGh1bWJuYWlsIjp7IndpZHRoIjoyNDAsImhlaWdodCI6MTYwLCJmaWxlbmFtZSI6InRodW1ic19DYXB0dXJhLWRlLXBhbnRhbGxhLTIwMTktMDQtMTMtYS1sYXMtMjEuMzYuMDAucG5nIiwiZ2VuZXJhdGVkIjoiMC4zMTg3NDkwMCAxNTU1MjA1ODI2In19', 132, 1555265848),
(4, 'captura-de-pantalla-2019-04-13-a-las-21-36-04-2', 0, 1, 'Captura-de-pantalla-2019-04-13-a-las-21.36.04.png', '', 'Clientes felices', '2019-04-14 01:37:06', 0, 0, 'eyJhcGVydHVyZSI6ZmFsc2UsImNyZWRpdCI6ZmFsc2UsImNhbWVyYSI6ZmFsc2UsImNhcHRpb24iOmZhbHNlLCJjcmVhdGVkX3RpbWVzdGFtcCI6ZmFsc2UsImNvcHlyaWdodCI6ZmFsc2UsImZvY2FsX2xlbmd0aCI6ZmFsc2UsImlzbyI6ZmFsc2UsInNodXR0ZXJfc3BlZWQiOmZhbHNlLCJmbGFzaCI6ZmFsc2UsInRpdGxlIjpmYWxzZSwia2V5d29yZHMiOmZhbHNlLCJ3aWR0aCI6NTcyLCJoZWlnaHQiOjU2Niwic2F2ZWQiOnRydWUsImJhY2t1cCI6eyJmaWxlbmFtZSI6IkNhcHR1cmEtZGUtcGFudGFsbGEtMjAxOS0wNC0xMy1hLWxhcy0yMS4zNi4wNC5wbmciLCJ3aWR0aCI6NTcyLCJoZWlnaHQiOjU2NiwiZ2VuZXJhdGVkIjoiMC44MDQzNTIwMCAxNTU1MjA1ODI2In0sIm1kNSI6IjYwODZlYmQ2Yzg0MDk0ZjAyYzk1NTk1YzJkODAzOThiIiwiZnVsbCI6eyJ3aWR0aCI6NTcyLCJoZWlnaHQiOjU2NiwibWQ1IjoiNjA4NmViZDZjODQwOTRmMDJjOTU1OTVjMmQ4MDM5OGIifSwidGh1bWJuYWlsIjp7IndpZHRoIjoyNDAsImhlaWdodCI6MTYwLCJmaWxlbmFtZSI6InRodW1ic19DYXB0dXJhLWRlLXBhbnRhbGxhLTIwMTktMDQtMTMtYS1sYXMtMjEuMzYuMDQucG5nIiwiZ2VuZXJhdGVkIjoiMC4yNjkwMzgwMCAxNTU1MjA1ODI3In19', 133, 1555265848),
(5, 'captura-de-pantalla-2019-04-13-a-las-21-36-09-2', 0, 1, 'Captura-de-pantalla-2019-04-13-a-las-21.36.09.png', '', 'Clientes felices', '2019-04-14 01:37:07', 0, 0, 'eyJhcGVydHVyZSI6ZmFsc2UsImNyZWRpdCI6ZmFsc2UsImNhbWVyYSI6ZmFsc2UsImNhcHRpb24iOmZhbHNlLCJjcmVhdGVkX3RpbWVzdGFtcCI6ZmFsc2UsImNvcHlyaWdodCI6ZmFsc2UsImZvY2FsX2xlbmd0aCI6ZmFsc2UsImlzbyI6ZmFsc2UsInNodXR0ZXJfc3BlZWQiOmZhbHNlLCJmbGFzaCI6ZmFsc2UsInRpdGxlIjpmYWxzZSwia2V5d29yZHMiOmZhbHNlLCJ3aWR0aCI6NTgyLCJoZWlnaHQiOjU4OCwic2F2ZWQiOnRydWUsImJhY2t1cCI6eyJmaWxlbmFtZSI6IkNhcHR1cmEtZGUtcGFudGFsbGEtMjAxOS0wNC0xMy1hLWxhcy0yMS4zNi4wOS5wbmciLCJ3aWR0aCI6NTgyLCJoZWlnaHQiOjU4OCwiZ2VuZXJhdGVkIjoiMC44MzQ1NDkwMCAxNTU1MjA1ODI3In0sIm1kNSI6ImNiYjIzZjRmMzk0YTczN2Y3NWU1MTZkOGEwZjdlMjZiIiwiZnVsbCI6eyJ3aWR0aCI6NTgyLCJoZWlnaHQiOjU4OCwibWQ1IjoiY2JiMjNmNGYzOTRhNzM3Zjc1ZTUxNmQ4YTBmN2UyNmIifSwidGh1bWJuYWlsIjp7IndpZHRoIjoyNDAsImhlaWdodCI6MTYwLCJmaWxlbmFtZSI6InRodW1ic19DYXB0dXJhLWRlLXBhbnRhbGxhLTIwMTktMDQtMTMtYS1sYXMtMjEuMzYuMDkucG5nIiwiZ2VuZXJhdGVkIjoiMC4zMTg5NjkwMCAxNTU1MjA1ODI4In19', 134, 1555265848),
(6, 'captura-de-pantalla-2019-04-13-a-las-21-36-15-2', 0, 1, 'Captura-de-pantalla-2019-04-13-a-las-21.36.15.png', '', 'empanadas listas', '2019-04-14 01:37:08', 0, 0, 'eyJhcGVydHVyZSI6ZmFsc2UsImNyZWRpdCI6ZmFsc2UsImNhbWVyYSI6ZmFsc2UsImNhcHRpb24iOmZhbHNlLCJjcmVhdGVkX3RpbWVzdGFtcCI6ZmFsc2UsImNvcHlyaWdodCI6ZmFsc2UsImZvY2FsX2xlbmd0aCI6ZmFsc2UsImlzbyI6ZmFsc2UsInNodXR0ZXJfc3BlZWQiOmZhbHNlLCJmbGFzaCI6ZmFsc2UsInRpdGxlIjpmYWxzZSwia2V5d29yZHMiOmZhbHNlLCJ3aWR0aCI6NTcwLCJoZWlnaHQiOjU4MCwic2F2ZWQiOnRydWUsImJhY2t1cCI6eyJmaWxlbmFtZSI6IkNhcHR1cmEtZGUtcGFudGFsbGEtMjAxOS0wNC0xMy1hLWxhcy0yMS4zNi4xNS5wbmciLCJ3aWR0aCI6NTcwLCJoZWlnaHQiOjU4MCwiZ2VuZXJhdGVkIjoiMC43OTcwMTQwMCAxNTU1MjA1ODI4In0sIm1kNSI6IjI4MjQ2MjUyN2Q3MjY4Zjk2ZTRmNDlkMDc3NWM4MTBjIiwiZnVsbCI6eyJ3aWR0aCI6NTcwLCJoZWlnaHQiOjU4MCwibWQ1IjoiMjgyNDYyNTI3ZDcyNjhmOTZlNGY0OWQwNzc1YzgxMGMifSwidGh1bWJuYWlsIjp7IndpZHRoIjoyNDAsImhlaWdodCI6MTYwLCJmaWxlbmFtZSI6InRodW1ic19DYXB0dXJhLWRlLXBhbnRhbGxhLTIwMTktMDQtMTMtYS1sYXMtMjEuMzYuMTUucG5nIiwiZ2VuZXJhdGVkIjoiMC4yMTI5NTkwMCAxNTU1MjA1ODI5In19', 135, 1555265848),
(7, 'captura-de-pantalla-2019-04-13-a-las-21-36-20-2', 0, 1, 'Captura-de-pantalla-2019-04-13-a-las-21.36.20.png', '', 'Clientes felices', '2019-04-14 01:37:09', 0, 0, 'eyJhcGVydHVyZSI6ZmFsc2UsImNyZWRpdCI6ZmFsc2UsImNhbWVyYSI6ZmFsc2UsImNhcHRpb24iOmZhbHNlLCJjcmVhdGVkX3RpbWVzdGFtcCI6ZmFsc2UsImNvcHlyaWdodCI6ZmFsc2UsImZvY2FsX2xlbmd0aCI6ZmFsc2UsImlzbyI6ZmFsc2UsInNodXR0ZXJfc3BlZWQiOmZhbHNlLCJmbGFzaCI6ZmFsc2UsInRpdGxlIjpmYWxzZSwia2V5d29yZHMiOmZhbHNlLCJ3aWR0aCI6NTgwLCJoZWlnaHQiOjU3Miwic2F2ZWQiOnRydWUsImJhY2t1cCI6eyJmaWxlbmFtZSI6IkNhcHR1cmEtZGUtcGFudGFsbGEtMjAxOS0wNC0xMy1hLWxhcy0yMS4zNi4yMC5wbmciLCJ3aWR0aCI6NTgwLCJoZWlnaHQiOjU3MiwiZ2VuZXJhdGVkIjoiMC43MzAyMjEwMCAxNTU1MjA1ODI5In0sIm1kNSI6IjY4OTIxY2JkYTBkMDNhN2QwZmY4MGEyMjU5YjZjMzc2IiwiZnVsbCI6eyJ3aWR0aCI6NTgwLCJoZWlnaHQiOjU3MiwibWQ1IjoiNjg5MjFjYmRhMGQwM2E3ZDBmZjgwYTIyNTliNmMzNzYifSwidGh1bWJuYWlsIjp7IndpZHRoIjoyNDAsImhlaWdodCI6MTYwLCJmaWxlbmFtZSI6InRodW1ic19DYXB0dXJhLWRlLXBhbnRhbGxhLTIwMTktMDQtMTMtYS1sYXMtMjEuMzYuMjAucG5nIiwiZ2VuZXJhdGVkIjoiMC4wNzIzOTIwMCAxNTU1MjA1ODMwIn19', 136, 1555265848),
(8, 'captura-de-pantalla-2019-04-13-a-las-21-36-29-2', 0, 1, 'Captura-de-pantalla-2019-04-13-a-las-21.36.29.png', '', 'empanada con salsa de ajo', '2019-04-14 01:37:10', 0, 0, 'eyJhcGVydHVyZSI6ZmFsc2UsImNyZWRpdCI6ZmFsc2UsImNhbWVyYSI6ZmFsc2UsImNhcHRpb24iOmZhbHNlLCJjcmVhdGVkX3RpbWVzdGFtcCI6ZmFsc2UsImNvcHlyaWdodCI6ZmFsc2UsImZvY2FsX2xlbmd0aCI6ZmFsc2UsImlzbyI6ZmFsc2UsInNodXR0ZXJfc3BlZWQiOmZhbHNlLCJmbGFzaCI6ZmFsc2UsInRpdGxlIjpmYWxzZSwia2V5d29yZHMiOmZhbHNlLCJ3aWR0aCI6NTcyLCJoZWlnaHQiOjU4MCwic2F2ZWQiOnRydWUsImJhY2t1cCI6eyJmaWxlbmFtZSI6IkNhcHR1cmEtZGUtcGFudGFsbGEtMjAxOS0wNC0xMy1hLWxhcy0yMS4zNi4yOS5wbmciLCJ3aWR0aCI6NTcyLCJoZWlnaHQiOjU4MCwiZ2VuZXJhdGVkIjoiMC41Njk1NDEwMCAxNTU1MjA1ODMwIn0sIm1kNSI6IjM0ZWE3YjZhODRhYjM0ZDBmZDFhMDY5ZjBmMDVlMmI5IiwiZnVsbCI6eyJ3aWR0aCI6NTcyLCJoZWlnaHQiOjU4MCwibWQ1IjoiMzRlYTdiNmE4NGFiMzRkMGZkMWEwNjlmMGYwNWUyYjkifSwidGh1bWJuYWlsIjp7IndpZHRoIjoyNDAsImhlaWdodCI6MTYwLCJmaWxlbmFtZSI6InRodW1ic19DYXB0dXJhLWRlLXBhbnRhbGxhLTIwMTktMDQtMTMtYS1sYXMtMjEuMzYuMjkucG5nIiwiZ2VuZXJhdGVkIjoiMC4wMDI2NTAwMCAxNTU1MjA1ODMxIn19', 137, 1555265848),
(9, 'captura-de-pantalla-2019-04-13-a-las-21-36-33-2', 0, 1, 'Captura-de-pantalla-2019-04-13-a-las-21.36.33.png', '', 'empanadas', '2019-04-14 01:37:11', 0, 0, 'eyJhcGVydHVyZSI6ZmFsc2UsImNyZWRpdCI6ZmFsc2UsImNhbWVyYSI6ZmFsc2UsImNhcHRpb24iOmZhbHNlLCJjcmVhdGVkX3RpbWVzdGFtcCI6ZmFsc2UsImNvcHlyaWdodCI6ZmFsc2UsImZvY2FsX2xlbmd0aCI6ZmFsc2UsImlzbyI6ZmFsc2UsInNodXR0ZXJfc3BlZWQiOmZhbHNlLCJmbGFzaCI6ZmFsc2UsInRpdGxlIjpmYWxzZSwia2V5d29yZHMiOmZhbHNlLCJ3aWR0aCI6NTY0LCJoZWlnaHQiOjU3NCwic2F2ZWQiOnRydWUsImJhY2t1cCI6eyJmaWxlbmFtZSI6IkNhcHR1cmEtZGUtcGFudGFsbGEtMjAxOS0wNC0xMy1hLWxhcy0yMS4zNi4zMy5wbmciLCJ3aWR0aCI6NTY0LCJoZWlnaHQiOjU3NCwiZ2VuZXJhdGVkIjoiMC41MTk0NjUwMCAxNTU1MjA1ODMxIn0sIm1kNSI6IjJkNmFjYTk0YmI4ZmViMzZlYjVmNWI1NzY4YzdlNTc4IiwiZnVsbCI6eyJ3aWR0aCI6NTY0LCJoZWlnaHQiOjU3NCwibWQ1IjoiMmQ2YWNhOTRiYjhmZWIzNmViNWY1YjU3NjhjN2U1NzgifSwidGh1bWJuYWlsIjp7IndpZHRoIjoyNDAsImhlaWdodCI6MTYwLCJmaWxlbmFtZSI6InRodW1ic19DYXB0dXJhLWRlLXBhbnRhbGxhLTIwMTktMDQtMTMtYS1sYXMtMjEuMzYuMzMucG5nIiwiZ2VuZXJhdGVkIjoiMC45Mzc1ODkwMCAxNTU1MjA1ODMxIn19', 138, 1555265848),
(10, '1_captura-de-pantalla-2019-04-13-a-las-21-35-47', 0, 1, '1_Captura-de-pantalla-2019-04-13-a-las-21.35.47.png', '', 'Clientes felices', '2019-04-14 02:38:21', 0, 0, 'eyJhcGVydHVyZSI6ZmFsc2UsImNyZWRpdCI6ZmFsc2UsImNhbWVyYSI6ZmFsc2UsImNhcHRpb24iOmZhbHNlLCJjcmVhdGVkX3RpbWVzdGFtcCI6ZmFsc2UsImNvcHlyaWdodCI6ZmFsc2UsImZvY2FsX2xlbmd0aCI6ZmFsc2UsImlzbyI6ZmFsc2UsInNodXR0ZXJfc3BlZWQiOmZhbHNlLCJmbGFzaCI6ZmFsc2UsInRpdGxlIjpmYWxzZSwia2V5d29yZHMiOmZhbHNlLCJ3aWR0aCI6NTc2LCJoZWlnaHQiOjU2NCwic2F2ZWQiOnRydWUsImJhY2t1cCI6eyJmaWxlbmFtZSI6IjFfQ2FwdHVyYS1kZS1wYW50YWxsYS0yMDE5LTA0LTEzLWEtbGFzLTIxLjM1LjQ3LnBuZyIsIndpZHRoIjo1NzYsImhlaWdodCI6NTY0LCJnZW5lcmF0ZWQiOiIwLjE2OTQ0ODAwIDE1NTUyMDk1MDEifSwibWQ1IjoiNTU2ZjRjOWIwMGMyZmFkMmU3NzlmYzhjNjhhZmJlNjQiLCJmdWxsIjp7IndpZHRoIjo1NzYsImhlaWdodCI6NTY0LCJtZDUiOiI1NTZmNGM5YjAwYzJmYWQyZTc3OWZjOGM2OGFmYmU2NCJ9LCJ0aHVtYm5haWwiOnsid2lkdGgiOjI0MCwiaGVpZ2h0IjoxNjAsImZpbGVuYW1lIjoidGh1bWJzXzFfQ2FwdHVyYS1kZS1wYW50YWxsYS0yMDE5LTA0LTEzLWEtbGFzLTIxLjM1LjQ3LnBuZyIsImdlbmVyYXRlZCI6IjAuNTYwNDY1MDAgMTU1NTIwOTUwMSJ9fQ==', 145, 1555265848),
(11, '1_captura-de-pantalla-2019-04-13-a-las-21-35-52', 0, 1, '1_Captura-de-pantalla-2019-04-13-a-las-21.35.52.png', '', 'Clientes felices', '2019-04-14 02:38:21', 0, 0, 'eyJhcGVydHVyZSI6ZmFsc2UsImNyZWRpdCI6ZmFsc2UsImNhbWVyYSI6ZmFsc2UsImNhcHRpb24iOmZhbHNlLCJjcmVhdGVkX3RpbWVzdGFtcCI6ZmFsc2UsImNvcHlyaWdodCI6ZmFsc2UsImZvY2FsX2xlbmd0aCI6ZmFsc2UsImlzbyI6ZmFsc2UsInNodXR0ZXJfc3BlZWQiOmZhbHNlLCJmbGFzaCI6ZmFsc2UsInRpdGxlIjpmYWxzZSwia2V5d29yZHMiOmZhbHNlLCJ3aWR0aCI6NTY4LCJoZWlnaHQiOjU1Niwic2F2ZWQiOnRydWUsImJhY2t1cCI6eyJmaWxlbmFtZSI6IjFfQ2FwdHVyYS1kZS1wYW50YWxsYS0yMDE5LTA0LTEzLWEtbGFzLTIxLjM1LjUyLnBuZyIsIndpZHRoIjo1NjgsImhlaWdodCI6NTU2LCJnZW5lcmF0ZWQiOiIwLjk5NDMxNjAwIDE1NTUyMDk1MDEifSwibWQ1IjoiNzgyZjlhM2NlZTMxNWU3MWZhZWUzYzc4NWYwMmFiMjgiLCJmdWxsIjp7IndpZHRoIjo1NjgsImhlaWdodCI6NTU2LCJtZDUiOiI3ODJmOWEzY2VlMzE1ZTcxZmFlZTNjNzg1ZjAyYWIyOCJ9LCJ0aHVtYm5haWwiOnsid2lkdGgiOjI0MCwiaGVpZ2h0IjoxNjAsImZpbGVuYW1lIjoidGh1bWJzXzFfQ2FwdHVyYS1kZS1wYW50YWxsYS0yMDE5LTA0LTEzLWEtbGFzLTIxLjM1LjUyLnBuZyIsImdlbmVyYXRlZCI6IjAuMzQ2ODc0MDAgMTU1NTIwOTUwMiJ9fQ==', 146, 1555265848);

-- --------------------------------------------------------

--
-- Table structure for table `kwa_options`
--

CREATE TABLE `kwa_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `kwa_options`
--

INSERT INTO `kwa_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost:8080', 'yes'),
(2, 'home', 'http://localhost:8080', 'yes'),
(3, 'blogname', 'KWAfood', 'yes'),
(4, 'blogdescription', 'Los sabores de Venezuela', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'nada@nada.cl', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '3', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:91:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:39:\"index.php?&page_id=20&cpage=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:58:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:68:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:88:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:64:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:53:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$\";s:91:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$\";s:85:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1\";s:77:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:65:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]\";s:61:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]\";s:47:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]\";s:38:\"([0-9]{4})/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&cpage=$matches[2]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:5:{i:0;s:30:\"advanced-custom-fields/acf.php\";i:1;s:36:\"contact-form-7/wp-contact-form-7.php\";i:2;s:33:\"instagram-feed/instagram-feed.php\";i:3;s:56:\"tiled-gallery-carousel-without-jetpack/tiled-gallery.php\";i:4;s:29:\"nextgen-gallery/nggallery.php\";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '-3', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'KWAfood', 'yes'),
(41, 'stylesheet', 'KWAfood', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '44719', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:2:{s:59:\"ultimate-social-media-icons/ultimate_social_media_icons.php\";s:20:\"sfsi_Unistall_plugin\";s:33:\"instagram-feed/instagram-feed.php\";s:22:\"sb_instagram_uninstall\";}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '10', 'yes'),
(84, 'page_on_front', '20', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '8', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'wp_page_for_privacy_policy', '3', 'yes'),
(92, 'show_comments_cookies_opt_in', '1', 'yes'),
(93, 'initial_db_version', '44719', 'yes'),
(94, 'kwa_user_roles', 'a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:72:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:24:\"NextGEN Attach Interface\";b:1;s:22:\"NextGEN Change options\";b:1;s:20:\"NextGEN Change style\";b:1;s:18:\"NextGEN Edit album\";b:1;s:24:\"NextGEN Gallery overview\";b:1;s:22:\"NextGEN Manage gallery\";b:1;s:29:\"NextGEN Manage others gallery\";b:1;s:19:\"NextGEN Manage tags\";b:1;s:21:\"NextGEN Upload images\";b:1;s:19:\"NextGEN Use TinyMCE\";b:1;s:29:\"manage_instagram_feed_options\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}', 'yes'),
(95, 'fresh_site', '0', 'yes'),
(96, 'WPLANG', 'es_CL', 'yes'),
(97, 'widget_search', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(98, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(99, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(100, 'widget_archives', 'a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(101, 'widget_meta', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(102, 'sidebars_widgets', 'a:3:{s:19:\"wp_inactive_widgets\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:13:\"widget_footer\";a:1:{i:0;s:13:\"sfsi-widget-2\";}s:13:\"array_version\";i:3;}', 'yes'),
(103, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(104, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(105, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(106, 'widget_media_image', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(108, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(109, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(110, 'widget_nav_menu', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(111, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(112, 'cron', 'a:6:{i:1555378361;a:1:{s:29:\"ngg_delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"ngg_custom\";s:4:\"args\";a:0:{}s:8:\"interval\";i:900;}}}i:1555378954;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1555414954;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1555458166;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1555458172;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}', 'yes'),
(113, 'theme_mods_twentynineteen', 'a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1554671217;s:4:\"data\";a:2:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}}}}', 'yes'),
(130, 'can_compress_scripts', '1', 'no'),
(166, 'dismissed_update_core', 'a:1:{s:11:\"5.1.1|es_CL\";b:1;}', 'no'),
(173, 'current_theme', 'KwaFood restaurant.', 'yes'),
(174, 'theme_mods_KWAfood', 'a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:11:\"header-menu\";i:9;}s:18:\"custom_css_post_id\";i:-1;s:11:\"custom_logo\";i:6;}', 'yes'),
(175, 'theme_switched', '', 'yes'),
(201, 'category_children', 'a:0:{}', 'yes'),
(205, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}', 'yes'),
(212, 'recently_activated', 'a:6:{s:31:\"instanow-lite/instanow-lite.php\";i:1555270413;s:59:\"ultimate-social-media-icons/ultimate_social_media_icons.php\";i:1555270229;s:57:\"social-media-sidebar-icons/social-media-sidebar-icons.php\";i:1555269669;s:65:\"skins-for-social-media-feather/skins-for-social-media-feather.php\";i:1555269665;s:19:\"akismet/akismet.php\";i:1554769922;s:9:\"hello.php\";i:1554769914;}', 'yes'),
(219, 'acf_version', '5.7.12', 'yes'),
(220, 'widget_akismet_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(320, 'widget_ngg-images', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(321, 'widget_ngg-mrssw', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(322, 'widget_slideshow', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(323, 'ngg_transient_groups', 'a:7:{s:9:\"__counter\";i:7;s:16:\"WordPress-Router\";a:2:{s:2:\"id\";i:2;s:7:\"enabled\";b:1;}s:16:\"col_in_kwa_posts\";a:2:{s:2:\"id\";i:3;s:7:\"enabled\";b:1;}s:22:\"col_in_kwa_ngg_gallery\";a:2:{s:2:\"id\";i:4;s:7:\"enabled\";b:1;}s:23:\"col_in_kwa_ngg_pictures\";a:2:{s:2:\"id\";i:5;s:7:\"enabled\";b:1;}s:20:\"col_in_kwa_ngg_album\";a:2:{s:2:\"id\";i:6;s:7:\"enabled\";b:1;}s:27:\"displayed_gallery_rendering\";a:2:{s:2:\"id\";i:7;s:7:\"enabled\";b:1;}}', 'yes'),
(324, 'ngg_options', 'a:72:{s:11:\"gallerypath\";s:19:\"wp-content/gallery/\";s:11:\"wpmuCSSfile\";s:13:\"nggallery.css\";s:9:\"wpmuStyle\";b:0;s:9:\"wpmuRoles\";b:0;s:16:\"wpmuImportFolder\";b:0;s:13:\"wpmuZipUpload\";b:0;s:14:\"wpmuQuotaCheck\";b:0;s:17:\"datamapper_driver\";s:22:\"custom_post_datamapper\";s:20:\"maximum_entity_count\";i:500;s:17:\"router_param_slug\";s:9:\"nggallery\";s:22:\"router_param_separator\";s:2:\"--\";s:19:\"router_param_prefix\";s:0:\"\";s:9:\"deleteImg\";b:1;s:13:\"usePermalinks\";b:0;s:13:\"permalinkSlug\";s:9:\"nggallery\";s:14:\"graphicLibrary\";s:2:\"gd\";s:14:\"imageMagickDir\";s:15:\"/usr/local/bin/\";s:11:\"useMediaRSS\";b:0;s:18:\"galleries_in_feeds\";b:0;s:12:\"activateTags\";i:0;s:10:\"appendType\";s:4:\"tags\";s:9:\"maxImages\";i:7;s:14:\"relatedHeading\";s:24:\"<h3>Related Images:</h3>\";s:10:\"thumbwidth\";i:240;s:11:\"thumbheight\";i:160;s:8:\"thumbfix\";b:1;s:12:\"thumbquality\";i:100;s:8:\"imgWidth\";i:1800;s:9:\"imgHeight\";i:1200;s:10:\"imgQuality\";i:100;s:9:\"imgBackup\";b:1;s:13:\"imgAutoResize\";b:1;s:9:\"galImages\";s:2:\"24\";s:17:\"galPagedGalleries\";i:0;s:10:\"galColumns\";i:0;s:12:\"galShowSlide\";b:0;s:12:\"galTextSlide\";s:14:\"View Slideshow\";s:14:\"galTextGallery\";s:15:\"View Thumbnails\";s:12:\"galShowOrder\";s:7:\"gallery\";s:7:\"galSort\";s:9:\"sortorder\";s:10:\"galSortDir\";s:3:\"ASC\";s:10:\"galNoPages\";b:1;s:13:\"galImgBrowser\";i:0;s:12:\"galHiddenImg\";i:0;s:10:\"galAjaxNav\";i:1;s:11:\"thumbEffect\";s:14:\"simplelightbox\";s:9:\"thumbCode\";s:47:\"class=\"ngg-simplelightbox\" rel=\"%GALLERY_NAME%\"\";s:18:\"thumbEffectContext\";s:14:\"nextgen_images\";s:5:\"wmPos\";s:9:\"midCenter\";s:6:\"wmXpos\";i:15;s:6:\"wmYpos\";i:5;s:6:\"wmType\";s:4:\"text\";s:6:\"wmPath\";s:0:\"\";s:6:\"wmFont\";s:9:\"arial.ttf\";s:6:\"wmSize\";i:30;s:6:\"wmText\";s:7:\"KWAfood\";s:7:\"wmColor\";s:6:\"ffffff\";s:8:\"wmOpaque\";s:2:\"33\";s:7:\"slideFX\";s:4:\"fade\";s:7:\"irWidth\";i:750;s:8:\"irHeight\";i:500;s:12:\"irRotatetime\";i:5;s:11:\"activateCSS\";i:1;s:7:\"CSSfile\";s:13:\"nggallery.css\";s:28:\"always_enable_frontend_logic\";b:0;s:27:\"use_alternate_random_method\";b:0;s:23:\"random_widget_cache_ttl\";i:30;s:22:\"dynamic_thumbnail_slug\";s:13:\"nextgen-image\";s:23:\"dynamic_stylesheet_slug\";s:12:\"nextgen-dcss\";s:11:\"installDate\";i:1555205185;s:13:\"gallery_count\";i:1;s:40:\"gallery_created_after_reviews_introduced\";b:1;}', 'yes'),
(326, 'photocrati_auto_update_admin_update_list', '', 'yes'),
(327, 'photocrati_auto_update_admin_check_date', '', 'yes'),
(328, 'ngg_db_version', '1.8.1', 'yes'),
(331, 'pope_module_list', 'a:37:{i:0;s:19:\"photocrati-fs|3.1.8\";i:1;s:22:\"photocrati-i18n|3.1.14\";i:2;s:29:\"photocrati-validation|3.1.4.2\";i:3;s:25:\"photocrati-router|3.1.7.1\";i:4;s:34:\"photocrati-wordpress_routing|3.1.8\";i:5;s:25:\"photocrati-security|3.1.8\";i:6;s:33:\"photocrati-nextgen_settings|3.1.8\";i:7;s:20:\"photocrati-mvc|3.1.8\";i:8;s:21:\"photocrati-ajax|3.1.8\";i:9;s:28:\"photocrati-datamapper|3.1.14\";i:10;s:32:\"photocrati-nextgen-legacy|3.1.14\";i:11;s:32:\"photocrati-simple_html_dom|3.0.0\";i:12;s:30:\"photocrati-nextgen-data|3.1.14\";i:13;s:30:\"photocrati-nextgen_block|3.1.8\";i:14;s:35:\"photocrati-dynamic_thumbnails|3.1.8\";i:15;s:30:\"photocrati-nextgen_admin|3.1.8\";i:16;s:41:\"photocrati-nextgen_gallery_display|3.1.17\";i:17;s:36:\"photocrati-frame_communication|3.0.0\";i:18;s:32:\"photocrati-attach_to_post|3.1.16\";i:19;s:40:\"photocrati-nextgen_addgallery_page|3.1.8\";i:20;s:38:\"photocrati-nextgen_other_options|3.1.8\";i:21;s:37:\"photocrati-nextgen_pagination|3.0.0.2\";i:22;s:35:\"photocrati-dynamic_stylesheet|3.0.0\";i:23;s:36:\"photocrati-nextgen_pro_upgrade|3.0.0\";i:24;s:22:\"photocrati-cache|3.0.0\";i:25;s:28:\"photocrati-lightbox|3.1.11.1\";i:26;s:42:\"photocrati-nextgen_basic_templates|3.0.0.2\";i:27;s:38:\"photocrati-nextgen_basic_gallery|3.1.8\";i:28;s:43:\"photocrati-nextgen_basic_imagebrowser|3.1.8\";i:29;s:40:\"photocrati-nextgen_basic_singlepic|3.1.8\";i:30;s:39:\"photocrati-nextgen_basic_tagcloud|3.1.8\";i:31;s:36:\"photocrati-nextgen_basic_album|3.1.8\";i:32;s:23:\"photocrati-widget|3.1.6\";i:33;s:38:\"photocrati-third_party_compat|3.1.11.1\";i:34;s:32:\"photocrati-nextgen_xmlrpc|3.1.16\";i:35;s:22:\"photocrati-wpcli|3.0.0\";i:36;s:24:\"photocrati-imagify|3.1.8\";}', 'yes'),
(395, '_site_transient_timeout_browser_97f13ec12ae090ad8ce3b44283943675', '1555870503', 'no'),
(396, '_site_transient_browser_97f13ec12ae090ad8ce3b44283943675', 'a:10:{s:4:\"name\";s:6:\"Safari\";s:7:\"version\";s:6:\"12.0.2\";s:8:\"platform\";s:9:\"Macintosh\";s:10:\"update_url\";s:29:\"https://www.apple.com/safari/\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/safari.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/safari.png?1\";s:15:\"current_version\";s:2:\"11\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(397, '_site_transient_timeout_php_check_464f4068caea2f8f3edcc5ae59429c65', '1555870503', 'no'),
(398, '_site_transient_php_check_464f4068caea2f8f3edcc5ae59429c65', 'a:5:{s:19:\"recommended_version\";s:3:\"7.3\";s:15:\"minimum_version\";s:5:\"5.2.4\";s:12:\"is_supported\";b:1;s:9:\"is_secure\";b:1;s:13:\"is_acceptable\";b:1;}', 'no'),
(442, 'widget_social-buttons', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(469, 'widget_sfsi-widget', 'a:2:{i:2;a:2:{s:5:\"showf\";i:1;s:5:\"title\";s:24:\"Síguenos y dale like :)\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(482, 'widget_tie_insta-widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(485, 'sb_instagram_settings', 'a:39:{s:15:\"sb_instagram_at\";s:0:\"\";s:20:\"sb_instagram_user_id\";s:0:\"\";s:30:\"sb_instagram_preserve_settings\";s:0:\"\";s:23:\"sb_instagram_ajax_theme\";b:0;s:23:\"sb_instagram_cache_time\";i:1;s:28:\"sb_instagram_cache_time_unit\";s:5:\"hours\";s:18:\"sb_instagram_width\";s:3:\"100\";s:23:\"sb_instagram_width_unit\";s:1:\"%\";s:28:\"sb_instagram_feed_width_resp\";b:0;s:19:\"sb_instagram_height\";s:0:\"\";s:16:\"sb_instagram_num\";s:2:\"20\";s:24:\"sb_instagram_height_unit\";s:0:\"\";s:17:\"sb_instagram_cols\";s:1:\"4\";s:27:\"sb_instagram_disable_mobile\";b:0;s:26:\"sb_instagram_image_padding\";s:1:\"5\";s:31:\"sb_instagram_image_padding_unit\";s:2:\"px\";s:17:\"sb_instagram_sort\";s:4:\"none\";s:23:\"sb_instagram_background\";s:0:\"\";s:21:\"sb_instagram_show_btn\";b:1;s:27:\"sb_instagram_btn_background\";s:0:\"\";s:27:\"sb_instagram_btn_text_color\";s:0:\"\";s:21:\"sb_instagram_btn_text\";s:12:\"Load More...\";s:22:\"sb_instagram_image_res\";s:4:\"auto\";s:24:\"sb_instagram_show_header\";b:1;s:24:\"sb_instagram_header_size\";s:5:\"small\";s:25:\"sb_instagram_header_color\";s:0:\"\";s:28:\"sb_instagram_show_follow_btn\";b:1;s:33:\"sb_instagram_folow_btn_background\";s:0:\"\";s:34:\"sb_instagram_follow_btn_text_color\";s:0:\"\";s:28:\"sb_instagram_follow_btn_text\";s:19:\"Follow on Instagram\";s:23:\"sb_instagram_custom_css\";s:0:\"\";s:22:\"sb_instagram_custom_js\";s:0:\"\";s:17:\"sb_instagram_cron\";s:2:\"no\";s:9:\"check_api\";b:1;s:19:\"sb_instagram_backup\";b:1;s:24:\"enqueue_css_in_shortcode\";b:0;s:30:\"sb_instagram_disable_mob_swipe\";b:0;s:15:\"sbi_font_method\";s:3:\"svg\";s:28:\"sb_instagram_disable_awesome\";b:0;}', 'yes'),
(486, '_transient_timeout_instagram_feed_rating_notice_waiting', '1556480099', 'no'),
(487, '_transient_instagram_feed_rating_notice_waiting', 'waiting', 'no'),
(488, 'sbi_rating_notice', 'pending', 'yes'),
(501, 'wpcf7', 'a:2:{s:7:\"version\";s:5:\"5.1.1\";s:13:\"bulk_validate\";a:4:{s:9:\"timestamp\";i:1555261153;s:7:\"version\";s:5:\"5.1.1\";s:11:\"count_valid\";i:1;s:13:\"count_invalid\";i:0;}}', 'yes'),
(545, '_site_transient_timeout_theme_roots', '1555372927', 'no'),
(546, '_site_transient_theme_roots', 'a:1:{s:7:\"KWAfood\";s:7:\"/themes\";}', 'no'),
(555, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.1.1.zip\";s:6:\"locale\";s:5:\"es_CL\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.1.1.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.1.1-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.1.1-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.1.1\";s:7:\"version\";s:5:\"5.1.1\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.0\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1555371827;s:15:\"version_checked\";s:5:\"5.1.1\";s:12:\"translations\";a:0:{}}', 'no'),
(556, '_site_transient_update_themes', 'O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1555371828;s:7:\"checked\";a:1:{s:7:\"KWAfood\";s:3:\"0.1\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}', 'no'),
(557, '_site_transient_update_plugins', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1555371830;s:7:\"checked\";a:5:{s:30:\"advanced-custom-fields/acf.php\";s:6:\"5.7.12\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:5:\"5.1.1\";s:33:\"instagram-feed/instagram-feed.php\";s:4:\"1.12\";s:29:\"nextgen-gallery/nggallery.php\";s:6:\"3.1.17\";s:56:\"tiled-gallery-carousel-without-jetpack/tiled-gallery.php\";s:3:\"3.0\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:1:{i:0;a:7:{s:4:\"type\";s:6:\"plugin\";s:4:\"slug\";s:14:\"contact-form-7\";s:8:\"language\";s:5:\"es_CL\";s:7:\"version\";s:5:\"4.3.1\";s:7:\"updated\";s:19:\"2015-11-26 19:25:25\";s:7:\"package\";s:81:\"https://downloads.wordpress.org/translation/plugin/contact-form-7/4.3.1/es_CL.zip\";s:10:\"autoupdate\";b:1;}}s:9:\"no_update\";a:5:{s:30:\"advanced-custom-fields/acf.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:36:\"w.org/plugins/advanced-custom-fields\";s:4:\"slug\";s:22:\"advanced-custom-fields\";s:6:\"plugin\";s:30:\"advanced-custom-fields/acf.php\";s:11:\"new_version\";s:6:\"5.7.12\";s:3:\"url\";s:53:\"https://wordpress.org/plugins/advanced-custom-fields/\";s:7:\"package\";s:72:\"https://downloads.wordpress.org/plugin/advanced-custom-fields.5.7.12.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:75:\"https://ps.w.org/advanced-custom-fields/assets/icon-256x256.png?rev=1082746\";s:2:\"1x\";s:75:\"https://ps.w.org/advanced-custom-fields/assets/icon-128x128.png?rev=1082746\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:78:\"https://ps.w.org/advanced-custom-fields/assets/banner-1544x500.jpg?rev=1729099\";s:2:\"1x\";s:77:\"https://ps.w.org/advanced-custom-fields/assets/banner-772x250.jpg?rev=1729102\";}s:11:\"banners_rtl\";a:0:{}}s:36:\"contact-form-7/wp-contact-form-7.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:28:\"w.org/plugins/contact-form-7\";s:4:\"slug\";s:14:\"contact-form-7\";s:6:\"plugin\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:11:\"new_version\";s:5:\"5.1.1\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/contact-form-7/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/contact-form-7.5.1.1.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:66:\"https://ps.w.org/contact-form-7/assets/icon-256x256.png?rev=984007\";s:2:\"1x\";s:66:\"https://ps.w.org/contact-form-7/assets/icon-128x128.png?rev=984007\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/contact-form-7/assets/banner-1544x500.png?rev=860901\";s:2:\"1x\";s:68:\"https://ps.w.org/contact-form-7/assets/banner-772x250.png?rev=880427\";}s:11:\"banners_rtl\";a:0:{}}s:33:\"instagram-feed/instagram-feed.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:28:\"w.org/plugins/instagram-feed\";s:4:\"slug\";s:14:\"instagram-feed\";s:6:\"plugin\";s:33:\"instagram-feed/instagram-feed.php\";s:11:\"new_version\";s:4:\"1.12\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/instagram-feed/\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/plugin/instagram-feed.1.12.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:66:\"https://ps.w.org/instagram-feed/assets/icon-128x128.png?rev=991410\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:69:\"https://ps.w.org/instagram-feed/assets/banner-772x250.png?rev=1805441\";}s:11:\"banners_rtl\";a:0:{}}s:29:\"nextgen-gallery/nggallery.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:29:\"w.org/plugins/nextgen-gallery\";s:4:\"slug\";s:15:\"nextgen-gallery\";s:6:\"plugin\";s:29:\"nextgen-gallery/nggallery.php\";s:11:\"new_version\";s:6:\"3.1.17\";s:3:\"url\";s:46:\"https://wordpress.org/plugins/nextgen-gallery/\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/plugin/nextgen-gallery.3.1.17.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:68:\"https://ps.w.org/nextgen-gallery/assets/icon-256x256.png?rev=1875408\";s:2:\"1x\";s:68:\"https://ps.w.org/nextgen-gallery/assets/icon-128x128.png?rev=1875408\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:71:\"https://ps.w.org/nextgen-gallery/assets/banner-1544x500.png?rev=1962188\";s:2:\"1x\";s:70:\"https://ps.w.org/nextgen-gallery/assets/banner-772x250.png?rev=1962188\";}s:11:\"banners_rtl\";a:0:{}}s:56:\"tiled-gallery-carousel-without-jetpack/tiled-gallery.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:52:\"w.org/plugins/tiled-gallery-carousel-without-jetpack\";s:4:\"slug\";s:38:\"tiled-gallery-carousel-without-jetpack\";s:6:\"plugin\";s:56:\"tiled-gallery-carousel-without-jetpack/tiled-gallery.php\";s:11:\"new_version\";s:3:\"3.0\";s:3:\"url\";s:69:\"https://wordpress.org/plugins/tiled-gallery-carousel-without-jetpack/\";s:7:\"package\";s:85:\"https://downloads.wordpress.org/plugin/tiled-gallery-carousel-without-jetpack.3.0.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:90:\"https://ps.w.org/tiled-gallery-carousel-without-jetpack/assets/icon-256x256.png?rev=982770\";s:2:\"1x\";s:90:\"https://ps.w.org/tiled-gallery-carousel-without-jetpack/assets/icon-256x256.png?rev=982770\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:92:\"https://ps.w.org/tiled-gallery-carousel-without-jetpack/assets/banner-772x250.jpg?rev=982763\";}s:11:\"banners_rtl\";a:0:{}}}}', 'no'),
(561, '_transient_timeout_2__2951165530', '1555379703', 'no'),
(562, '_transient_2__2951165530', '[]', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `kwa_postmeta`
--

CREATE TABLE `kwa_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `kwa_postmeta`
--

INSERT INTO `kwa_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 6, '_wp_attached_file', '2019/04/screenshot.png'),
(4, 6, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:978;s:6:\"height\";i:906;s:4:\"file\";s:22:\"2019/04/screenshot.png\";s:5:\"sizes\";a:7:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"screenshot-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:22:\"screenshot-300x278.png\";s:5:\"width\";i:300;s:6:\"height\";i:278;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:22:\"screenshot-768x711.png\";s:5:\"width\";i:768;s:6:\"height\";i:711;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"platos-menu\";a:4:{s:4:\"file\";s:22:\"screenshot-690x250.png\";s:5:\"width\";i:690;s:6:\"height\";i:250;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"square\";a:4:{s:4:\"file\";s:22:\"screenshot-400x400.png\";s:5:\"width\";i:400;s:6:\"height\";i:400;s:9:\"mime-type\";s:9:\"image/png\";}s:16:\"post-custom-size\";a:4:{s:4:\"file\";s:22:\"screenshot-800x600.png\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:9:\"image/png\";}s:16:\"custom-size-blog\";a:4:{s:4:\"file\";s:22:\"screenshot-400x300.png\";s:5:\"width\";i:400;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(5, 7, '_wp_attached_file', '2019/04/cropped-screenshot.png'),
(6, 7, '_wp_attachment_context', 'custom-logo'),
(7, 7, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:978;s:6:\"height\";i:877;s:4:\"file\";s:30:\"2019/04/cropped-screenshot.png\";s:5:\"sizes\";a:7:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:30:\"cropped-screenshot-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:30:\"cropped-screenshot-300x269.png\";s:5:\"width\";i:300;s:6:\"height\";i:269;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:30:\"cropped-screenshot-768x689.png\";s:5:\"width\";i:768;s:6:\"height\";i:689;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"platos-menu\";a:4:{s:4:\"file\";s:30:\"cropped-screenshot-690x250.png\";s:5:\"width\";i:690;s:6:\"height\";i:250;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"square\";a:4:{s:4:\"file\";s:30:\"cropped-screenshot-400x400.png\";s:5:\"width\";i:400;s:6:\"height\";i:400;s:9:\"mime-type\";s:9:\"image/png\";}s:16:\"post-custom-size\";a:4:{s:4:\"file\";s:30:\"cropped-screenshot-800x600.png\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:9:\"image/png\";}s:16:\"custom-size-blog\";a:4:{s:4:\"file\";s:30:\"cropped-screenshot-400x300.png\";s:5:\"width\";i:400;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(8, 8, '_wp_attached_file', '2019/04/cropped-screenshot-1.png'),
(9, 8, '_wp_attachment_context', 'site-icon'),
(10, 8, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:512;s:6:\"height\";i:512;s:4:\"file\";s:32:\"2019/04/cropped-screenshot-1.png\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:32:\"cropped-screenshot-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:32:\"cropped-screenshot-1-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"platos-menu\";a:4:{s:4:\"file\";s:32:\"cropped-screenshot-1-512x250.png\";s:5:\"width\";i:512;s:6:\"height\";i:250;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"square\";a:4:{s:4:\"file\";s:32:\"cropped-screenshot-1-400x400.png\";s:5:\"width\";i:400;s:6:\"height\";i:400;s:9:\"mime-type\";s:9:\"image/png\";}s:16:\"custom-size-blog\";a:4:{s:4:\"file\";s:32:\"cropped-screenshot-1-400x300.png\";s:5:\"width\";i:400;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"site_icon-270\";a:4:{s:4:\"file\";s:32:\"cropped-screenshot-1-270x270.png\";s:5:\"width\";i:270;s:6:\"height\";i:270;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"site_icon-192\";a:4:{s:4:\"file\";s:32:\"cropped-screenshot-1-192x192.png\";s:5:\"width\";i:192;s:6:\"height\";i:192;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"site_icon-180\";a:4:{s:4:\"file\";s:32:\"cropped-screenshot-1-180x180.png\";s:5:\"width\";i:180;s:6:\"height\";i:180;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"site_icon-32\";a:4:{s:4:\"file\";s:30:\"cropped-screenshot-1-32x32.png\";s:5:\"width\";i:32;s:6:\"height\";i:32;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(11, 9, '_wp_trash_meta_status', 'publish'),
(12, 9, '_wp_trash_meta_time', '1554678480'),
(13, 10, '_edit_lock', '1555208295:1'),
(14, 12, '_wp_attached_file', '2019/04/IMG-20190204-WA0224.jpg'),
(15, 12, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1279;s:6:\"height\";i:1280;s:4:\"file\";s:31:\"2019/04/IMG-20190204-WA0224.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"IMG-20190204-WA0224-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"IMG-20190204-WA0224-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"IMG-20190204-WA0224-768x769.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:769;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:33:\"IMG-20190204-WA0224-1024x1024.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"platos-menu\";a:4:{s:4:\"file\";s:31:\"IMG-20190204-WA0224-690x250.jpg\";s:5:\"width\";i:690;s:6:\"height\";i:250;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"square\";a:4:{s:4:\"file\";s:31:\"IMG-20190204-WA0224-400x400.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:16:\"post-custom-size\";a:4:{s:4:\"file\";s:31:\"IMG-20190204-WA0224-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:16:\"custom-size-blog\";a:4:{s:4:\"file\";s:31:\"IMG-20190204-WA0224-400x300.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(16, 13, '_wp_attached_file', '2019/04/cropped-IMG-20190204-WA0224.jpg'),
(17, 13, '_wp_attachment_context', 'custom-logo'),
(18, 13, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1279;s:6:\"height\";i:1178;s:4:\"file\";s:39:\"2019/04/cropped-IMG-20190204-WA0224.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:39:\"cropped-IMG-20190204-WA0224-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:39:\"cropped-IMG-20190204-WA0224-300x276.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:276;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:39:\"cropped-IMG-20190204-WA0224-768x707.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:707;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:40:\"cropped-IMG-20190204-WA0224-1024x943.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:943;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"platos-menu\";a:4:{s:4:\"file\";s:39:\"cropped-IMG-20190204-WA0224-690x250.jpg\";s:5:\"width\";i:690;s:6:\"height\";i:250;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"square\";a:4:{s:4:\"file\";s:39:\"cropped-IMG-20190204-WA0224-400x400.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:16:\"post-custom-size\";a:4:{s:4:\"file\";s:39:\"cropped-IMG-20190204-WA0224-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:16:\"custom-size-blog\";a:4:{s:4:\"file\";s:39:\"cropped-IMG-20190204-WA0224-400x300.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(20, 15, '_wp_attached_file', '2019/04/cropped-IMG-20190204-WA0224-1.jpg'),
(21, 15, '_wp_attachment_context', 'custom-logo'),
(22, 15, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1279;s:6:\"height\";i:1176;s:4:\"file\";s:41:\"2019/04/cropped-IMG-20190204-WA0224-1.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:41:\"cropped-IMG-20190204-WA0224-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:41:\"cropped-IMG-20190204-WA0224-1-300x276.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:276;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:41:\"cropped-IMG-20190204-WA0224-1-768x706.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:706;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:42:\"cropped-IMG-20190204-WA0224-1-1024x942.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:942;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"platos-menu\";a:4:{s:4:\"file\";s:41:\"cropped-IMG-20190204-WA0224-1-690x250.jpg\";s:5:\"width\";i:690;s:6:\"height\";i:250;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"square\";a:4:{s:4:\"file\";s:41:\"cropped-IMG-20190204-WA0224-1-400x400.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:16:\"post-custom-size\";a:4:{s:4:\"file\";s:41:\"cropped-IMG-20190204-WA0224-1-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:16:\"custom-size-blog\";a:4:{s:4:\"file\";s:41:\"cropped-IMG-20190204-WA0224-1-400x300.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(25, 17, '_wp_attached_file', '2019/04/cropped-IMG-20190204-WA0224-2.jpg'),
(26, 17, '_wp_attachment_context', 'custom-logo'),
(27, 17, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1279;s:6:\"height\";i:1262;s:4:\"file\";s:41:\"2019/04/cropped-IMG-20190204-WA0224-2.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:41:\"cropped-IMG-20190204-WA0224-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:41:\"cropped-IMG-20190204-WA0224-2-300x296.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:296;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:41:\"cropped-IMG-20190204-WA0224-2-768x758.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:758;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:43:\"cropped-IMG-20190204-WA0224-2-1024x1010.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:1010;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"platos-menu\";a:4:{s:4:\"file\";s:41:\"cropped-IMG-20190204-WA0224-2-690x250.jpg\";s:5:\"width\";i:690;s:6:\"height\";i:250;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"square\";a:4:{s:4:\"file\";s:41:\"cropped-IMG-20190204-WA0224-2-400x400.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:16:\"post-custom-size\";a:4:{s:4:\"file\";s:41:\"cropped-IMG-20190204-WA0224-2-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:16:\"custom-size-blog\";a:4:{s:4:\"file\";s:41:\"cropped-IMG-20190204-WA0224-2-400x300.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(29, 18, '_wp_trash_meta_status', 'publish'),
(30, 18, '_wp_trash_meta_time', '1554681315'),
(31, 20, '_edit_lock', '1555280749:1'),
(32, 1, '_edit_lock', '1554695399:1'),
(37, 1, '_thumbnail_id', '6'),
(38, 24, '_edit_lock', '1554866697:1'),
(39, 25, '_wp_attached_file', '2019/04/IMG_20190330_142954.jpg'),
(40, 25, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:3120;s:6:\"height\";i:4160;s:4:\"file\";s:31:\"2019/04/IMG_20190330_142954.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"IMG_20190330_142954-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"IMG_20190330_142954-225x300.jpg\";s:5:\"width\";i:225;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:32:\"IMG_20190330_142954-768x1024.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"IMG_20190330_142954-768x1024.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"platos-menu\";a:4:{s:4:\"file\";s:31:\"IMG_20190330_142954-690x250.jpg\";s:5:\"width\";i:690;s:6:\"height\";i:250;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"square\";a:4:{s:4:\"file\";s:31:\"IMG_20190330_142954-400x400.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:16:\"post-custom-size\";a:4:{s:4:\"file\";s:31:\"IMG_20190330_142954-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:16:\"custom-size-blog\";a:4:{s:4:\"file\";s:31:\"IMG_20190330_142954-400x300.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"2\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:7:\"Nokia 5\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1553956194\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:4:\"3.57\";s:3:\"iso\";s:3:\"250\";s:13:\"shutter_speed\";s:4:\"0.05\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(43, 24, '_thumbnail_id', '25'),
(44, 27, '_menu_item_type', 'custom'),
(45, 27, '_menu_item_menu_item_parent', '0'),
(46, 27, '_menu_item_object_id', '27'),
(47, 27, '_menu_item_object', 'custom'),
(48, 27, '_menu_item_target', ''),
(49, 27, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(50, 27, '_menu_item_xfn', ''),
(51, 27, '_menu_item_url', '/#fastmenu'),
(53, 28, '_menu_item_type', 'custom'),
(54, 28, '_menu_item_menu_item_parent', '0'),
(55, 28, '_menu_item_object_id', '28'),
(56, 28, '_menu_item_object', 'custom'),
(57, 28, '_menu_item_target', ''),
(58, 28, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(59, 28, '_menu_item_xfn', ''),
(60, 28, '_menu_item_url', '/#lacarta'),
(62, 29, '_menu_item_type', 'custom'),
(63, 29, '_menu_item_menu_item_parent', '0'),
(64, 29, '_menu_item_object_id', '29'),
(65, 29, '_menu_item_object', 'custom'),
(66, 29, '_menu_item_target', ''),
(67, 29, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(68, 29, '_menu_item_xfn', ''),
(69, 29, '_menu_item_url', '/#us'),
(71, 30, '_menu_item_type', 'custom'),
(72, 30, '_menu_item_menu_item_parent', '0'),
(73, 30, '_menu_item_object_id', '30'),
(74, 30, '_menu_item_object', 'custom'),
(75, 30, '_menu_item_target', ''),
(76, 30, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(77, 30, '_menu_item_xfn', ''),
(78, 30, '_menu_item_url', '/#contact'),
(89, 32, '_menu_item_type', 'post_type'),
(90, 32, '_menu_item_menu_item_parent', '0'),
(91, 32, '_menu_item_object_id', '10'),
(92, 32, '_menu_item_object', 'page'),
(93, 32, '_menu_item_target', ''),
(94, 32, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(95, 32, '_menu_item_xfn', ''),
(96, 32, '_menu_item_url', ''),
(98, 33, '_edit_last', '1'),
(99, 33, '_edit_lock', '1554693110:1'),
(100, 34, '_wp_attached_file', '2019/04/IMG_20190331_151243.jpg'),
(101, 34, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:4160;s:6:\"height\";i:3120;s:4:\"file\";s:31:\"2019/04/IMG_20190331_151243.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"IMG_20190331_151243-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"IMG_20190331_151243-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"IMG_20190331_151243-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"IMG_20190331_151243-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"platos-menu\";a:4:{s:4:\"file\";s:31:\"IMG_20190331_151243-690x250.jpg\";s:5:\"width\";i:690;s:6:\"height\";i:250;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"square\";a:4:{s:4:\"file\";s:31:\"IMG_20190331_151243-400x400.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:16:\"post-custom-size\";a:4:{s:4:\"file\";s:31:\"IMG_20190331_151243-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:16:\"custom-size-blog\";a:4:{s:4:\"file\";s:31:\"IMG_20190331_151243-400x300.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"2\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:7:\"Nokia 5\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1554045164\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:4:\"3.57\";s:3:\"iso\";s:3:\"125\";s:13:\"shutter_speed\";s:16:\"0.03030303030303\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(102, 33, '_thumbnail_id', '50'),
(103, 35, '_edit_last', '1'),
(104, 35, '_edit_lock', '1554693099:1'),
(105, 36, '_wp_attached_file', '2019/04/empanadas.jpg'),
(106, 36, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1280;s:6:\"height\";i:720;s:4:\"file\";s:21:\"2019/04/empanadas.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"empanadas-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"empanadas-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"empanadas-768x432.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:22:\"empanadas-1024x576.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"platos-menu\";a:4:{s:4:\"file\";s:21:\"empanadas-690x250.jpg\";s:5:\"width\";i:690;s:6:\"height\";i:250;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"square\";a:4:{s:4:\"file\";s:21:\"empanadas-400x400.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:16:\"post-custom-size\";a:4:{s:4:\"file\";s:21:\"empanadas-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:16:\"custom-size-blog\";a:4:{s:4:\"file\";s:21:\"empanadas-400x300.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(107, 35, '_thumbnail_id', '49'),
(108, 37, '_edit_last', '1'),
(109, 37, '_edit_lock', '1554693084:1'),
(110, 38, '_wp_attached_file', '2019/04/clubhouse.jpg'),
(111, 38, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1400;s:6:\"height\";i:919;s:4:\"file\";s:21:\"2019/04/clubhouse.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"clubhouse-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"clubhouse-300x197.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"clubhouse-768x504.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:504;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:22:\"clubhouse-1024x672.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:672;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"platos-menu\";a:4:{s:4:\"file\";s:21:\"clubhouse-690x250.jpg\";s:5:\"width\";i:690;s:6:\"height\";i:250;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"square\";a:4:{s:4:\"file\";s:21:\"clubhouse-400x400.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:16:\"post-custom-size\";a:4:{s:4:\"file\";s:21:\"clubhouse-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:16:\"custom-size-blog\";a:4:{s:4:\"file\";s:21:\"clubhouse-400x300.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(112, 37, '_thumbnail_id', '48'),
(113, 39, '_edit_last', '1'),
(114, 39, '_edit_lock', '1554693067:1'),
(115, 40, '_wp_attached_file', '2019/04/IMG_20190331_151226.jpg'),
(116, 40, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:4160;s:6:\"height\";i:3120;s:4:\"file\";s:31:\"2019/04/IMG_20190331_151226.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"IMG_20190331_151226-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"IMG_20190331_151226-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"IMG_20190331_151226-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"IMG_20190331_151226-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"platos-menu\";a:4:{s:4:\"file\";s:31:\"IMG_20190331_151226-690x250.jpg\";s:5:\"width\";i:690;s:6:\"height\";i:250;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"square\";a:4:{s:4:\"file\";s:31:\"IMG_20190331_151226-400x400.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:16:\"post-custom-size\";a:4:{s:4:\"file\";s:31:\"IMG_20190331_151226-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:16:\"custom-size-blog\";a:4:{s:4:\"file\";s:31:\"IMG_20190331_151226-400x300.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"2\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:7:\"Nokia 5\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1554045146\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:4:\"3.57\";s:3:\"iso\";s:3:\"125\";s:13:\"shutter_speed\";s:16:\"0.03030303030303\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(117, 39, '_thumbnail_id', '47'),
(118, 41, '_edit_last', '1'),
(119, 41, '_edit_lock', '1554693057:1'),
(120, 42, '_wp_attached_file', '2019/04/cesar.jpg'),
(121, 42, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1280;s:6:\"height\";i:847;s:4:\"file\";s:17:\"2019/04/cesar.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"cesar-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"cesar-300x199.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:199;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:17:\"cesar-768x508.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:508;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:18:\"cesar-1024x678.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:678;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"platos-menu\";a:4:{s:4:\"file\";s:17:\"cesar-690x250.jpg\";s:5:\"width\";i:690;s:6:\"height\";i:250;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"square\";a:4:{s:4:\"file\";s:17:\"cesar-400x400.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:16:\"post-custom-size\";a:4:{s:4:\"file\";s:17:\"cesar-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:16:\"custom-size-blog\";a:4:{s:4:\"file\";s:17:\"cesar-400x300.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(122, 41, '_thumbnail_id', '46'),
(123, 43, '_edit_last', '1'),
(124, 43, '_edit_lock', '1554693045:1'),
(125, 44, '_wp_attached_file', '2019/04/golfeados.jpg'),
(126, 44, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2448;s:6:\"height\";i:2448;s:4:\"file\";s:21:\"2019/04/golfeados.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"golfeados-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"golfeados-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"golfeados-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:23:\"golfeados-1024x1024.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"platos-menu\";a:4:{s:4:\"file\";s:21:\"golfeados-690x250.jpg\";s:5:\"width\";i:690;s:6:\"height\";i:250;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"square\";a:4:{s:4:\"file\";s:21:\"golfeados-400x400.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:16:\"post-custom-size\";a:4:{s:4:\"file\";s:21:\"golfeados-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:16:\"custom-size-blog\";a:4:{s:4:\"file\";s:21:\"golfeados-400x300.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.4\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:8:\"iPhone 5\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1435837353\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:4:\"4.12\";s:3:\"iso\";s:3:\"125\";s:13:\"shutter_speed\";s:4:\"0.05\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(127, 43, '_thumbnail_id', '45'),
(128, 45, '_wp_attached_file', '2019/04/golfeados-1.jpg'),
(129, 45, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:650;s:6:\"height\";i:350;s:4:\"file\";s:23:\"2019/04/golfeados-1.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"golfeados-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:23:\"golfeados-1-300x162.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:162;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"platos-menu\";a:4:{s:4:\"file\";s:23:\"golfeados-1-650x250.jpg\";s:5:\"width\";i:650;s:6:\"height\";i:250;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"square\";a:4:{s:4:\"file\";s:23:\"golfeados-1-400x350.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:350;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:16:\"custom-size-blog\";a:4:{s:4:\"file\";s:23:\"golfeados-1-400x300.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(130, 46, '_wp_attached_file', '2019/04/cesar-1.jpg'),
(131, 46, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:650;s:6:\"height\";i:350;s:4:\"file\";s:19:\"2019/04/cesar-1.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"cesar-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"cesar-1-300x162.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:162;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"platos-menu\";a:4:{s:4:\"file\";s:19:\"cesar-1-650x250.jpg\";s:5:\"width\";i:650;s:6:\"height\";i:250;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"square\";a:4:{s:4:\"file\";s:19:\"cesar-1-400x350.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:350;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:16:\"custom-size-blog\";a:4:{s:4:\"file\";s:19:\"cesar-1-400x300.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(132, 47, '_wp_attached_file', '2019/04/sandvege.jpg'),
(133, 47, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:650;s:6:\"height\";i:350;s:4:\"file\";s:20:\"2019/04/sandvege.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"sandvege-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"sandvege-300x162.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:162;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"platos-menu\";a:4:{s:4:\"file\";s:20:\"sandvege-650x250.jpg\";s:5:\"width\";i:650;s:6:\"height\";i:250;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"square\";a:4:{s:4:\"file\";s:20:\"sandvege-400x350.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:350;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:16:\"custom-size-blog\";a:4:{s:4:\"file\";s:20:\"sandvege-400x300.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(134, 48, '_wp_attached_file', '2019/04/clubhouse-1.jpg'),
(135, 48, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:650;s:6:\"height\";i:350;s:4:\"file\";s:23:\"2019/04/clubhouse-1.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"clubhouse-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:23:\"clubhouse-1-300x162.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:162;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"platos-menu\";a:4:{s:4:\"file\";s:23:\"clubhouse-1-650x250.jpg\";s:5:\"width\";i:650;s:6:\"height\";i:250;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"square\";a:4:{s:4:\"file\";s:23:\"clubhouse-1-400x350.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:350;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:16:\"custom-size-blog\";a:4:{s:4:\"file\";s:23:\"clubhouse-1-400x300.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(136, 49, '_wp_attached_file', '2019/04/empanadas-1.jpg'),
(137, 49, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:650;s:6:\"height\";i:350;s:4:\"file\";s:23:\"2019/04/empanadas-1.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"empanadas-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:23:\"empanadas-1-300x162.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:162;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"platos-menu\";a:4:{s:4:\"file\";s:23:\"empanadas-1-650x250.jpg\";s:5:\"width\";i:650;s:6:\"height\";i:250;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"square\";a:4:{s:4:\"file\";s:23:\"empanadas-1-400x350.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:350;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:16:\"custom-size-blog\";a:4:{s:4:\"file\";s:23:\"empanadas-1-400x300.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(138, 50, '_wp_attached_file', '2019/04/tequeños.jpg'),
(139, 50, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:650;s:6:\"height\";i:350;s:4:\"file\";s:21:\"2019/04/tequeños.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"tequeños-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"tequeños-300x162.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:162;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"platos-menu\";a:4:{s:4:\"file\";s:21:\"tequeños-650x250.jpg\";s:5:\"width\";i:650;s:6:\"height\";i:250;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"square\";a:4:{s:4:\"file\";s:21:\"tequeños-400x350.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:350;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:16:\"custom-size-blog\";a:4:{s:4:\"file\";s:21:\"tequeños-400x300.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(141, 52, '_edit_last', '1'),
(142, 52, '_edit_lock', '1555275224:1'),
(143, 20, '_edit_last', '1'),
(144, 20, 'us_title', 'Arepa con queso'),
(145, 20, '_us_title', 'field_5caac210b2b3b'),
(146, 20, 'nosotros', 'Cagua es una ciudad de Venezuela, capital del municipio Sucre (Aragua), situada a 458 msnm en el valle del río Aragua, en la parte noroeste del estado Aragua, teniendo un área aproximada de 27 km² íntegramente dentro del municipio Sucre. Está atravesada de norte a sur por la Carretera Nacional Cagua - La Villa, importante arteria vial que comunica los Valles de Aragua con los Llanos centrales, a través del abra de Villa de Cura; además, posee comunicación directa con las ciudades de Santa Cruz de Aragua y San Mateo, así como con el importante nudo comunicacional de La Encrucijada.'),
(147, 20, '_nosotros', 'field_5caac2558e5b4'),
(148, 57, 'us_title', 'Arepa con queso'),
(149, 57, '_us_title', 'field_5caac210b2b3b'),
(150, 57, 'nosotros', ''),
(151, 57, '_nosotros', 'field_5caac2558e5b4'),
(152, 58, 'us_title', 'Arepa con queso'),
(153, 58, '_us_title', 'field_5caac210b2b3b'),
(154, 58, 'nosotros', 'Cagua es una ciudad de Venezuela, capital del municipio Sucre (Aragua), situada a 458 msnm en el valle del río Aragua, en la parte noroeste del estado Aragua, teniendo un área aproximada de 27 km² íntegramente dentro del municipio Sucre. Está atravesada de norte a sur por la Carretera Nacional Cagua - La Villa, importante arteria vial que comunica los Valles de Aragua con los Llanos centrales, a través del abra de Villa de Cura; además, posee comunicación directa con las ciudades de Santa Cruz de Aragua y San Mateo, así como con el importante nudo comunicacional de La Encrucijada.'),
(155, 58, '_nosotros', 'field_5caac2558e5b4'),
(156, 59, '_menu_item_type', 'post_type'),
(157, 59, '_menu_item_menu_item_parent', '0'),
(158, 59, '_menu_item_object_id', '20'),
(159, 59, '_menu_item_object', 'page'),
(160, 59, '_menu_item_target', ''),
(161, 59, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(162, 59, '_menu_item_xfn', ''),
(163, 59, '_menu_item_url', ''),
(164, 59, '_menu_item_orphaned', '1554766823'),
(165, 60, '_menu_item_type', 'post_type'),
(166, 60, '_menu_item_menu_item_parent', '0'),
(167, 60, '_menu_item_object_id', '10'),
(168, 60, '_menu_item_object', 'page'),
(169, 60, '_menu_item_target', ''),
(170, 60, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(171, 60, '_menu_item_xfn', ''),
(172, 60, '_menu_item_url', ''),
(173, 60, '_menu_item_orphaned', '1554766823'),
(174, 61, '_menu_item_type', 'post_type'),
(175, 61, '_menu_item_menu_item_parent', '0'),
(176, 61, '_menu_item_object_id', '2'),
(177, 61, '_menu_item_object', 'page'),
(178, 61, '_menu_item_target', ''),
(179, 61, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(180, 61, '_menu_item_xfn', ''),
(181, 61, '_menu_item_url', ''),
(182, 61, '_menu_item_orphaned', '1554766823'),
(183, 62, '_edit_last', '1'),
(184, 62, '_edit_lock', '1554866933:1'),
(185, 63, '_wp_attached_file', '2019/04/jueves.png'),
(186, 63, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:284;s:6:\"height\";i:259;s:4:\"file\";s:18:\"2019/04/jueves.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"jueves-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"platos-menu\";a:4:{s:4:\"file\";s:18:\"jueves-284x250.png\";s:5:\"width\";i:284;s:6:\"height\";i:250;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(187, 64, '_wp_attached_file', '2019/04/lunes.png'),
(188, 64, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:284;s:6:\"height\";i:259;s:4:\"file\";s:17:\"2019/04/lunes.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"lunes-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"platos-menu\";a:4:{s:4:\"file\";s:17:\"lunes-284x250.png\";s:5:\"width\";i:284;s:6:\"height\";i:250;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(189, 65, '_wp_attached_file', '2019/04/martes.png'),
(190, 65, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:288;s:6:\"height\";i:262;s:4:\"file\";s:18:\"2019/04/martes.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"martes-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"platos-menu\";a:4:{s:4:\"file\";s:18:\"martes-288x250.png\";s:5:\"width\";i:288;s:6:\"height\";i:250;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(191, 66, '_wp_attached_file', '2019/04/miercoles.png'),
(192, 66, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:297;s:6:\"height\";i:265;s:4:\"file\";s:21:\"2019/04/miercoles.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"miercoles-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"platos-menu\";a:4:{s:4:\"file\";s:21:\"miercoles-297x250.png\";s:5:\"width\";i:297;s:6:\"height\";i:250;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(193, 67, '_wp_attached_file', '2019/04/sabadom.png'),
(194, 67, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:291;s:6:\"height\";i:259;s:4:\"file\";s:19:\"2019/04/sabadom.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"sabadom-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"platos-menu\";a:4:{s:4:\"file\";s:19:\"sabadom-291x250.png\";s:5:\"width\";i:291;s:6:\"height\";i:250;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(195, 68, '_wp_attached_file', '2019/04/viernes.png'),
(196, 68, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:284;s:6:\"height\";i:259;s:4:\"file\";s:19:\"2019/04/viernes.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"viernes-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"platos-menu\";a:4:{s:4:\"file\";s:19:\"viernes-284x250.png\";s:5:\"width\";i:284;s:6:\"height\";i:250;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(198, 69, '_edit_last', '1'),
(199, 69, '_edit_lock', '1554866230:1'),
(200, 70, '_edit_last', '1'),
(201, 70, '_edit_lock', '1554866271:1'),
(202, 71, '_edit_last', '1'),
(203, 71, '_edit_lock', '1554866289:1'),
(204, 72, '_edit_last', '1'),
(205, 72, '_edit_lock', '1554866688:1'),
(206, 73, '_edit_lock', '1554939361:1'),
(207, 74, '_wp_attached_file', '2019/04/IMG-20190321-WA0012.jpg'),
(208, 74, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:847;s:6:\"height\";i:1280;s:4:\"file\";s:31:\"2019/04/IMG-20190321-WA0012.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"IMG-20190321-WA0012-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"IMG-20190321-WA0012-199x300.jpg\";s:5:\"width\";i:199;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:32:\"IMG-20190321-WA0012-768x1161.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1161;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"IMG-20190321-WA0012-678x1024.jpg\";s:5:\"width\";i:678;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"platos-menu\";a:4:{s:4:\"file\";s:31:\"IMG-20190321-WA0012-690x250.jpg\";s:5:\"width\";i:690;s:6:\"height\";i:250;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"square\";a:4:{s:4:\"file\";s:31:\"IMG-20190321-WA0012-400x400.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:16:\"post-custom-size\";a:4:{s:4:\"file\";s:31:\"IMG-20190321-WA0012-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:16:\"custom-size-blog\";a:4:{s:4:\"file\";s:31:\"IMG-20190321-WA0012-400x300.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(211, 73, '_thumbnail_id', '74'),
(212, 76, '_edit_last', '1'),
(213, 76, '_edit_lock', '1554941494:1'),
(214, 83, '_edit_lock', '1554940611:1'),
(217, 83, '_edit_last', '1'),
(220, 83, 'promo_lunes', 'Arepas Gratis'),
(221, 83, '_promo_lunes', 'field_5cae816a64d39'),
(222, 83, 'promo_martes', ''),
(223, 83, '_promo_martes', 'field_5cae819564d3a'),
(224, 83, 'promo_miercoles', ''),
(225, 83, '_promo_miercoles', 'field_5cae81a764d3b'),
(226, 83, 'promo_jueves', ''),
(227, 83, '_promo_jueves', 'field_5cae81b364d3c'),
(228, 83, 'promo_viernes', ''),
(229, 83, '_promo_viernes', 'field_5cae81bf64d3d'),
(230, 83, 'promo_SaDo', ''),
(231, 83, '_promo_SaDo', 'field_5cae81ca64d3e'),
(232, 85, 'promo_lunes', 'Arepas Gratis'),
(233, 85, '_promo_lunes', 'field_5cae816a64d39'),
(234, 85, 'promo_martes', ''),
(235, 85, '_promo_martes', 'field_5cae819564d3a'),
(236, 85, 'promo_miercoles', ''),
(237, 85, '_promo_miercoles', 'field_5cae81a764d3b'),
(238, 85, 'promo_jueves', ''),
(239, 85, '_promo_jueves', 'field_5cae81b364d3c'),
(240, 85, 'promo_viernes', ''),
(241, 85, '_promo_viernes', 'field_5cae81bf64d3d'),
(242, 85, 'promo_SaDo', ''),
(243, 85, '_promo_SaDo', 'field_5cae81ca64d3e'),
(244, 83, '_wp_trash_meta_status', 'publish'),
(245, 83, '_wp_trash_meta_time', '1554940643'),
(246, 83, '_wp_desired_post_slug', 'promociones'),
(247, 86, '_edit_last', '1'),
(248, 86, 'promo_lunes', 'AREPA GRATIS'),
(249, 86, '_promo_lunes', 'field_5cae816a64d39'),
(250, 86, 'promo_martes', ''),
(251, 86, '_promo_martes', 'field_5cae819564d3a'),
(252, 86, 'promo_miercoles', ''),
(253, 86, '_promo_miercoles', 'field_5cae81a764d3b'),
(254, 86, 'promo_jueves', ''),
(255, 86, '_promo_jueves', 'field_5cae81b364d3c'),
(256, 86, 'promo_viernes', ''),
(257, 86, '_promo_viernes', 'field_5cae81bf64d3d'),
(258, 86, 'promo_SaDo', ''),
(259, 86, '_promo_SaDo', 'field_5cae81ca64d3e'),
(260, 86, '_edit_lock', '1555209306:1'),
(261, 20, 'promo_lunes', 'BEBIDAS GRATIS'),
(262, 20, '_promo_lunes', 'field_5cae816a64d39'),
(263, 20, 'promo_martes', '2X1 EN ENSALADAS'),
(264, 20, '_promo_martes', 'field_5cae819564d3a'),
(265, 20, 'promo_miercoles', 'COMBO TEQUEÑOS + BEBIDA $4.000'),
(266, 20, '_promo_miercoles', 'field_5cae81a764d3b'),
(267, 20, 'promo_jueves', '2 EMPANADAS + BEBIDA GRATIS'),
(268, 20, '_promo_jueves', 'field_5cae81b364d3c'),
(269, 20, 'promo_viernes', 'SOPA, SECO Y JUGO $3.000'),
(270, 20, '_promo_viernes', 'field_5cae81bf64d3d'),
(271, 20, 'promo_sado', '50% EN CLUB HOUSE'),
(272, 20, '_promo_sado', 'field_5cae81ca64d3e'),
(273, 87, 'us_title', 'Arepa con queso'),
(274, 87, '_us_title', 'field_5caac210b2b3b'),
(275, 87, 'nosotros', 'Cagua es una ciudad de Venezuela, capital del municipio Sucre (Aragua), situada a 458 msnm en el valle del río Aragua, en la parte noroeste del estado Aragua, teniendo un área aproximada de 27 km² íntegramente dentro del municipio Sucre. Está atravesada de norte a sur por la Carretera Nacional Cagua - La Villa, importante arteria vial que comunica los Valles de Aragua con los Llanos centrales, a través del abra de Villa de Cura; además, posee comunicación directa con las ciudades de Santa Cruz de Aragua y San Mateo, así como con el importante nudo comunicacional de La Encrucijada.'),
(276, 87, '_nosotros', 'field_5caac2558e5b4'),
(277, 87, 'promo_lunes', 'AREPA GRATIS'),
(278, 87, '_promo_lunes', 'field_5cae816a64d39'),
(279, 87, 'promo_martes', ''),
(280, 87, '_promo_martes', 'field_5cae819564d3a'),
(281, 87, 'promo_miercoles', ''),
(282, 87, '_promo_miercoles', 'field_5cae81a764d3b'),
(283, 87, 'promo_jueves', ''),
(284, 87, '_promo_jueves', 'field_5cae81b364d3c'),
(285, 87, 'promo_viernes', '');
INSERT INTO `kwa_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(286, 87, '_promo_viernes', 'field_5cae81bf64d3d'),
(287, 87, 'promo_sado', ''),
(288, 87, '_promo_sado', 'field_5cae81ca64d3e'),
(289, 88, 'us_title', 'Arepa con queso'),
(290, 88, '_us_title', 'field_5caac210b2b3b'),
(291, 88, 'nosotros', 'Cagua es una ciudad de Venezuela, capital del municipio Sucre (Aragua), situada a 458 msnm en el valle del río Aragua, en la parte noroeste del estado Aragua, teniendo un área aproximada de 27 km² íntegramente dentro del municipio Sucre. Está atravesada de norte a sur por la Carretera Nacional Cagua - La Villa, importante arteria vial que comunica los Valles de Aragua con los Llanos centrales, a través del abra de Villa de Cura; además, posee comunicación directa con las ciudades de Santa Cruz de Aragua y San Mateo, así como con el importante nudo comunicacional de La Encrucijada.'),
(292, 88, '_nosotros', 'field_5caac2558e5b4'),
(293, 88, 'promo_lunes', 'AREPA GRATIS'),
(294, 88, '_promo_lunes', 'field_5cae816a64d39'),
(295, 88, 'promo_martes', 'AREPA'),
(296, 88, '_promo_martes', 'field_5cae819564d3a'),
(297, 88, 'promo_miercoles', ''),
(298, 88, '_promo_miercoles', 'field_5cae81a764d3b'),
(299, 88, 'promo_jueves', ''),
(300, 88, '_promo_jueves', 'field_5cae81b364d3c'),
(301, 88, 'promo_viernes', ''),
(302, 88, '_promo_viernes', 'field_5cae81bf64d3d'),
(303, 88, 'promo_sado', ''),
(304, 88, '_promo_sado', 'field_5cae81ca64d3e'),
(305, 90, 'us_title', 'Arepa con queso'),
(306, 90, '_us_title', 'field_5caac210b2b3b'),
(307, 90, 'nosotros', 'Cagua es una ciudad de Venezuela, capital del municipio Sucre (Aragua), situada a 458 msnm en el valle del río Aragua, en la parte noroeste del estado Aragua, teniendo un área aproximada de 27 km² íntegramente dentro del municipio Sucre. Está atravesada de norte a sur por la Carretera Nacional Cagua - La Villa, importante arteria vial que comunica los Valles de Aragua con los Llanos centrales, a través del abra de Villa de Cura; además, posee comunicación directa con las ciudades de Santa Cruz de Aragua y San Mateo, así como con el importante nudo comunicacional de La Encrucijada.'),
(308, 90, '_nosotros', 'field_5caac2558e5b4'),
(309, 90, 'promo_lunes', 'BEBIDAS GRATIS'),
(310, 90, '_promo_lunes', 'field_5cae816a64d39'),
(311, 90, 'promo_martes', '2X1 EN ENSALADAS'),
(312, 90, '_promo_martes', 'field_5cae819564d3a'),
(313, 90, 'promo_miercoles', 'COMBO TEQUEÑOS + BEBIDA $4.000'),
(314, 90, '_promo_miercoles', 'field_5cae81a764d3b'),
(315, 90, 'promo_jueves', '2 EMPANADAS + BEBIDA GRATIS'),
(316, 90, '_promo_jueves', 'field_5cae81b364d3c'),
(317, 90, 'promo_viernes', 'SOPA, SECO Y JUGO $3.000'),
(318, 90, '_promo_viernes', 'field_5cae81bf64d3d'),
(319, 90, 'promo_sado', '50% EN CLUB HOUSE'),
(320, 90, '_promo_sado', 'field_5cae81ca64d3e'),
(321, 91, 'us_title', 'Arepa con queso'),
(322, 91, '_us_title', 'field_5caac210b2b3b'),
(323, 91, 'nosotros', 'Cagua es una ciudad de Venezuela, capital del municipio Sucre (Aragua), situada a 458 msnm en el valle del río Aragua, en la parte noroeste del estado Aragua, teniendo un área aproximada de 27 km² íntegramente dentro del municipio Sucre. Está atravesada de norte a sur por la Carretera Nacional Cagua - La Villa, importante arteria vial que comunica los Valles de Aragua con los Llanos centrales, a través del abra de Villa de Cura; además, posee comunicación directa con las ciudades de Santa Cruz de Aragua y San Mateo, así como con el importante nudo comunicacional de La Encrucijada.'),
(324, 91, '_nosotros', 'field_5caac2558e5b4'),
(325, 91, 'promo_lunes', 'BEBIDAS GRATIS'),
(326, 91, '_promo_lunes', 'field_5cae816a64d39'),
(327, 91, 'promo_martes', '2X1 EN ENSALADAS'),
(328, 91, '_promo_martes', 'field_5cae819564d3a'),
(329, 91, 'promo_miercoles', 'COMBO TEQUEÑOS + BEBIDA $4.000'),
(330, 91, '_promo_miercoles', 'field_5cae81a764d3b'),
(331, 91, 'promo_jueves', '2 EMPANADAS + BEBIDA GRATIS'),
(332, 91, '_promo_jueves', 'field_5cae81b364d3c'),
(333, 91, 'promo_viernes', 'SOPA, SECO Y JUGO $3.000'),
(334, 91, '_promo_viernes', 'field_5cae81bf64d3d'),
(335, 91, 'promo_sado', '50% EN CLUB HOUSE'),
(336, 91, '_promo_sado', 'field_5cae81ca64d3e'),
(337, 92, '_edit_last', '1'),
(338, 92, '_edit_lock', '1555196467:1'),
(339, 20, 'la_carta', 'LA CARTA'),
(340, 20, '_la_carta', 'field_5cae97c32cadb'),
(341, 20, 'contacto', 'CONTACTO'),
(342, 20, '_contacto', 'field_5cae97e22cadd'),
(343, 20, 'noticias', 'NOTICIAS'),
(344, 20, '_noticias', 'field_5cae97f82cade'),
(345, 97, 'us_title', 'Arepa con queso'),
(346, 97, '_us_title', 'field_5caac210b2b3b'),
(347, 97, 'nosotros', 'Cagua es una ciudad de Venezuela, capital del municipio Sucre (Aragua), situada a 458 msnm en el valle del río Aragua, en la parte noroeste del estado Aragua, teniendo un área aproximada de 27 km² íntegramente dentro del municipio Sucre. Está atravesada de norte a sur por la Carretera Nacional Cagua - La Villa, importante arteria vial que comunica los Valles de Aragua con los Llanos centrales, a través del abra de Villa de Cura; además, posee comunicación directa con las ciudades de Santa Cruz de Aragua y San Mateo, así como con el importante nudo comunicacional de La Encrucijada.'),
(348, 97, '_nosotros', 'field_5cae97da2cadc'),
(349, 97, 'promo_lunes', 'BEBIDAS GRATIS'),
(350, 97, '_promo_lunes', 'field_5cae816a64d39'),
(351, 97, 'promo_martes', '2X1 EN ENSALADAS'),
(352, 97, '_promo_martes', 'field_5cae819564d3a'),
(353, 97, 'promo_miercoles', 'COMBO TEQUEÑOS + BEBIDA $4.000'),
(354, 97, '_promo_miercoles', 'field_5cae81a764d3b'),
(355, 97, 'promo_jueves', '2 EMPANADAS + BEBIDA GRATIS'),
(356, 97, '_promo_jueves', 'field_5cae81b364d3c'),
(357, 97, 'promo_viernes', 'SOPA, SECO Y JUGO $3.000'),
(358, 97, '_promo_viernes', 'field_5cae81bf64d3d'),
(359, 97, 'promo_sado', '50% EN CLUB HOUSE'),
(360, 97, '_promo_sado', 'field_5cae81ca64d3e'),
(361, 97, 'la_carta', 'LA CARTA'),
(362, 97, '_la_carta', 'field_5cae97c32cadb'),
(363, 97, 'contacto', ''),
(364, 97, '_contacto', 'field_5cae97e22cadd'),
(365, 97, 'noticias', ''),
(366, 97, '_noticias', 'field_5cae97f82cade'),
(367, 98, 'us_title', 'Arepa con queso'),
(368, 98, '_us_title', 'field_5caac210b2b3b'),
(369, 98, 'nosotros', 'Cagua es una ciudad de Venezuela, capital del municipio Sucre (Aragua), situada a 458 msnm en el valle del río Aragua, en la parte noroeste del estado Aragua, teniendo un área aproximada de 27 km² íntegramente dentro del municipio Sucre. Está atravesada de norte a sur por la Carretera Nacional Cagua - La Villa, importante arteria vial que comunica los Valles de Aragua con los Llanos centrales, a través del abra de Villa de Cura; además, posee comunicación directa con las ciudades de Santa Cruz de Aragua y San Mateo, así como con el importante nudo comunicacional de La Encrucijada.'),
(370, 98, '_nosotros', 'field_5cae97da2cadc'),
(371, 98, 'promo_lunes', 'BEBIDAS GRATIS'),
(372, 98, '_promo_lunes', 'field_5cae816a64d39'),
(373, 98, 'promo_martes', '2X1 EN ENSALADAS'),
(374, 98, '_promo_martes', 'field_5cae819564d3a'),
(375, 98, 'promo_miercoles', 'COMBO TEQUEÑOS + BEBIDA $4.000'),
(376, 98, '_promo_miercoles', 'field_5cae81a764d3b'),
(377, 98, 'promo_jueves', '2 EMPANADAS + BEBIDA GRATIS'),
(378, 98, '_promo_jueves', 'field_5cae81b364d3c'),
(379, 98, 'promo_viernes', 'SOPA, SECO Y JUGO $3.000'),
(380, 98, '_promo_viernes', 'field_5cae81bf64d3d'),
(381, 98, 'promo_sado', '50% EN CLUB HOUSE'),
(382, 98, '_promo_sado', 'field_5cae81ca64d3e'),
(383, 98, 'la_carta', 'AREPA'),
(384, 98, '_la_carta', 'field_5cae97c32cadb'),
(385, 98, 'contacto', ''),
(386, 98, '_contacto', 'field_5cae97e22cadd'),
(387, 98, 'noticias', ''),
(388, 98, '_noticias', 'field_5cae97f82cade'),
(389, 20, 'historia', 'NOSOTROS'),
(390, 20, '_historia', 'field_5cae97da2cadc'),
(391, 99, 'us_title', 'Arepa con queso'),
(392, 99, '_us_title', 'field_5caac210b2b3b'),
(393, 99, 'nosotros', 'Cagua es una ciudad de Venezuela, capital del municipio Sucre (Aragua), situada a 458 msnm en el valle del río Aragua, en la parte noroeste del estado Aragua, teniendo un área aproximada de 27 km² íntegramente dentro del municipio Sucre. Está atravesada de norte a sur por la Carretera Nacional Cagua - La Villa, importante arteria vial que comunica los Valles de Aragua con los Llanos centrales, a través del abra de Villa de Cura; además, posee comunicación directa con las ciudades de Santa Cruz de Aragua y San Mateo, así como con el importante nudo comunicacional de La Encrucijada.'),
(394, 99, '_nosotros', 'field_5caac2558e5b4'),
(395, 99, 'promo_lunes', 'BEBIDAS GRATIS'),
(396, 99, '_promo_lunes', 'field_5cae816a64d39'),
(397, 99, 'promo_martes', '2X1 EN ENSALADAS'),
(398, 99, '_promo_martes', 'field_5cae819564d3a'),
(399, 99, 'promo_miercoles', 'COMBO TEQUEÑOS + BEBIDA $4.000'),
(400, 99, '_promo_miercoles', 'field_5cae81a764d3b'),
(401, 99, 'promo_jueves', '2 EMPANADAS + BEBIDA GRATIS'),
(402, 99, '_promo_jueves', 'field_5cae81b364d3c'),
(403, 99, 'promo_viernes', 'SOPA, SECO Y JUGO $3.000'),
(404, 99, '_promo_viernes', 'field_5cae81bf64d3d'),
(405, 99, 'promo_sado', '50% EN CLUB HOUSE'),
(406, 99, '_promo_sado', 'field_5cae81ca64d3e'),
(407, 99, 'la_carta', 'AREPA'),
(408, 99, '_la_carta', 'field_5cae97c32cadb'),
(409, 99, 'contacto', 'CONTACTO'),
(410, 99, '_contacto', 'field_5cae97e22cadd'),
(411, 99, 'noticias', 'NOTICIAS'),
(412, 99, '_noticias', 'field_5cae97f82cade'),
(413, 99, 'historia', 'NOSOTROS'),
(414, 99, '_historia', 'field_5cae97da2cadc'),
(415, 10, '_edit_last', '1'),
(416, 10, 'la_carta', ''),
(417, 10, '_la_carta', 'field_5cae97c32cadb'),
(418, 10, 'historia', ''),
(419, 10, '_historia', 'field_5cae97da2cadc'),
(420, 10, 'contacto', ''),
(421, 10, '_contacto', 'field_5cae97e22cadd'),
(422, 10, 'noticias', 'NOTICIAS'),
(423, 10, '_noticias', 'field_5cae97f82cade'),
(424, 100, 'la_carta', ''),
(425, 100, '_la_carta', 'field_5cae97c32cadb'),
(426, 100, 'historia', ''),
(427, 100, '_historia', 'field_5cae97da2cadc'),
(428, 100, 'contacto', ''),
(429, 100, '_contacto', 'field_5cae97e22cadd'),
(430, 100, 'noticias', 'NOTICIAS'),
(431, 100, '_noticias', 'field_5cae97f82cade'),
(432, 101, 'us_title', 'Arepa con queso'),
(433, 101, '_us_title', 'field_5caac210b2b3b'),
(434, 101, 'nosotros', 'Cagua es una ciudad de Venezuela, capital del municipio Sucre (Aragua), situada a 458 msnm en el valle del río Aragua, en la parte noroeste del estado Aragua, teniendo un área aproximada de 27 km² íntegramente dentro del municipio Sucre. Está atravesada de norte a sur por la Carretera Nacional Cagua - La Villa, importante arteria vial que comunica los Valles de Aragua con los Llanos centrales, a través del abra de Villa de Cura; además, posee comunicación directa con las ciudades de Santa Cruz de Aragua y San Mateo, así como con el importante nudo comunicacional de La Encrucijada.'),
(435, 101, '_nosotros', 'field_5caac2558e5b4'),
(436, 101, 'promo_lunes', 'BEBIDAS GRATIS'),
(437, 101, '_promo_lunes', 'field_5cae816a64d39'),
(438, 101, 'promo_martes', '2X1 EN ENSALADAS'),
(439, 101, '_promo_martes', 'field_5cae819564d3a'),
(440, 101, 'promo_miercoles', 'COMBO TEQUEÑOS + BEBIDA $4.000'),
(441, 101, '_promo_miercoles', 'field_5cae81a764d3b'),
(442, 101, 'promo_jueves', '2 EMPANADAS + BEBIDA GRATIS'),
(443, 101, '_promo_jueves', 'field_5cae81b364d3c'),
(444, 101, 'promo_viernes', 'SOPA, SECO Y JUGO $3.000'),
(445, 101, '_promo_viernes', 'field_5cae81bf64d3d'),
(446, 101, 'promo_sado', '50% EN CLUB HOUSE'),
(447, 101, '_promo_sado', 'field_5cae81ca64d3e'),
(448, 101, 'la_carta', 'LA CARTA'),
(449, 101, '_la_carta', 'field_5cae97c32cadb'),
(450, 101, 'contacto', 'CONTACTO'),
(451, 101, '_contacto', 'field_5cae97e22cadd'),
(452, 101, 'noticias', 'NOTICIAS'),
(453, 101, '_noticias', 'field_5cae97f82cade'),
(454, 101, 'historia', 'NOSOTROS'),
(455, 101, '_historia', 'field_5cae97da2cadc'),
(456, 102, '_edit_last', '1'),
(457, 102, '_edit_lock', '1555196612:1'),
(458, 103, '_edit_last', '1'),
(459, 103, '_thumbnail_id', '74'),
(460, 103, '_edit_lock', '1555196912:1'),
(461, 104, '_edit_last', '1'),
(462, 104, '_thumbnail_id', '49'),
(463, 104, '_edit_lock', '1555196924:1'),
(464, 105, '_edit_last', '1'),
(465, 105, '_thumbnail_id', '48'),
(466, 105, '_edit_lock', '1555196968:1'),
(467, 105, '_wp_trash_meta_status', 'publish'),
(468, 105, '_wp_trash_meta_time', '1555197123'),
(469, 105, '_wp_desired_post_slug', '105'),
(470, 104, '_wp_trash_meta_status', 'publish'),
(471, 104, '_wp_trash_meta_time', '1555197123'),
(472, 104, '_wp_desired_post_slug', '104'),
(473, 103, '_wp_trash_meta_status', 'publish'),
(474, 103, '_wp_trash_meta_time', '1555197123'),
(475, 103, '_wp_desired_post_slug', '103'),
(476, 102, '_wp_trash_meta_status', 'publish'),
(477, 102, '_wp_trash_meta_time', '1555197123'),
(478, 102, '_wp_desired_post_slug', '102'),
(479, 106, '_edit_last', '1'),
(480, 106, '_edit_lock', '1555197000:1'),
(481, 106, '_thumbnail_id', '49'),
(482, 107, '_edit_last', '1'),
(483, 107, '_edit_lock', '1555197018:1'),
(484, 107, '_thumbnail_id', '49'),
(485, 108, '_edit_last', '1'),
(486, 108, '_edit_lock', '1555197033:1'),
(487, 108, '_thumbnail_id', '47'),
(488, 109, '_edit_last', '1'),
(489, 109, '_edit_lock', '1555197097:1'),
(490, 109, '_thumbnail_id', '46'),
(491, 110, '_edit_last', '1'),
(492, 110, '_edit_lock', '1555197114:1'),
(493, 110, '_thumbnail_id', '45'),
(494, 111, '_edit_last', '1'),
(495, 111, '_edit_lock', '1555201719:1'),
(496, 111, '_thumbnail_id', '50'),
(497, 112, '_edit_lock', '1555201908:1'),
(498, 112, '_wp_trash_meta_status', 'draft'),
(499, 112, '_wp_trash_meta_time', '1555202056'),
(500, 112, '_wp_desired_post_slug', ''),
(501, 114, '_edit_lock', '1555202421:1'),
(504, 114, '_wp_trash_meta_status', 'publish'),
(505, 114, '_wp_trash_meta_time', '1555202571'),
(506, 114, '_wp_desired_post_slug', 'galeria-de-imagenes'),
(507, 116, '_edit_last', '1'),
(508, 116, '_edit_lock', '1555203200:1'),
(509, 111, '_wp_trash_meta_status', 'publish'),
(510, 111, '_wp_trash_meta_time', '1555202804'),
(511, 111, '_wp_desired_post_slug', 'dulce'),
(512, 110, '_wp_trash_meta_status', 'publish'),
(513, 110, '_wp_trash_meta_time', '1555202804'),
(514, 110, '_wp_desired_post_slug', 'ensalada'),
(515, 109, '_wp_trash_meta_status', 'publish'),
(516, 109, '_wp_trash_meta_time', '1555202804'),
(517, 109, '_wp_desired_post_slug', 'pan'),
(518, 108, '_wp_trash_meta_status', 'publish'),
(519, 108, '_wp_trash_meta_time', '1555202804'),
(520, 108, '_wp_desired_post_slug', 'delicia'),
(521, 107, '_wp_trash_meta_status', 'publish'),
(522, 107, '_wp_trash_meta_time', '1555202804'),
(523, 107, '_wp_desired_post_slug', 'las-empanadas'),
(524, 106, '_wp_trash_meta_status', 'publish'),
(525, 106, '_wp_trash_meta_time', '1555202804'),
(526, 106, '_wp_desired_post_slug', 'comida'),
(527, 118, '_edit_last', '1'),
(528, 118, '_edit_lock', '1555204085:1'),
(529, 10, 'galeria', '65'),
(530, 10, '_galeria', 'field_5cb287b8202e7'),
(531, 120, 'la_carta', ''),
(532, 120, '_la_carta', 'field_5cae97c32cadb'),
(533, 120, 'historia', ''),
(534, 120, '_historia', 'field_5cae97da2cadc'),
(535, 120, 'contacto', ''),
(536, 120, '_contacto', 'field_5cae97e22cadd'),
(537, 120, 'noticias', 'NOTICIAS'),
(538, 120, '_noticias', 'field_5cae97f82cade'),
(539, 120, 'galeria', '65'),
(540, 120, '_galeria', 'field_5cb287b8202e7'),
(541, 121, 'title', 'NextGEN Basic Thumbnails'),
(542, 121, 'module_id', 'photocrati-nextgen_basic_gallery'),
(543, 121, 'preview_image_relpath', 'photocrati-nextgen_basic_gallery#thumb_preview.jpg'),
(544, 121, 'default_source', 'galleries'),
(545, 121, 'view_order', '10000'),
(546, 121, 'name', 'photocrati-nextgen_basic_thumbnails'),
(547, 121, 'installed_at_version', '3.1.17'),
(548, 121, 'hidden_from_ui', ''),
(549, 121, 'hidden_from_igw', ''),
(550, 121, '__defaults_set', '1'),
(551, 121, 'filter', 'raw'),
(552, 121, 'entity_types', 'WyJpbWFnZSJd'),
(553, 121, 'aliases', 'WyJiYXNpY190aHVtYm5haWwiLCJiYXNpY190aHVtYm5haWxzIiwibmV4dGdlbl9iYXNpY190aHVtYm5haWxzIl0='),
(554, 121, 'id_field', 'ID'),
(555, 121, 'settings', 'eyJ1c2VfbGlnaHRib3hfZWZmZWN0Ijp0cnVlLCJkaXNwbGF5X3ZpZXciOiJkZWZhdWx0LXZpZXcucGhwIiwiaW1hZ2VzX3Blcl9wYWdlIjoiMjQiLCJudW1iZXJfb2ZfY29sdW1ucyI6MCwidGh1bWJuYWlsX3dpZHRoIjoyNDAsInRodW1ibmFpbF9oZWlnaHQiOjE2MCwic2hvd19hbGxfaW5fbGlnaHRib3giOjAsImFqYXhfcGFnaW5hdGlvbiI6MSwidXNlX2ltYWdlYnJvd3Nlcl9lZmZlY3QiOjAsInRlbXBsYXRlIjoiIiwiZGlzcGxheV9ub19pbWFnZXNfZXJyb3IiOjEsImRpc2FibGVfcGFnaW5hdGlvbiI6MCwic2hvd19zbGlkZXNob3dfbGluayI6MCwic2xpZGVzaG93X2xpbmtfdGV4dCI6IlZpZXcgU2xpZGVzaG93Iiwib3ZlcnJpZGVfdGh1bWJuYWlsX3NldHRpbmdzIjowLCJ0aHVtYm5haWxfcXVhbGl0eSI6IjEwMCIsInRodW1ibmFpbF9jcm9wIjoxLCJ0aHVtYm5haWxfd2F0ZXJtYXJrIjowLCJuZ2dfdHJpZ2dlcnNfZGlzcGxheSI6Im5ldmVyIiwiX2Vycm9ycyI6W119'),
(556, 122, 'title', 'NextGEN Basic Slideshow'),
(557, 122, 'module_id', 'photocrati-nextgen_basic_gallery'),
(558, 122, 'preview_image_relpath', 'photocrati-nextgen_basic_gallery#slideshow_preview.jpg'),
(559, 122, 'default_source', 'galleries'),
(560, 122, 'view_order', '10010'),
(561, 122, 'name', 'photocrati-nextgen_basic_slideshow'),
(562, 122, 'installed_at_version', '3.1.17'),
(563, 122, 'hidden_from_ui', ''),
(564, 122, 'hidden_from_igw', ''),
(565, 122, '__defaults_set', '1'),
(566, 122, 'filter', 'raw'),
(567, 122, 'entity_types', 'WyJpbWFnZSJd'),
(568, 122, 'aliases', 'WyJiYXNpY19zbGlkZXNob3ciLCJuZXh0Z2VuX2Jhc2ljX3NsaWRlc2hvdyJd'),
(569, 122, 'id_field', 'ID'),
(570, 122, 'settings', 'eyJ1c2VfbGlnaHRib3hfZWZmZWN0Ijp0cnVlLCJnYWxsZXJ5X3dpZHRoIjo3NTAsImdhbGxlcnlfaGVpZ2h0Ijo1MDAsInNob3dfdGh1bWJuYWlsX2xpbmsiOjAsInRodW1ibmFpbF9saW5rX3RleHQiOiJWaWV3IFRodW1ibmFpbHMiLCJ0ZW1wbGF0ZSI6IiIsImRpc3BsYXlfdmlldyI6ImRlZmF1bHQiLCJhdXRvcGxheSI6MSwicGF1c2VvbmhvdmVyIjoxLCJhcnJvd3MiOjAsImludGVydmFsIjozMDAwLCJ0cmFuc2l0aW9uX3NwZWVkIjozMDAsInRyYW5zaXRpb25fc3R5bGUiOiJmYWRlIiwibmdnX3RyaWdnZXJzX2Rpc3BsYXkiOiJuZXZlciIsIl9lcnJvcnMiOltdfQ=='),
(571, 123, 'title', 'NextGEN Basic ImageBrowser'),
(572, 123, 'preview_image_relpath', 'photocrati-nextgen_basic_imagebrowser#preview.jpg'),
(573, 123, 'default_source', 'galleries'),
(574, 123, 'view_order', '10020'),
(575, 123, 'name', 'photocrati-nextgen_basic_imagebrowser'),
(576, 123, 'installed_at_version', '3.1.17'),
(577, 123, 'hidden_from_ui', ''),
(578, 123, 'hidden_from_igw', ''),
(579, 123, '__defaults_set', '1'),
(580, 123, 'filter', 'raw'),
(581, 123, 'entity_types', 'WyJpbWFnZSJd'),
(582, 123, 'aliases', 'WyJiYXNpY19pbWFnZWJyb3dzZXIiLCJpbWFnZWJyb3dzZXIiLCJuZXh0Z2VuX2Jhc2ljX2ltYWdlYnJvd3NlciJd'),
(583, 123, 'id_field', 'ID'),
(584, 123, 'settings', 'eyJ1c2VfbGlnaHRib3hfZWZmZWN0Ijp0cnVlLCJkaXNwbGF5X3ZpZXciOiJkZWZhdWx0LXZpZXcucGhwIiwidGVtcGxhdGUiOiIiLCJhamF4X3BhZ2luYXRpb24iOiIxIiwibmdnX3RyaWdnZXJzX2Rpc3BsYXkiOiJuZXZlciIsIl9lcnJvcnMiOltdfQ=='),
(585, 124, 'title', 'NextGEN Basic SinglePic'),
(586, 124, 'preview_image_relpath', 'photocrati-nextgen_basic_singlepic#preview.gif'),
(587, 124, 'default_source', 'galleries'),
(588, 124, 'view_order', '10060'),
(589, 124, 'hidden_from_ui', '1'),
(590, 124, 'hidden_from_igw', '1'),
(591, 124, 'name', 'photocrati-nextgen_basic_singlepic'),
(592, 124, 'installed_at_version', '3.1.17'),
(593, 124, '__defaults_set', '1'),
(594, 124, 'filter', 'raw'),
(595, 124, 'entity_types', 'WyJpbWFnZSJd'),
(596, 124, 'aliases', 'WyJiYXNpY19zaW5nbGVwaWMiLCJzaW5nbGVwaWMiLCJuZXh0Z2VuX2Jhc2ljX3NpbmdsZXBpYyJd'),
(597, 124, 'id_field', 'ID'),
(598, 124, 'settings', 'eyJ1c2VfbGlnaHRib3hfZWZmZWN0Ijp0cnVlLCJ3aWR0aCI6IiIsImhlaWdodCI6IiIsIm1vZGUiOiIiLCJkaXNwbGF5X3dhdGVybWFyayI6MCwiZGlzcGxheV9yZWZsZWN0aW9uIjowLCJmbG9hdCI6IiIsImxpbmsiOiIiLCJsaW5rX3RhcmdldCI6Il9ibGFuayIsInF1YWxpdHkiOjEwMCwiY3JvcCI6MCwidGVtcGxhdGUiOiIiLCJuZ2dfdHJpZ2dlcnNfZGlzcGxheSI6Im5ldmVyIiwiX2Vycm9ycyI6W119'),
(599, 125, 'title', 'NextGEN Basic TagCloud'),
(600, 125, 'preview_image_relpath', 'photocrati-nextgen_basic_tagcloud#preview.gif'),
(601, 125, 'default_source', 'tags'),
(602, 125, 'view_order', '10100'),
(603, 125, 'name', 'photocrati-nextgen_basic_tagcloud'),
(604, 125, 'installed_at_version', '3.1.17'),
(605, 125, 'hidden_from_ui', ''),
(606, 125, 'hidden_from_igw', ''),
(607, 125, '__defaults_set', '1'),
(608, 125, 'filter', 'raw'),
(609, 125, 'entity_types', 'WyJpbWFnZSJd'),
(610, 125, 'aliases', 'WyJiYXNpY190YWdjbG91ZCIsInRhZ2Nsb3VkIiwibmV4dGdlbl9iYXNpY190YWdjbG91ZCJd'),
(611, 125, 'id_field', 'ID'),
(612, 125, 'settings', 'eyJ1c2VfbGlnaHRib3hfZWZmZWN0Ijp0cnVlLCJnYWxsZXJ5X2Rpc3BsYXlfdHlwZSI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY190aHVtYm5haWxzIiwibnVtYmVyIjo0NSwibmdnX3RyaWdnZXJzX2Rpc3BsYXkiOiJuZXZlciIsIl9lcnJvcnMiOltdfQ=='),
(613, 126, 'title', 'NextGEN Basic Compact Album'),
(614, 126, 'module_id', 'photocrati-nextgen_basic_album'),
(615, 126, 'preview_image_relpath', 'photocrati-nextgen_basic_album#compact_preview.jpg'),
(616, 126, 'default_source', 'albums'),
(617, 126, 'view_order', '10200'),
(618, 126, 'name', 'photocrati-nextgen_basic_compact_album'),
(619, 126, 'installed_at_version', '3.1.17'),
(620, 126, 'hidden_from_ui', ''),
(621, 126, 'hidden_from_igw', ''),
(622, 126, '__defaults_set', '1'),
(623, 126, 'filter', 'raw'),
(624, 126, 'entity_types', 'WyJhbGJ1bSIsImdhbGxlcnkiXQ=='),
(625, 126, 'aliases', 'WyJiYXNpY19jb21wYWN0X2FsYnVtIiwibmV4dGdlbl9iYXNpY19hbGJ1bSIsImJhc2ljX2FsYnVtX2NvbXBhY3QiLCJjb21wYWN0X2FsYnVtIl0='),
(626, 126, 'id_field', 'ID'),
(627, 126, 'settings', 'eyJ1c2VfbGlnaHRib3hfZWZmZWN0Ijp0cnVlLCJkaXNwbGF5X3ZpZXciOiJkZWZhdWx0LXZpZXcucGhwIiwiZ2FsbGVyaWVzX3Blcl9wYWdlIjowLCJlbmFibGVfYnJlYWRjcnVtYnMiOjEsImRpc2FibGVfcGFnaW5hdGlvbiI6MCwiZW5hYmxlX2Rlc2NyaXB0aW9ucyI6MCwidGVtcGxhdGUiOiIiLCJvcGVuX2dhbGxlcnlfaW5fbGlnaHRib3giOjAsIm92ZXJyaWRlX3RodW1ibmFpbF9zZXR0aW5ncyI6MSwidGh1bWJuYWlsX3F1YWxpdHkiOjEwMCwidGh1bWJuYWlsX2Nyb3AiOjEsInRodW1ibmFpbF93YXRlcm1hcmsiOjAsInRodW1ibmFpbF93aWR0aCI6MjQwLCJ0aHVtYm5haWxfaGVpZ2h0IjoxNjAsImdhbGxlcnlfZGlzcGxheV90eXBlIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX3RodW1ibmFpbHMiLCJnYWxsZXJ5X2Rpc3BsYXlfdGVtcGxhdGUiOiIiLCJuZ2dfdHJpZ2dlcnNfZGlzcGxheSI6Im5ldmVyIiwiX2Vycm9ycyI6W119'),
(628, 127, 'title', 'NextGEN Basic Extended Album'),
(629, 127, 'module_id', 'photocrati-nextgen_basic_album'),
(630, 127, 'preview_image_relpath', 'photocrati-nextgen_basic_album#extended_preview.jpg'),
(631, 127, 'default_source', 'albums'),
(632, 127, 'view_order', '10210'),
(633, 127, 'name', 'photocrati-nextgen_basic_extended_album'),
(634, 127, 'installed_at_version', '3.1.17'),
(635, 127, 'hidden_from_ui', ''),
(636, 127, 'hidden_from_igw', ''),
(637, 127, '__defaults_set', '1'),
(638, 127, 'filter', 'raw'),
(639, 127, 'entity_types', 'WyJhbGJ1bSIsImdhbGxlcnkiXQ=='),
(640, 127, 'aliases', 'WyJiYXNpY19leHRlbmRlZF9hbGJ1bSIsIm5leHRnZW5fYmFzaWNfZXh0ZW5kZWRfYWxidW0iLCJleHRlbmRlZF9hbGJ1bSJd'),
(641, 127, 'id_field', 'ID'),
(642, 127, 'settings', 'eyJ1c2VfbGlnaHRib3hfZWZmZWN0Ijp0cnVlLCJkaXNwbGF5X3ZpZXciOiJkZWZhdWx0LXZpZXcucGhwIiwiZ2FsbGVyaWVzX3Blcl9wYWdlIjowLCJlbmFibGVfYnJlYWRjcnVtYnMiOjEsImRpc2FibGVfcGFnaW5hdGlvbiI6MCwiZW5hYmxlX2Rlc2NyaXB0aW9ucyI6MCwidGVtcGxhdGUiOiIiLCJvcGVuX2dhbGxlcnlfaW5fbGlnaHRib3giOjAsIm92ZXJyaWRlX3RodW1ibmFpbF9zZXR0aW5ncyI6MSwidGh1bWJuYWlsX3F1YWxpdHkiOjEwMCwidGh1bWJuYWlsX2Nyb3AiOjEsInRodW1ibmFpbF93YXRlcm1hcmsiOjAsInRodW1ibmFpbF93aWR0aCI6MzAwLCJ0aHVtYm5haWxfaGVpZ2h0IjoyMDAsImdhbGxlcnlfZGlzcGxheV90eXBlIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX3RodW1ibmFpbHMiLCJnYWxsZXJ5X2Rpc3BsYXlfdGVtcGxhdGUiOiIiLCJuZ2dfdHJpZ2dlcnNfZGlzcGxheSI6Im5ldmVyIiwiX2Vycm9ycyI6W119'),
(757, 139, 'la_carta', ''),
(758, 139, '_la_carta', 'field_5cae97c32cadb'),
(759, 139, 'historia', ''),
(760, 139, '_historia', 'field_5cae97da2cadc'),
(761, 139, 'contacto', ''),
(762, 139, '_contacto', 'field_5cae97e22cadd'),
(763, 139, 'noticias', 'NOTICIAS'),
(764, 139, '_noticias', 'field_5cae97f82cade'),
(765, 139, 'galeria', '65'),
(766, 139, '_galeria', 'field_5cb287b8202e7'),
(767, 140, 'la_carta', ''),
(768, 140, '_la_carta', 'field_5cae97c32cadb'),
(769, 140, 'historia', ''),
(770, 140, '_historia', 'field_5cae97da2cadc'),
(771, 140, 'contacto', ''),
(772, 140, '_contacto', 'field_5cae97e22cadd'),
(773, 140, 'noticias', 'NOTICIAS'),
(774, 140, '_noticias', 'field_5cae97f82cade'),
(775, 140, 'galeria', '65'),
(776, 140, '_galeria', 'field_5cb287b8202e7'),
(787, 142, 'la_carta', ''),
(788, 142, '_la_carta', 'field_5cae97c32cadb'),
(789, 142, 'historia', ''),
(790, 142, '_historia', 'field_5cae97da2cadc'),
(791, 142, 'contacto', ''),
(792, 142, '_contacto', 'field_5cae97e22cadd'),
(793, 142, 'noticias', 'NOTICIAS'),
(794, 142, '_noticias', 'field_5cae97f82cade'),
(795, 142, 'galeria', '65'),
(796, 142, '_galeria', 'field_5cb287b8202e7'),
(915, 144, '_edit_last', '1'),
(916, 144, '_edit_lock', '1555267191:1'),
(917, 129, '__defaults_set', '1'),
(918, 129, 'filter', 'raw'),
(919, 129, 'id_field', 'ID'),
(920, 130, '__defaults_set', '1'),
(921, 130, 'filter', 'raw'),
(922, 130, 'id_field', 'ID'),
(923, 131, '__defaults_set', '1'),
(924, 131, 'filter', 'raw'),
(925, 131, 'id_field', 'ID'),
(926, 132, '__defaults_set', '1'),
(927, 132, 'filter', 'raw'),
(928, 132, 'id_field', 'ID'),
(929, 133, '__defaults_set', '1'),
(930, 133, 'filter', 'raw'),
(931, 133, 'id_field', 'ID'),
(932, 134, '__defaults_set', '1'),
(933, 134, 'filter', 'raw'),
(934, 134, 'id_field', 'ID'),
(935, 135, '__defaults_set', '1'),
(936, 135, 'filter', 'raw'),
(937, 135, 'id_field', 'ID'),
(938, 136, '__defaults_set', '1'),
(939, 136, 'filter', 'raw'),
(940, 136, 'id_field', 'ID'),
(941, 137, '__defaults_set', '1'),
(942, 137, 'filter', 'raw'),
(943, 137, 'id_field', 'ID'),
(944, 138, '__defaults_set', '1'),
(945, 138, 'filter', 'raw'),
(946, 138, 'id_field', 'ID'),
(947, 145, '__defaults_set', '1'),
(948, 145, 'filter', 'raw'),
(949, 145, 'id_field', 'ID'),
(950, 146, '__defaults_set', '1'),
(951, 146, 'filter', 'raw'),
(952, 146, 'id_field', 'ID'),
(953, 2, '_wp_trash_meta_status', 'publish'),
(954, 2, '_wp_trash_meta_time', '1555271735'),
(955, 2, '_wp_desired_post_slug', 'pagina-de-ejemplo'),
(956, 3, '_wp_trash_meta_status', 'draft'),
(957, 3, '_wp_trash_meta_time', '1555271735'),
(958, 3, '_wp_desired_post_slug', 'politica-de-privacidad'),
(959, 156, '_form', '<form>\n  <div class=\"form-group\">\n	<label for=\"exampleFormControlInput1\">Email o Apodo:</label>\n	<input type=\"email\" class=\"form-control\" id=\"exampleFormControlInput1\" placeholder=\"name@example.com\">\n  </div>\n  <div class=\"form-group\">\n	 <label for=\"exampleFormControlTextarea1\">Escribe tu experiencia o recomendación:</label>\n	<textarea class=\"form-control\" id=\"exampleFormControlTextarea1\" rows=\"5\"></textarea>\n  </div>\n  <div class=\"form-group\">\n	<label for=\"exampleFormControlFile1\">Adjunta imagen:</label>\n	<input type=\"file\" class=\"form-control-file\" id=\"exampleFormControlFile1\">\n  </div>\n  <div class=\"recentco\">\n     <h1>Comentarios recientes</h1>\n     <button type=\"button\" id=\"boton\" class=\"btn btn-dark\">Publicar</button>\n	<br><br>\n	<table class=\"table table-striped table-hover\" id=\"tabla\">\n	<tr>\n	<th>Título</th>\n	<th>Contenido</th>\n	</tr>\n </table>\n</div>\n</form>'),
(960, 156, '_mail', 'a:9:{s:6:\"active\";b:1;s:7:\"subject\";s:24:\"KWAfood \"[your-subject]\"\";s:6:\"sender\";s:22:\"KWAfood <nada@nada.cl>\";s:9:\"recipient\";s:12:\"nada@nada.cl\";s:4:\"body\";s:167:\"From: [your-name] <[your-email]>\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on KWAfood (http://localhost:8080)\";s:18:\"additional_headers\";s:0:\"\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}'),
(961, 156, '_mail_2', 'a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:24:\"KWAfood \"[your-subject]\"\";s:6:\"sender\";s:22:\"KWAfood <nada@nada.cl>\";s:9:\"recipient\";s:12:\"[your-email]\";s:4:\"body\";s:109:\"Message Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on KWAfood (http://localhost:8080)\";s:18:\"additional_headers\";s:22:\"Reply-To: nada@nada.cl\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}'),
(962, 156, '_messages', 'a:23:{s:12:\"mail_sent_ok\";s:45:\"Thank you for your message. It has been sent.\";s:12:\"mail_sent_ng\";s:71:\"There was an error trying to send your message. Please try again later.\";s:16:\"validation_error\";s:61:\"One or more fields have an error. Please check and try again.\";s:4:\"spam\";s:71:\"There was an error trying to send your message. Please try again later.\";s:12:\"accept_terms\";s:69:\"You must accept the terms and conditions before sending your message.\";s:16:\"invalid_required\";s:22:\"The field is required.\";s:16:\"invalid_too_long\";s:22:\"The field is too long.\";s:17:\"invalid_too_short\";s:23:\"The field is too short.\";s:12:\"invalid_date\";s:29:\"The date format is incorrect.\";s:14:\"date_too_early\";s:44:\"The date is before the earliest one allowed.\";s:13:\"date_too_late\";s:41:\"The date is after the latest one allowed.\";s:13:\"upload_failed\";s:46:\"There was an unknown error uploading the file.\";s:24:\"upload_file_type_invalid\";s:49:\"You are not allowed to upload files of this type.\";s:21:\"upload_file_too_large\";s:20:\"The file is too big.\";s:23:\"upload_failed_php_error\";s:38:\"There was an error uploading the file.\";s:14:\"invalid_number\";s:29:\"The number format is invalid.\";s:16:\"number_too_small\";s:47:\"The number is smaller than the minimum allowed.\";s:16:\"number_too_large\";s:46:\"The number is larger than the maximum allowed.\";s:23:\"quiz_answer_not_correct\";s:36:\"The answer to the quiz is incorrect.\";s:17:\"captcha_not_match\";s:31:\"Your entered code is incorrect.\";s:13:\"invalid_email\";s:38:\"The e-mail address entered is invalid.\";s:11:\"invalid_url\";s:19:\"The URL is invalid.\";s:11:\"invalid_tel\";s:32:\"The telephone number is invalid.\";}'),
(963, 156, '_additional_settings', ''),
(964, 156, '_locale', 'es_CL'),
(969, 157, '_edit_last', '1'),
(970, 157, '_edit_lock', '1555275171:1'),
(971, 157, '_wp_trash_meta_status', 'publish'),
(972, 157, '_wp_trash_meta_time', '1555275315'),
(973, 157, '_wp_desired_post_slug', 'group_5cb39e22c9b51'),
(974, 20, 'contacto_shortcode', '[contact-form-7 id=\"156\" title=\"Contact form 1\"]'),
(975, 20, '_contacto_shortcode', 'field_5cb39e430b4c4'),
(976, 159, 'us_title', 'Arepa con queso'),
(977, 159, '_us_title', 'field_5caac210b2b3b'),
(978, 159, 'nosotros', 'Cagua es una ciudad de Venezuela, capital del municipio Sucre (Aragua), situada a 458 msnm en el valle del río Aragua, en la parte noroeste del estado Aragua, teniendo un área aproximada de 27 km² íntegramente dentro del municipio Sucre. Está atravesada de norte a sur por la Carretera Nacional Cagua - La Villa, importante arteria vial que comunica los Valles de Aragua con los Llanos centrales, a través del abra de Villa de Cura; además, posee comunicación directa con las ciudades de Santa Cruz de Aragua y San Mateo, así como con el importante nudo comunicacional de La Encrucijada.'),
(979, 159, '_nosotros', 'field_5caac2558e5b4'),
(980, 159, 'promo_lunes', 'BEBIDAS GRATIS'),
(981, 159, '_promo_lunes', 'field_5cae816a64d39'),
(982, 159, 'promo_martes', '2X1 EN ENSALADAS'),
(983, 159, '_promo_martes', 'field_5cae819564d3a'),
(984, 159, 'promo_miercoles', 'COMBO TEQUEÑOS + BEBIDA $4.000'),
(985, 159, '_promo_miercoles', 'field_5cae81a764d3b'),
(986, 159, 'promo_jueves', '2 EMPANADAS + BEBIDA GRATIS'),
(987, 159, '_promo_jueves', 'field_5cae81b364d3c'),
(988, 159, 'promo_viernes', 'SOPA, SECO Y JUGO $3.000'),
(989, 159, '_promo_viernes', 'field_5cae81bf64d3d'),
(990, 159, 'promo_sado', '50% EN CLUB HOUSE'),
(991, 159, '_promo_sado', 'field_5cae81ca64d3e'),
(992, 159, 'la_carta', 'LA CARTA'),
(993, 159, '_la_carta', 'field_5cae97c32cadb'),
(994, 159, 'contacto', 'CONTACTO'),
(995, 159, '_contacto', 'field_5cae97e22cadd'),
(996, 159, 'noticias', 'NOTICIAS'),
(997, 159, '_noticias', 'field_5cae97f82cade'),
(998, 159, 'historia', 'NOSOTROS'),
(999, 159, '_historia', 'field_5cae97da2cadc'),
(1000, 159, 'contacto_shortcode', '[contact-form-7 id=\"156\" title=\"Contact form 1\"]'),
(1001, 159, '_contacto_shortcode', 'field_5cb39e430b4c4');

-- --------------------------------------------------------

--
-- Table structure for table `kwa_posts`
--

CREATE TABLE `kwa_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `kwa_posts`
--

INSERT INTO `kwa_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2019-03-25 20:42:34', '2019-03-25 23:42:34', '<!-- wp:paragraph -->\n<p>Bienvenido(a) a WordPress. Esta es tu primera entrada. Edítala o bórrala ¡y comienza a publiccakmkmmkm</p>\n<!-- /wp:paragraph -->', '¡Hola mundo!', '', 'publish', 'open', 'open', '', 'hola-mundo', '', '', '2019-04-07 21:23:32', '2019-04-08 00:23:32', '', 0, 'http://localhost:8080/?p=1', 0, 'post', '', 0),
(2, 1, '2019-03-25 20:42:34', '2019-03-25 23:42:34', '<!-- wp:paragraph -->\n<p>Esta es una página de ejemplo. Es diferente de una entrada de blog porque se quedará en ese lugar y se mostrará en la navegación de tu sitio (en la mayoría de los temas). La mayoría de la gente comienza con una página de acerca de que los introduce a los visitantes potenciales del sitio. Podría decir algo como esto:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>¡Hola! Soy un Mensajero en bici durante el día, aspirante a actor de noche, y este es mi sitio Web. Vivo en los Ángeles, tengo un gran perro llamado Jack, y me gustan las piñas coladas. (Y estar atrapados en la lluvia.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>... o algo así:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>La Empresa Cosas XYZ fue fundada en 1971, y ha estado proporcionando cosas de calidad al público desde entonces. Ubicado en la ciudad de Gotham, XYZ emplea a más de 2.000 personas y hace todo tipo de cosas impresionantes para la comunidad gótica.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Como nuevo usuario de WordPress, debes ir a <a href=\"http://localhost:8080/wp-admin/\">tu Dashboard</a> para eliminar esta página, y así crear nuevas páginas para su contenido. ¡Que te diviertas!</p>\n<!-- /wp:paragraph -->', 'Página de ejemplo', '', 'trash', 'closed', 'open', '', 'pagina-de-ejemplo__trashed', '', '', '2019-04-14 16:55:35', '2019-04-14 19:55:35', '', 0, 'http://localhost:8080/?page_id=2', 0, 'page', '', 0),
(3, 1, '2019-03-25 20:42:34', '2019-03-25 23:42:34', '<!-- wp:heading --><h2>Quiénes somos</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Nuestra dirección de sitio web es: http://localhost:8080.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Qué datos personales recopilamos y por qué lo recogemos</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Comentarios</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Cuando los visitantes dejan comentarios en el sitio recopilamos los datos mostrados en el formulario de comentarios, y también la dirección IP del visitante y la cadena del agente de usuario del navegador para ayudar a la detección de spam.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Se puede proporcionar una cadena anonimizada creada a partir de su dirección de correo electrónico (también denominada hash) al servicio gravatar para ver si la está utilizando. La política de privacidad del servicio gravar está disponible aquí: https://automattic.com/privacy/. Después de la aprobación de tu comentario, su imagen de perfil es visible para el público en el contexto de tu comentario.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Multimedia</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Si subes imágenes al sitio web, debes evitar cargar imágenes con datos de ubicación incrustados (EXIF GPS). Los visitantes del sitio web pueden descargar y extraer los datos de la ubicación de las imágenes en el sitio Web.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Formularios de Contacto</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Cookies</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Si deja un Comentario en nuestro sitio puedes optar por guardar tu nombre, dirección de correo electrónico y sitio web en cookies. Éstos son para tu conveniencia de modo que no tengas que rellenar tus datos otra vez cuando dejes otro comentario. Estas cookies durarán un año.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Si tienes una cuenta e inicias sesión en este sitio, configuraremos una cookie temporal para determinar si tu navegador acepta cookies. Esta cookie no contiene datos personales y se descarta al cerrar el navegador.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Cuando inicies sesión, también configuraremos varias cookies para guardar tu información de inicio de sesión y sus opciones de visualización en pantalla. Las cookies de inicio de sesión duran dos días y las cookies de opciones de pantalla duran un año. Si selecciona &quot;Recordarme&quot; en tu inicio de sesión se mantendrá durante dos semanas. Si cierra la sesión de tu cuenta, se eliminarán las cookies de inicio de sesión.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Si editas o publicas un artículo, una cookie adicional se guardará en tu navegador. Esta cookie no incluye datos personales y simplemente indica el ID de correo del artículo que acabas de editar. Expira después de 1 día.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Contenido incrustado de otros sitios web</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Los artículos en este sitio pueden incluir contenido incrustado (por ejemplo, videos, imágenes, artículos, etc.). El contenido incrustado de otros sitios web se comporta de la misma manera que si el visitante hubiera visitado el otro sitio web.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Estos sitios web pueden recopilar datos sobre ti, utilizar cookies, incrustar un seguimiento adicional de terceros y supervisar tu interacción con ese contenido incrustado, incluido el seguimiento de tu interacción con el contenido incrustado si tiene una cuenta y está conectado a dicho sitio web.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Analíticas</h3><!-- /wp:heading --><!-- wp:heading --><h2>Con quién compartimos tus datos</h2><!-- /wp:heading --><!-- wp:heading --><h2>Cuánto tiempo conservamos tus datos</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Si dejas un comentario, el comentario y sus metadatos se conservan indefinidamente. Esto es para que podamos reconocer y aprobar automáticamente cualquier comentario de seguimiento en lugar de mantenerlos en una cola de moderación.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Para los usuarios que se registren en nuestro sitio web (si los hay), también almacenamos la información personal que proporcionan en su perfil de usuario. Todos los usuarios pueden ver, editar o borrar su información personal en cualquier momento (excepto que no pueden cambiar su nombre de usuario). Los administradores de sitios web también pueden ver y editar esa información.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Qué derechos tienen sobre sus datos</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Si tienes una cuenta en este sitio, o ha dejado comentarios, puedes solicitar recibir un archivo exportado de los datos personales que tengamos sobre usted, incluyendo cualquier dato que nos haya proporcionado. También puede solicitar que borremos cualquier dato personal que mantengamos sobre usted. Esto no incluye los datos que estamos obligados a mantener para fines administrativos, legales o de seguridad.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Dónde enviamos tus datos</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Los comentarios de los visitantes se pueden verificar a través de un servicio automático de detección de spam.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Tu información de contacto</h2><!-- /wp:heading --><!-- wp:heading --><h2>Información adicional</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Cómo protegemos sus datos</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Qué procedimientos de violación de datos tenemos en marcha</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>De qué terceros recibimos datos</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Qué toma de decisiones y/o perfiles automatizados haremos con los datos del usuario</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Requisitos de divulgación regulatoria de la industria</h3><!-- /wp:heading -->', 'Políticas de Privacidad', '', 'trash', 'closed', 'open', '', 'politica-de-privacidad__trashed', '', '', '2019-04-14 16:55:35', '2019-04-14 19:55:35', '', 0, 'http://localhost:8080/?page_id=3', 0, 'page', '', 0),
(6, 1, '2019-04-07 20:07:06', '2019-04-07 23:07:06', '', 'screenshot', '', 'inherit', 'open', 'closed', '', 'screenshot', '', '', '2019-04-07 20:07:06', '2019-04-07 23:07:06', '', 0, 'http://localhost:8080/wp-content/uploads/2019/04/screenshot.png', 0, 'attachment', 'image/png', 0),
(7, 1, '2019-04-07 20:07:20', '2019-04-07 23:07:20', 'http://localhost:8080/wp-content/uploads/2019/04/cropped-screenshot.png', 'cropped-screenshot.png', '', 'inherit', 'open', 'closed', '', 'cropped-screenshot-png', '', '', '2019-04-07 20:07:20', '2019-04-07 23:07:20', '', 0, 'http://localhost:8080/wp-content/uploads/2019/04/cropped-screenshot.png', 0, 'attachment', 'image/png', 0),
(8, 1, '2019-04-07 20:07:54', '2019-04-07 23:07:54', 'http://localhost:8080/wp-content/uploads/2019/04/cropped-screenshot-1.png', 'cropped-screenshot-1.png', '', 'inherit', 'open', 'closed', '', 'cropped-screenshot-1-png', '', '', '2019-04-07 20:07:54', '2019-04-07 23:07:54', '', 0, 'http://localhost:8080/wp-content/uploads/2019/04/cropped-screenshot-1.png', 0, 'attachment', 'image/png', 0),
(9, 1, '2019-04-07 20:08:00', '2019-04-07 23:08:00', '{\n    \"blogdescription\": {\n        \"value\": \"Los sabores de Venezuela\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-04-07 23:08:00\"\n    },\n    \"site_icon\": {\n        \"value\": 8,\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-04-07 23:08:00\"\n    },\n    \"KWAfood::custom_logo\": {\n        \"value\": 7,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-04-07 23:08:00\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'c06551b6-5b47-4031-90f8-e94741f80e07', '', '', '2019-04-07 20:08:00', '2019-04-07 23:08:00', '', 0, 'http://localhost:8080/2019/04/07/c06551b6-5b47-4031-90f8-e94741f80e07/', 0, 'customize_changeset', '', 0),
(10, 1, '2019-04-07 20:13:08', '2019-04-07 23:13:08', '<!-- wp:imagely/nextgen-gallery -->\n[ngg src=\"galleries\" display=\"basic_thumbnail\" images_per_page=\"10\"]\n<!-- /wp:imagely/nextgen-gallery -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'blog', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2019-04-13 22:44:34', '2019-04-14 01:44:34', '', 0, 'http://localhost:8080/?page_id=10', 0, 'page', '', 0),
(11, 1, '2019-04-07 20:13:08', '2019-04-07 23:13:08', '<!-- wp:paragraph -->\n<p>funciona</p>\n<!-- /wp:paragraph -->', 'blog', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2019-04-07 20:13:08', '2019-04-07 23:13:08', '', 10, 'http://localhost:8080/2019/04/07/10-revision-v1/', 0, 'revision', '', 0),
(12, 1, '2019-04-07 20:50:14', '2019-04-07 23:50:14', '', 'IMG-20190204-WA0224', '', 'inherit', 'open', 'closed', '', 'img-20190204-wa0224', '', '', '2019-04-07 20:50:14', '2019-04-07 23:50:14', '', 0, 'http://localhost:8080/wp-content/uploads/2019/04/IMG-20190204-WA0224.jpg', 0, 'attachment', 'image/jpeg', 0),
(13, 1, '2019-04-07 20:50:23', '2019-04-07 23:50:23', 'http://localhost:8080/wp-content/uploads/2019/04/cropped-IMG-20190204-WA0224.jpg', 'cropped-IMG-20190204-WA0224.jpg', '', 'inherit', 'open', 'closed', '', 'cropped-img-20190204-wa0224-jpg', '', '', '2019-04-07 20:50:23', '2019-04-07 23:50:23', '', 0, 'http://localhost:8080/wp-content/uploads/2019/04/cropped-IMG-20190204-WA0224.jpg', 0, 'attachment', 'image/jpeg', 0),
(15, 1, '2019-04-07 20:52:44', '2019-04-07 23:52:44', 'http://localhost:8080/wp-content/uploads/2019/04/cropped-IMG-20190204-WA0224-1.jpg', 'cropped-IMG-20190204-WA0224-1.jpg', '', 'inherit', 'open', 'closed', '', 'cropped-img-20190204-wa0224-1-jpg', '', '', '2019-04-07 20:52:44', '2019-04-07 23:52:44', '', 0, 'http://localhost:8080/wp-content/uploads/2019/04/cropped-IMG-20190204-WA0224-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(17, 1, '2019-04-07 20:55:02', '2019-04-07 23:55:02', 'http://localhost:8080/wp-content/uploads/2019/04/cropped-IMG-20190204-WA0224-2.jpg', 'cropped-IMG-20190204-WA0224-2.jpg', '', 'inherit', 'open', 'closed', '', 'cropped-img-20190204-wa0224-2-jpg', '', '', '2019-04-07 20:55:02', '2019-04-07 23:55:02', '', 0, 'http://localhost:8080/wp-content/uploads/2019/04/cropped-IMG-20190204-WA0224-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(18, 1, '2019-04-07 20:55:15', '2019-04-07 23:55:15', '{\n    \"KWAfood::custom_logo\": {\n        \"value\": 6,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-04-07 23:55:15\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '238047b1-a4ee-4e56-906d-c4247ddf539a', '', '', '2019-04-07 20:55:15', '2019-04-07 23:55:15', '', 0, 'http://localhost:8080/2019/04/07/238047b1-a4ee-4e56-906d-c4247ddf539a/', 0, 'customize_changeset', '', 0),
(19, 1, '2019-04-07 21:09:18', '2019-04-08 00:09:18', '<!-- wp:paragraph -->\n<p>funciona como que no</p>\n<!-- /wp:paragraph -->', 'blog', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2019-04-07 21:09:18', '2019-04-08 00:09:18', '', 10, 'http://localhost:8080/2019/04/07/10-revision-v1/', 0, 'revision', '', 0),
(20, 1, '2019-04-07 21:21:34', '2019-04-08 00:21:34', '', 'home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2019-04-14 17:56:33', '2019-04-14 20:56:33', '', 0, 'http://localhost:8080/?page_id=20', 0, 'page', '', 0),
(21, 1, '2019-04-07 21:21:34', '2019-04-08 00:21:34', '', 'home', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2019-04-07 21:21:34', '2019-04-08 00:21:34', '', 20, 'http://localhost:8080/2019/04/07/20-revision-v1/', 0, 'revision', '', 0),
(22, 1, '2019-04-07 21:22:35', '2019-04-08 00:22:35', '<!-- wp:paragraph -->\n<p>Bienvenido(a) a WordPress. Esta es tu primera entrada. Edítala o bórrala ¡y comienza a publiccakmkmmkm</p>\n<!-- /wp:paragraph -->', '¡Hola mundo!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2019-04-07 21:22:35', '2019-04-08 00:22:35', '', 1, 'http://localhost:8080/2019/04/07/1-revision-v1/', 0, 'revision', '', 0),
(23, 1, '2019-04-07 21:22:37', '2019-04-08 00:22:37', '<!-- wp:paragraph -->\n<p>Bienvenido(a) a WordPress. Esta es tu primera entrada. Edítala o bórrala ¡y comienza a publiccakmkmmkm</p>\n<!-- /wp:paragraph -->', '¡Hola mundo!', '', 'inherit', 'closed', 'closed', '', '1-autosave-v1', '', '', '2019-04-07 21:22:37', '2019-04-08 00:22:37', '', 1, 'http://localhost:8080/2019/04/07/1-autosave-v1/', 0, 'revision', '', 0),
(24, 1, '2019-04-07 22:00:31', '2019-04-08 01:00:31', '<!-- wp:paragraph -->\n<p>Junto con familiares y amigos el equipo de KWAfood dio apertura a su primer local el 14 de marzo del 2019.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>El evento estuvo lleno de degustaciones deliciosas de la carta, presentando a Chile los sabores Venezolanos siempre caracterizados por una sazón inigualable.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Empanadas, tequeños, sandwich, entre otros.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Te invitamos a conocer y probar los sabores de nuestra tierra.</p>\n<!-- /wp:paragraph -->', 'Inauguración', '', 'publish', 'open', 'open', '', 'inauguracion', '', '', '2019-04-07 22:00:31', '2019-04-08 01:00:31', '', 0, 'http://localhost:8080/?p=24', 0, 'post', '', 0),
(25, 1, '2019-04-07 21:59:30', '2019-04-08 00:59:30', '', 'KWAfood', '', 'inherit', 'open', 'closed', '', 'img_20190330_142954', '', '', '2019-04-07 21:59:45', '2019-04-08 00:59:45', '', 24, 'http://localhost:8080/wp-content/uploads/2019/04/IMG_20190330_142954.jpg', 0, 'attachment', 'image/jpeg', 0),
(26, 1, '2019-04-07 22:00:31', '2019-04-08 01:00:31', '<!-- wp:paragraph -->\n<p>Junto con familiares y amigos el equipo de KWAfood dio apertura a su primer local el 14 de marzo del 2019.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>El evento estuvo lleno de degustaciones deliciosas de la carta, presentando a Chile los sabores Venezolanos siempre caracterizados por una sazón inigualable.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Empanadas, tequeños, sandwich, entre otros.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Te invitamos a conocer y probar los sabores de nuestra tierra.</p>\n<!-- /wp:paragraph -->', 'Inauguración', '', 'inherit', 'closed', 'closed', '', '24-revision-v1', '', '', '2019-04-07 22:00:31', '2019-04-08 01:00:31', '', 24, 'http://localhost:8080/2019/04/07/24-revision-v1/', 0, 'revision', '', 0),
(27, 1, '2019-04-07 22:36:11', '2019-04-08 01:36:11', '', 'PROMOCIONES', '', 'publish', 'closed', 'closed', '', 'promociones', '', '', '2019-04-08 21:42:47', '2019-04-09 00:42:47', '', 0, 'http://localhost:8080/?p=27', 1, 'nav_menu_item', '', 0),
(28, 1, '2019-04-07 22:36:11', '2019-04-08 01:36:11', '', 'LA CARTA', '', 'publish', 'closed', 'closed', '', 'la-carta', '', '', '2019-04-08 21:42:47', '2019-04-09 00:42:47', '', 0, 'http://localhost:8080/?p=28', 2, 'nav_menu_item', '', 0),
(29, 1, '2019-04-07 22:36:11', '2019-04-08 01:36:11', '', 'NOSOTROS', '', 'publish', 'closed', 'closed', '', 'nosotros', '', '', '2019-04-08 21:42:47', '2019-04-09 00:42:47', '', 0, 'http://localhost:8080/?p=29', 3, 'nav_menu_item', '', 0),
(30, 1, '2019-04-07 22:36:11', '2019-04-08 01:36:11', '', 'CONTACTOS', '', 'publish', 'closed', 'closed', '', 'contactos', '', '', '2019-04-08 21:42:47', '2019-04-09 00:42:47', '', 0, 'http://localhost:8080/?p=30', 4, 'nav_menu_item', '', 0),
(32, 1, '2019-04-07 22:41:20', '2019-04-08 01:41:20', '', 'BLOG', '', 'publish', 'closed', 'closed', '', '32', '', '', '2019-04-08 21:42:47', '2019-04-09 00:42:47', '', 0, 'http://localhost:8080/?p=32', 5, 'nav_menu_item', '', 0),
(33, 1, '2019-04-07 23:35:32', '2019-04-08 02:35:32', 'Deliciosos dedos de queso envueltos en masa de harina blanca.', 'TEQUEÑOS', '', 'publish', 'closed', 'closed', '', 'tequenos', '', '', '2019-04-08 00:14:12', '2019-04-08 03:14:12', '', 0, 'http://localhost:8080/?post_type=carta&#038;p=33', 0, 'carta', '', 0),
(34, 1, '2019-04-07 23:35:23', '2019-04-08 02:35:23', '', 'IMG_20190331_151243', '', 'inherit', 'open', 'closed', '', 'img_20190331_151243', '', '', '2019-04-07 23:35:23', '2019-04-08 02:35:23', '', 33, 'http://localhost:8080/wp-content/uploads/2019/04/IMG_20190331_151243.jpg', 0, 'attachment', 'image/jpeg', 0),
(35, 1, '2019-04-07 23:37:33', '2019-04-08 02:37:33', 'Elige entre: Carne mechada, Queso, Jamón queso, Pollo y pabellón.', 'EMPANADAS', '', 'publish', 'closed', 'closed', '', 'empanadas', '', '', '2019-04-08 00:14:02', '2019-04-08 03:14:02', '', 0, 'http://localhost:8080/?post_type=carta&#038;p=35', 0, 'carta', '', 0),
(36, 1, '2019-04-07 23:37:24', '2019-04-08 02:37:24', '', 'empanadas', '', 'inherit', 'open', 'closed', '', 'empanadas', '', '', '2019-04-07 23:37:24', '2019-04-08 02:37:24', '', 35, 'http://localhost:8080/wp-content/uploads/2019/04/empanadas.jpg', 0, 'attachment', 'image/jpeg', 0),
(37, 1, '2019-04-07 23:38:51', '2019-04-08 02:38:51', 'Relleno con pollo, lechuga, tomates, tocinera, aderezo.\r\n\r\n&nbsp;', 'CLUB HOUSE', '', 'publish', 'closed', 'closed', '', 'club-house', '', '', '2019-04-08 00:13:47', '2019-04-08 03:13:47', '', 0, 'http://localhost:8080/?post_type=carta&#038;p=37', 0, 'carta', '', 0),
(38, 1, '2019-04-07 23:38:44', '2019-04-08 02:38:44', '', 'clubhouse', '', 'inherit', 'open', 'closed', '', 'clubhouse', '', '', '2019-04-07 23:38:44', '2019-04-08 02:38:44', '', 37, 'http://localhost:8080/wp-content/uploads/2019/04/clubhouse.jpg', 0, 'attachment', 'image/jpeg', 0),
(39, 1, '2019-04-07 23:55:53', '2019-04-08 02:55:53', 'La especialidad de la casa.\r\n\r\n&nbsp;', 'SANDWICH CHEDDAR', '', 'publish', 'closed', 'closed', '', 'sandwich-cheddar', '', '', '2019-04-08 00:13:30', '2019-04-08 03:13:30', '', 0, 'http://localhost:8080/?post_type=carta&#038;p=39', 0, 'carta', '', 0),
(40, 1, '2019-04-07 23:40:13', '2019-04-08 02:40:13', '', 'IMG_20190331_151226', '', 'inherit', 'open', 'closed', '', 'img_20190331_151226', '', '', '2019-04-07 23:40:13', '2019-04-08 02:40:13', '', 39, 'http://localhost:8080/wp-content/uploads/2019/04/IMG_20190331_151226.jpg', 0, 'attachment', 'image/jpeg', 0),
(41, 1, '2019-04-07 23:57:00', '2019-04-08 02:57:00', 'La más variada selección de ensaladas con los ingredientes más frescos.', 'ENSALADAS', '', 'publish', 'closed', 'closed', '', 'ensaladas', '', '', '2019-04-08 00:13:20', '2019-04-08 03:13:20', '', 0, 'http://localhost:8080/?post_type=carta&#038;p=41', 0, 'carta', '', 0),
(42, 1, '2019-04-07 23:56:49', '2019-04-08 02:56:49', '', 'cesar', '', 'inherit', 'open', 'closed', '', 'cesar', '', '', '2019-04-07 23:56:49', '2019-04-08 02:56:49', '', 41, 'http://localhost:8080/wp-content/uploads/2019/04/cesar.jpg', 0, 'attachment', 'image/jpeg', 0),
(43, 1, '2019-04-07 23:57:59', '2019-04-08 02:57:59', 'Rico dulce tradicional, rollos de chancaca.', 'GOLFEADOS', '', 'publish', 'closed', 'closed', '', 'golfeados', '', '', '2019-04-08 00:08:38', '2019-04-08 03:08:38', '', 0, 'http://localhost:8080/?post_type=carta&#038;p=43', 0, 'carta', '', 0),
(44, 1, '2019-04-07 23:57:37', '2019-04-08 02:57:37', '', 'golfeados', '', 'inherit', 'open', 'closed', '', 'golfeados', '', '', '2019-04-07 23:57:37', '2019-04-08 02:57:37', '', 43, 'http://localhost:8080/wp-content/uploads/2019/04/golfeados.jpg', 0, 'attachment', 'image/jpeg', 0),
(45, 1, '2019-04-08 00:08:31', '2019-04-08 03:08:31', '', 'golfeados', '', 'inherit', 'open', 'closed', '', 'golfeados-2', '', '', '2019-04-08 00:08:31', '2019-04-08 03:08:31', '', 43, 'http://localhost:8080/wp-content/uploads/2019/04/golfeados-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(46, 1, '2019-04-08 00:09:00', '2019-04-08 03:09:00', '', 'cesar', '', 'inherit', 'open', 'closed', '', 'cesar-2', '', '', '2019-04-08 00:09:00', '2019-04-08 03:09:00', '', 41, 'http://localhost:8080/wp-content/uploads/2019/04/cesar-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(47, 1, '2019-04-08 00:09:30', '2019-04-08 03:09:30', '', 'sandvege', '', 'inherit', 'open', 'closed', '', 'sandvege', '', '', '2019-04-08 00:09:30', '2019-04-08 03:09:30', '', 39, 'http://localhost:8080/wp-content/uploads/2019/04/sandvege.jpg', 0, 'attachment', 'image/jpeg', 0),
(48, 1, '2019-04-08 00:10:00', '2019-04-08 03:10:00', '', 'clubhouse', '', 'inherit', 'open', 'closed', '', 'clubhouse-2', '', '', '2019-04-08 00:10:00', '2019-04-08 03:10:00', '', 37, 'http://localhost:8080/wp-content/uploads/2019/04/clubhouse-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(49, 1, '2019-04-08 00:10:23', '2019-04-08 03:10:23', '', 'empanadas', '', 'inherit', 'open', 'closed', '', 'empanadas-2', '', '', '2019-04-08 00:10:23', '2019-04-08 03:10:23', '', 35, 'http://localhost:8080/wp-content/uploads/2019/04/empanadas-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(50, 1, '2019-04-08 00:10:50', '2019-04-08 03:10:50', '', 'tequeños', '', 'inherit', 'open', 'closed', '', 'tequenos-2', '', '', '2019-04-08 00:10:50', '2019-04-08 03:10:50', '', 33, 'http://localhost:8080/wp-content/uploads/2019/04/tequeños.jpg', 0, 'attachment', 'image/jpeg', 0),
(52, 1, '2019-04-08 00:30:13', '2019-04-08 03:30:13', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:4:\"page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:2:\"20\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";a:14:{i:0;s:9:\"permalink\";i:1;s:11:\"the_content\";i:2;s:7:\"excerpt\";i:3;s:10:\"discussion\";i:4;s:8:\"comments\";i:5;s:9:\"revisions\";i:6;s:4:\"slug\";i:7;s:6:\"author\";i:8;s:6:\"format\";i:9;s:15:\"page_attributes\";i:10;s:14:\"featured_image\";i:11;s:10:\"categories\";i:12;s:4:\"tags\";i:13;s:15:\"send-trackbacks\";}s:11:\"description\";s:0:\"\";}', 'Home', 'home', 'publish', 'closed', 'closed', '', 'group_5caac03a7884b', '', '', '2019-04-14 17:56:03', '2019-04-14 20:56:03', '', 0, 'http://localhost:8080/?post_type=acf-field-group&#038;p=52', -1, 'acf-field-group', '', 0),
(54, 1, '2019-04-08 00:38:00', '2019-04-08 03:38:00', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'us_title', 'us_title', 'publish', 'closed', 'closed', '', 'field_5caac210b2b3b', '', '', '2019-04-08 00:39:15', '2019-04-08 03:39:15', '', 52, 'http://localhost:8080/?post_type=acf-field&#038;p=54', 0, 'acf-field', '', 0),
(56, 1, '2019-04-08 00:39:15', '2019-04-08 03:39:15', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'nosotros', 'nosotros', 'publish', 'closed', 'closed', '', 'field_5caac2558e5b4', '', '', '2019-04-08 00:39:15', '2019-04-08 03:39:15', '', 52, 'http://localhost:8080/?post_type=acf-field&p=56', 1, 'acf-field', '', 0),
(57, 1, '2019-04-08 00:42:20', '2019-04-08 03:42:20', '', 'home', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2019-04-08 00:42:20', '2019-04-08 03:42:20', '', 20, 'http://localhost:8080/2019/04/08/20-revision-v1/', 0, 'revision', '', 0),
(58, 1, '2019-04-08 00:44:06', '2019-04-08 03:44:06', '', 'home', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2019-04-08 00:44:06', '2019-04-08 03:44:06', '', 20, 'http://localhost:8080/2019/04/08/20-revision-v1/', 0, 'revision', '', 0),
(59, 1, '2019-04-08 20:40:23', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-04-08 20:40:23', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/?p=59', 1, 'nav_menu_item', '', 0),
(60, 1, '2019-04-08 20:40:23', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-04-08 20:40:23', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/?p=60', 1, 'nav_menu_item', '', 0),
(61, 1, '2019-04-08 20:40:23', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-04-08 20:40:23', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/?p=61', 1, 'nav_menu_item', '', 0),
(62, 1, '2019-04-09 23:55:06', '2019-04-10 02:55:06', 'AREPAS', '2x1', '', 'publish', 'closed', 'closed', '', '2x1', '', '', '2019-04-10 00:09:11', '2019-04-10 03:09:11', '', 0, 'http://localhost:8080/?post_type=promos&#038;p=62', 0, 'promos', '', 0),
(63, 1, '2019-04-09 23:54:27', '2019-04-10 02:54:27', '', 'jueves', '', 'inherit', 'open', 'closed', '', 'jueves', '', '', '2019-04-09 23:54:27', '2019-04-10 02:54:27', '', 62, 'http://localhost:8080/wp-content/uploads/2019/04/jueves.png', 0, 'attachment', 'image/png', 0),
(64, 1, '2019-04-09 23:54:28', '2019-04-10 02:54:28', '', 'lunes', '', 'inherit', 'open', 'closed', '', 'lunes', '', '', '2019-04-09 23:54:28', '2019-04-10 02:54:28', '', 62, 'http://localhost:8080/wp-content/uploads/2019/04/lunes.png', 0, 'attachment', 'image/png', 0),
(65, 1, '2019-04-09 23:54:28', '2019-04-10 02:54:28', '', 'martes', '', 'inherit', 'open', 'closed', '', 'martes', '', '', '2019-04-09 23:54:28', '2019-04-10 02:54:28', '', 62, 'http://localhost:8080/wp-content/uploads/2019/04/martes.png', 0, 'attachment', 'image/png', 0),
(66, 1, '2019-04-09 23:54:28', '2019-04-10 02:54:28', '', 'miercoles', '', 'inherit', 'open', 'closed', '', 'miercoles', '', '', '2019-04-09 23:54:28', '2019-04-10 02:54:28', '', 62, 'http://localhost:8080/wp-content/uploads/2019/04/miercoles.png', 0, 'attachment', 'image/png', 0),
(67, 1, '2019-04-09 23:54:29', '2019-04-10 02:54:29', '', 'sabadom', '', 'inherit', 'open', 'closed', '', 'sabadom', '', '', '2019-04-09 23:54:29', '2019-04-10 02:54:29', '', 62, 'http://localhost:8080/wp-content/uploads/2019/04/sabadom.png', 0, 'attachment', 'image/png', 0),
(68, 1, '2019-04-09 23:54:29', '2019-04-10 02:54:29', '', 'viernes', '', 'inherit', 'open', 'closed', '', 'viernes', '', '', '2019-04-09 23:54:29', '2019-04-10 02:54:29', '', 62, 'http://localhost:8080/wp-content/uploads/2019/04/viernes.png', 0, 'attachment', 'image/png', 0),
(69, 1, '2019-04-10 00:19:33', '2019-04-10 03:19:33', 'GRATIS', 'BEBIDAS', '', 'publish', 'closed', 'closed', '', 'bebidas', '', '', '2019-04-10 00:19:33', '2019-04-10 03:19:33', '', 0, 'http://localhost:8080/?post_type=promos&#038;p=69', 0, 'promos', '', 0),
(70, 1, '2019-04-10 00:20:02', '2019-04-10 03:20:02', 'SANDWICH + BEBIDA', '$2.600', '', 'publish', 'closed', 'closed', '', '2-600', '', '', '2019-04-10 00:20:02', '2019-04-10 03:20:02', '', 0, 'http://localhost:8080/?post_type=promos&#038;p=70', 0, 'promos', '', 0),
(71, 1, '2019-04-10 00:20:32', '2019-04-10 03:20:32', '10 TEQUEÑOS', '$4.000', '', 'publish', 'closed', 'closed', '', '4-000', '', '', '2019-04-10 00:20:32', '2019-04-10 03:20:32', '', 0, 'http://localhost:8080/?post_type=promos&#038;p=71', 0, 'promos', '', 0),
(72, 1, '2019-04-10 00:20:41', '2019-04-10 03:20:41', 'SOPA, SECO Y JUGO', '$3.000', '', 'publish', 'closed', 'closed', '', '2x1-2', '', '', '2019-04-10 00:21:05', '2019-04-10 03:21:05', '', 0, 'http://localhost:8080/?post_type=promos&#038;p=72', 0, 'promos', '', 0),
(73, 1, '2019-04-10 20:37:56', '2019-04-10 23:37:56', '<!-- wp:paragraph -->\n<p>Nos hemos caracterizado por tener una carta variada, en ella se concentra los distintos sabores de Cagua y el estado Aragua en General.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Empanadas, Sandwiches, pequeños y ensaladas con las mezclas deseadas.</p>\n<!-- /wp:paragraph -->', 'Nuestra Carta', '', 'publish', 'open', 'open', '', 'nuestra-carta', '', '', '2019-04-10 20:37:56', '2019-04-10 23:37:56', '', 0, 'http://localhost:8080/?p=73', 0, 'post', '', 0),
(74, 1, '2019-04-10 20:37:49', '2019-04-10 23:37:49', '', 'IMG-20190321-WA0012', '', 'inherit', 'open', 'closed', '', 'img-20190321-wa0012', '', '', '2019-04-10 20:37:49', '2019-04-10 23:37:49', '', 73, 'http://localhost:8080/wp-content/uploads/2019/04/IMG-20190321-WA0012.jpg', 0, 'attachment', 'image/jpeg', 0),
(75, 1, '2019-04-10 20:37:56', '2019-04-10 23:37:56', '<!-- wp:paragraph -->\n<p>Nos hemos caracterizado por tener una carta variada, en ella se concentra los distintos sabores de Cagua y el estado Aragua en General.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Empanadas, Sandwiches, pequeños y ensaladas con las mezclas deseadas.</p>\n<!-- /wp:paragraph -->', 'Nuestra Carta', '', 'inherit', 'closed', 'closed', '', '73-revision-v1', '', '', '2019-04-10 20:37:56', '2019-04-10 23:37:56', '', 73, 'http://localhost:8080/2019/04/10/73-revision-v1/', 0, 'revision', '', 0),
(76, 1, '2019-04-10 20:53:53', '2019-04-10 23:53:53', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:4:\"page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:2:\"20\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'PROMOS', 'promos', 'publish', 'closed', 'closed', '', 'group_5cae81419cc59', '', '', '2019-04-10 21:13:50', '2019-04-11 00:13:50', '', 0, 'http://localhost:8080/?post_type=acf-field-group&#038;p=76', 0, 'acf-field-group', '', 0),
(77, 1, '2019-04-10 20:53:53', '2019-04-10 23:53:53', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Promoción Lunes', 'promo_lunes', 'publish', 'closed', 'closed', '', 'field_5cae816a64d39', '', '', '2019-04-10 21:13:03', '2019-04-11 00:13:03', '', 76, 'http://localhost:8080/?post_type=acf-field&#038;p=77', 0, 'acf-field', '', 0),
(78, 1, '2019-04-10 20:53:53', '2019-04-10 23:53:53', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Promoción Martes', 'promo_martes', 'publish', 'closed', 'closed', '', 'field_5cae819564d3a', '', '', '2019-04-10 20:53:53', '2019-04-10 23:53:53', '', 76, 'http://localhost:8080/?post_type=acf-field&p=78', 1, 'acf-field', '', 0),
(79, 1, '2019-04-10 20:53:53', '2019-04-10 23:53:53', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Promoción Miércoles', 'promo_miercoles', 'publish', 'closed', 'closed', '', 'field_5cae81a764d3b', '', '', '2019-04-10 20:53:53', '2019-04-10 23:53:53', '', 76, 'http://localhost:8080/?post_type=acf-field&p=79', 2, 'acf-field', '', 0),
(80, 1, '2019-04-10 20:53:53', '2019-04-10 23:53:53', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Promoción Jueves', 'promo_jueves', 'publish', 'closed', 'closed', '', 'field_5cae81b364d3c', '', '', '2019-04-10 20:53:53', '2019-04-10 23:53:53', '', 76, 'http://localhost:8080/?post_type=acf-field&p=80', 3, 'acf-field', '', 0),
(81, 1, '2019-04-10 20:53:53', '2019-04-10 23:53:53', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Promoción Viernes', 'promo_viernes', 'publish', 'closed', 'closed', '', 'field_5cae81bf64d3d', '', '', '2019-04-10 20:53:53', '2019-04-10 23:53:53', '', 76, 'http://localhost:8080/?post_type=acf-field&p=81', 4, 'acf-field', '', 0),
(82, 1, '2019-04-10 20:53:53', '2019-04-10 23:53:53', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Promoción Sab y Dom', 'promo_sado', 'publish', 'closed', 'closed', '', 'field_5cae81ca64d3e', '', '', '2019-04-10 21:13:23', '2019-04-11 00:13:23', '', 76, 'http://localhost:8080/?post_type=acf-field&#038;p=82', 5, 'acf-field', '', 0),
(83, 1, '2019-04-10 20:56:49', '2019-04-10 23:56:49', '', 'Promociones', '', 'trash', 'open', 'open', '', 'promociones__trashed', '', '', '2019-04-10 20:57:23', '2019-04-10 23:57:23', '', 0, 'http://localhost:8080/?p=83', 0, 'post', '', 0),
(84, 1, '2019-04-10 20:56:49', '2019-04-10 23:56:49', '', 'Promociones', '', 'inherit', 'closed', 'closed', '', '83-revision-v1', '', '', '2019-04-10 20:56:49', '2019-04-10 23:56:49', '', 83, 'http://localhost:8080/2019/04/10/83-revision-v1/', 0, 'revision', '', 0),
(85, 1, '2019-04-10 20:56:50', '2019-04-10 23:56:50', '', 'Promociones', '', 'inherit', 'closed', 'closed', '', '83-revision-v1', '', '', '2019-04-10 20:56:50', '2019-04-10 23:56:50', '', 83, 'http://localhost:8080/2019/04/10/83-revision-v1/', 0, 'revision', '', 0),
(86, 1, '2019-04-10 21:03:00', '2019-04-11 00:03:00', 'Arepas!', 'Borrador automático', '', 'publish', 'closed', 'closed', '', 'borrador-automatico', '', '', '2019-04-13 21:56:07', '2019-04-14 00:56:07', '', 0, 'http://localhost:8080/?post_type=promo&#038;p=86', 0, 'promo', '', 0),
(87, 1, '2019-04-10 21:14:12', '2019-04-11 00:14:12', '', 'home', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2019-04-10 21:14:12', '2019-04-11 00:14:12', '', 20, 'http://localhost:8080/2019/04/10/20-revision-v1/', 0, 'revision', '', 0),
(88, 1, '2019-04-10 21:38:01', '2019-04-11 00:38:01', '', 'home', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2019-04-10 21:38:01', '2019-04-11 00:38:01', '', 20, 'http://localhost:8080/2019/04/10/20-revision-v1/', 0, 'revision', '', 0),
(89, 1, '2019-04-10 21:38:13', '0000-00-00 00:00:00', '', 'Borrador automático', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2019-04-10 21:38:13', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/?post_type=promo&p=89', 0, 'promo', '', 0),
(90, 1, '2019-04-10 21:45:30', '2019-04-11 00:45:30', '', 'home', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2019-04-10 21:45:30', '2019-04-11 00:45:30', '', 20, 'http://localhost:8080/2019/04/10/20-revision-v1/', 0, 'revision', '', 0),
(91, 1, '2019-04-10 21:45:33', '2019-04-11 00:45:33', '', 'home', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2019-04-10 21:45:33', '2019-04-11 00:45:33', '', 20, 'http://localhost:8080/2019/04/10/20-revision-v1/', 0, 'revision', '', 0),
(92, 1, '2019-04-10 22:30:08', '2019-04-11 01:30:08', 'a:7:{s:8:\"location\";a:1:{i:0;a:2:{i:0;a:3:{s:5:\"param\";s:4:\"page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:2:\"10\";}i:1;a:3:{s:5:\"param\";s:4:\"page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:2:\"20\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'TITULOS', 'titulos', 'publish', 'closed', 'closed', '', 'group_5cae97b8cbabd', '', '', '2019-04-13 19:52:26', '2019-04-13 22:52:26', '', 0, 'http://localhost:8080/?post_type=acf-field-group&#038;p=92', 0, 'acf-field-group', '', 0),
(93, 1, '2019-04-10 22:30:08', '2019-04-11 01:30:08', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'La Carta', 'la_carta', 'publish', 'closed', 'closed', '', 'field_5cae97c32cadb', '', '', '2019-04-10 22:30:08', '2019-04-11 01:30:08', '', 92, 'http://localhost:8080/?post_type=acf-field&p=93', 0, 'acf-field', '', 0),
(94, 1, '2019-04-10 22:30:08', '2019-04-11 01:30:08', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Historia', 'historia', 'publish', 'closed', 'closed', '', 'field_5cae97da2cadc', '', '', '2019-04-10 22:32:07', '2019-04-11 01:32:07', '', 92, 'http://localhost:8080/?post_type=acf-field&#038;p=94', 1, 'acf-field', '', 0),
(95, 1, '2019-04-10 22:30:08', '2019-04-11 01:30:08', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Contacto', 'contacto', 'publish', 'closed', 'closed', '', 'field_5cae97e22cadd', '', '', '2019-04-10 22:30:08', '2019-04-11 01:30:08', '', 92, 'http://localhost:8080/?post_type=acf-field&p=95', 2, 'acf-field', '', 0),
(96, 1, '2019-04-10 22:30:08', '2019-04-11 01:30:08', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Noticias', 'news', 'publish', 'closed', 'closed', '', 'field_5cae97f82cade', '', '', '2019-04-13 19:52:13', '2019-04-13 22:52:13', '', 92, 'http://localhost:8080/?post_type=acf-field&#038;p=96', 3, 'acf-field', '', 0),
(97, 1, '2019-04-10 22:31:17', '2019-04-11 01:31:17', '', 'home', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2019-04-10 22:31:17', '2019-04-11 01:31:17', '', 20, 'http://localhost:8080/2019/04/10/20-revision-v1/', 0, 'revision', '', 0),
(98, 1, '2019-04-10 22:31:29', '2019-04-11 01:31:29', '', 'home', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2019-04-10 22:31:29', '2019-04-11 01:31:29', '', 20, 'http://localhost:8080/2019/04/10/20-revision-v1/', 0, 'revision', '', 0),
(99, 1, '2019-04-10 22:32:30', '2019-04-11 01:32:30', '', 'home', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2019-04-10 22:32:30', '2019-04-11 01:32:30', '', 20, 'http://localhost:8080/2019/04/10/20-revision-v1/', 0, 'revision', '', 0),
(100, 1, '2019-04-13 19:48:11', '2019-04-13 22:48:11', '<!-- wp:paragraph -->\n<p>funciona como que no</p>\n<!-- /wp:paragraph -->', 'blog', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2019-04-13 19:48:11', '2019-04-13 22:48:11', '', 10, 'http://localhost:8080/2019/04/13/10-revision-v1/', 0, 'revision', '', 0),
(101, 1, '2019-04-13 19:48:26', '2019-04-13 22:48:26', '', 'home', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2019-04-13 19:48:26', '2019-04-13 22:48:26', '', 20, 'http://localhost:8080/2019/04/13/20-revision-v1/', 0, 'revision', '', 0),
(102, 1, '2019-04-13 20:04:09', '2019-04-13 23:04:09', '<img class=\"alignnone size-medium wp-image-74\" src=\"http://localhost:8080/wp-content/uploads/2019/04/IMG-20190321-WA0012-199x300.jpg\" alt=\"\" width=\"199\" height=\"300\" />', '', '', 'trash', 'closed', 'closed', '', '102__trashed', '', '', '2019-04-13 20:12:03', '2019-04-13 23:12:03', '', 0, 'http://localhost:8080/?post_type=imagenes&#038;p=102', 0, 'imagenes', '', 0),
(103, 1, '2019-04-13 20:06:12', '2019-04-13 23:06:12', '', '', '', 'trash', 'closed', 'closed', '', '103__trashed', '', '', '2019-04-13 20:12:03', '2019-04-13 23:12:03', '', 0, 'http://localhost:8080/?post_type=imagenes&#038;p=103', 0, 'imagenes', '', 0),
(104, 1, '2019-04-13 20:11:06', '2019-04-13 23:11:06', '', '', '', 'trash', 'closed', 'closed', '', '104__trashed', '', '', '2019-04-13 20:12:03', '2019-04-13 23:12:03', '', 0, 'http://localhost:8080/?post_type=imagenes&#038;p=104', 0, 'imagenes', '', 0),
(105, 1, '2019-04-13 20:11:17', '2019-04-13 23:11:17', '', '', '', 'trash', 'closed', 'closed', '', '105__trashed', '', '', '2019-04-13 20:12:03', '2019-04-13 23:12:03', '', 0, 'http://localhost:8080/?post_type=imagenes&#038;p=105', 0, 'imagenes', '', 0),
(106, 1, '2019-04-13 20:12:23', '2019-04-13 23:12:23', '', 'Comida', '', 'trash', 'closed', 'closed', '', 'comida__trashed', '', '', '2019-04-13 21:46:44', '2019-04-14 00:46:44', '', 0, 'http://localhost:8080/?post_type=imagenes&#038;p=106', 0, 'imagenes', '', 0),
(107, 1, '2019-04-13 20:12:31', '2019-04-13 23:12:31', '', 'las empanadas', '', 'trash', 'closed', 'closed', '', 'las-empanadas__trashed', '', '', '2019-04-13 21:46:44', '2019-04-14 00:46:44', '', 0, 'http://localhost:8080/?post_type=imagenes&#038;p=107', 0, 'imagenes', '', 0),
(108, 1, '2019-04-13 20:12:56', '2019-04-13 23:12:56', '', 'delicia', '', 'trash', 'closed', 'closed', '', 'delicia__trashed', '', '', '2019-04-13 21:46:44', '2019-04-14 00:46:44', '', 0, 'http://localhost:8080/?post_type=imagenes&#038;p=108', 0, 'imagenes', '', 0),
(109, 1, '2019-04-13 20:13:02', '2019-04-13 23:13:02', '', 'pan', '', 'trash', 'closed', 'closed', '', 'pan__trashed', '', '', '2019-04-13 21:46:44', '2019-04-14 00:46:44', '', 0, 'http://localhost:8080/?post_type=imagenes&#038;p=109', 0, 'imagenes', '', 0),
(110, 1, '2019-04-13 20:14:15', '2019-04-13 23:14:15', '', 'ensalada', '', 'trash', 'closed', 'closed', '', 'ensalada__trashed', '', '', '2019-04-13 21:46:44', '2019-04-14 00:46:44', '', 0, 'http://localhost:8080/?post_type=imagenes&#038;p=110', 0, 'imagenes', '', 0),
(111, 1, '2019-04-13 20:14:34', '2019-04-13 23:14:34', '', 'dulce', '', 'trash', 'closed', 'closed', '', 'dulce__trashed', '', '', '2019-04-13 21:46:44', '2019-04-14 00:46:44', '', 0, 'http://localhost:8080/?post_type=imagenes&#038;p=111', 0, 'imagenes', '', 0),
(112, 1, '2019-04-13 21:34:16', '2019-04-14 00:34:16', '<!-- wp:image -->\n<figure class=\"wp-block-image\"><img alt=\"\"/></figure>\n<!-- /wp:image -->', 'Articulo con Galeria', '', 'trash', 'open', 'open', '', '__trashed', '', '', '2019-04-13 21:34:16', '2019-04-14 00:34:16', '', 0, 'http://localhost:8080/?p=112', 0, 'post', '', 0),
(113, 1, '2019-04-13 21:34:16', '2019-04-14 00:34:16', '<!-- wp:image -->\n<figure class=\"wp-block-image\"><img alt=\"\"/></figure>\n<!-- /wp:image -->', 'Articulo con Galeria', '', 'inherit', 'closed', 'closed', '', '112-revision-v1', '', '', '2019-04-13 21:34:16', '2019-04-14 00:34:16', '', 112, 'http://localhost:8080/2019/04/13/112-revision-v1/', 0, 'revision', '', 0),
(114, 1, '2019-04-13 21:40:01', '2019-04-14 00:40:01', '<!-- wp:gallery {\"ids\":[74,50,49,48,42,44,46,47,38,40,36,34,25]} -->\n<ul class=\"wp-block-gallery columns-3 is-cropped\"><li class=\"blocks-gallery-item\"><figure><img src=\"http://localhost:8080/wp-content/uploads/2019/04/IMG-20190321-WA0012-678x1024.jpg\" alt=\"\" data-id=\"74\" data-link=\"http://localhost:8080/2019/04/10/nuestra-carta/img-20190321-wa0012/\" class=\"wp-image-74\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://localhost:8080/wp-content/uploads/2019/04/tequeños.jpg\" alt=\"\" data-id=\"50\" data-link=\"http://localhost:8080/carta/tequenos/tequenos-2/\" class=\"wp-image-50\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://localhost:8080/wp-content/uploads/2019/04/empanadas-1.jpg\" alt=\"\" data-id=\"49\" data-link=\"http://localhost:8080/carta/empanadas/empanadas-2/\" class=\"wp-image-49\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://localhost:8080/wp-content/uploads/2019/04/clubhouse-1.jpg\" alt=\"\" data-id=\"48\" data-link=\"http://localhost:8080/carta/club-house/clubhouse-2/\" class=\"wp-image-48\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://localhost:8080/wp-content/uploads/2019/04/cesar-1024x678.jpg\" alt=\"\" data-id=\"42\" data-link=\"http://localhost:8080/carta/ensaladas/cesar/\" class=\"wp-image-42\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://localhost:8080/wp-content/uploads/2019/04/golfeados-1024x1024.jpg\" alt=\"\" data-id=\"44\" data-link=\"http://localhost:8080/carta/golfeados/golfeados/\" class=\"wp-image-44\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://localhost:8080/wp-content/uploads/2019/04/cesar-1.jpg\" alt=\"\" data-id=\"46\" data-link=\"http://localhost:8080/carta/ensaladas/cesar-2/\" class=\"wp-image-46\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://localhost:8080/wp-content/uploads/2019/04/sandvege.jpg\" alt=\"\" data-id=\"47\" data-link=\"http://localhost:8080/carta/sandwich-cheddar/sandvege/\" class=\"wp-image-47\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://localhost:8080/wp-content/uploads/2019/04/clubhouse-1024x672.jpg\" alt=\"\" data-id=\"38\" data-link=\"http://localhost:8080/carta/club-house/clubhouse/\" class=\"wp-image-38\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://localhost:8080/wp-content/uploads/2019/04/IMG_20190331_151226-1024x768.jpg\" alt=\"\" data-id=\"40\" data-link=\"http://localhost:8080/carta/sandwich-cheddar/img_20190331_151226/\" class=\"wp-image-40\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://localhost:8080/wp-content/uploads/2019/04/empanadas-1024x576.jpg\" alt=\"\" data-id=\"36\" data-link=\"http://localhost:8080/carta/empanadas/empanadas/\" class=\"wp-image-36\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://localhost:8080/wp-content/uploads/2019/04/IMG_20190331_151243-1024x768.jpg\" alt=\"\" data-id=\"34\" data-link=\"http://localhost:8080/carta/tequenos/img_20190331_151243/\" class=\"wp-image-34\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://localhost:8080/wp-content/uploads/2019/04/IMG_20190330_142954-768x1024.jpg\" alt=\"\" data-id=\"25\" data-link=\"http://localhost:8080/2019/04/07/inauguracion/img_20190330_142954/\" class=\"wp-image-25\"/></figure></li></ul>\n<!-- /wp:gallery -->', 'Galeria de imágenes', '', 'trash', 'open', 'open', '', 'galeria-de-imagenes__trashed', '', '', '2019-04-13 21:42:51', '2019-04-14 00:42:51', '', 0, 'http://localhost:8080/?p=114', 0, 'post', '', 0);
INSERT INTO `kwa_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(115, 1, '2019-04-13 21:40:01', '2019-04-14 00:40:01', '<!-- wp:gallery {\"ids\":[74,50,49,48,42,44,46,47,38,40,36,34,25]} -->\n<ul class=\"wp-block-gallery columns-3 is-cropped\"><li class=\"blocks-gallery-item\"><figure><img src=\"http://localhost:8080/wp-content/uploads/2019/04/IMG-20190321-WA0012-678x1024.jpg\" alt=\"\" data-id=\"74\" data-link=\"http://localhost:8080/2019/04/10/nuestra-carta/img-20190321-wa0012/\" class=\"wp-image-74\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://localhost:8080/wp-content/uploads/2019/04/tequeños.jpg\" alt=\"\" data-id=\"50\" data-link=\"http://localhost:8080/carta/tequenos/tequenos-2/\" class=\"wp-image-50\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://localhost:8080/wp-content/uploads/2019/04/empanadas-1.jpg\" alt=\"\" data-id=\"49\" data-link=\"http://localhost:8080/carta/empanadas/empanadas-2/\" class=\"wp-image-49\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://localhost:8080/wp-content/uploads/2019/04/clubhouse-1.jpg\" alt=\"\" data-id=\"48\" data-link=\"http://localhost:8080/carta/club-house/clubhouse-2/\" class=\"wp-image-48\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://localhost:8080/wp-content/uploads/2019/04/cesar-1024x678.jpg\" alt=\"\" data-id=\"42\" data-link=\"http://localhost:8080/carta/ensaladas/cesar/\" class=\"wp-image-42\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://localhost:8080/wp-content/uploads/2019/04/golfeados-1024x1024.jpg\" alt=\"\" data-id=\"44\" data-link=\"http://localhost:8080/carta/golfeados/golfeados/\" class=\"wp-image-44\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://localhost:8080/wp-content/uploads/2019/04/cesar-1.jpg\" alt=\"\" data-id=\"46\" data-link=\"http://localhost:8080/carta/ensaladas/cesar-2/\" class=\"wp-image-46\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://localhost:8080/wp-content/uploads/2019/04/sandvege.jpg\" alt=\"\" data-id=\"47\" data-link=\"http://localhost:8080/carta/sandwich-cheddar/sandvege/\" class=\"wp-image-47\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://localhost:8080/wp-content/uploads/2019/04/clubhouse-1024x672.jpg\" alt=\"\" data-id=\"38\" data-link=\"http://localhost:8080/carta/club-house/clubhouse/\" class=\"wp-image-38\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://localhost:8080/wp-content/uploads/2019/04/IMG_20190331_151226-1024x768.jpg\" alt=\"\" data-id=\"40\" data-link=\"http://localhost:8080/carta/sandwich-cheddar/img_20190331_151226/\" class=\"wp-image-40\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://localhost:8080/wp-content/uploads/2019/04/empanadas-1024x576.jpg\" alt=\"\" data-id=\"36\" data-link=\"http://localhost:8080/carta/empanadas/empanadas/\" class=\"wp-image-36\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://localhost:8080/wp-content/uploads/2019/04/IMG_20190331_151243-1024x768.jpg\" alt=\"\" data-id=\"34\" data-link=\"http://localhost:8080/carta/tequenos/img_20190331_151243/\" class=\"wp-image-34\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://localhost:8080/wp-content/uploads/2019/04/IMG_20190330_142954-768x1024.jpg\" alt=\"\" data-id=\"25\" data-link=\"http://localhost:8080/2019/04/07/inauguracion/img_20190330_142954/\" class=\"wp-image-25\"/></figure></li></ul>\n<!-- /wp:gallery -->', 'Galeria de imágenes', '', 'inherit', 'closed', 'closed', '', '114-revision-v1', '', '', '2019-04-13 21:40:01', '2019-04-14 00:40:01', '', 114, 'http://localhost:8080/2019/04/13/114-revision-v1/', 0, 'revision', '', 0),
(116, 1, '2019-04-13 21:45:52', '2019-04-14 00:45:52', '[gallery link=\"none\" size=\"medium\" ids=\"50,49,48,45,46,47,40,36,34,25\"]', 'Galeria', '', 'publish', 'closed', 'closed', '', 'galeria', '', '', '2019-04-13 21:46:22', '2019-04-14 00:46:22', '', 0, 'http://localhost:8080/?post_type=imagenes&#038;p=116', 0, 'imagenes', '', 0),
(118, 1, '2019-04-13 22:08:48', '2019-04-14 01:08:48', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:4:\"page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:2:\"10\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Galeria', 'galeria', 'publish', 'closed', 'closed', '', 'group_5cb286d7d2f5c', '', '', '2019-04-13 22:10:23', '2019-04-14 01:10:23', '', 0, 'http://localhost:8080/?post_type=acf-field-group&#038;p=118', 0, 'acf-field-group', '', 0),
(119, 1, '2019-04-13 22:08:48', '2019-04-14 01:08:48', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";s:12:\"preview_size\";s:6:\"medium\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";i:200;s:10:\"min_height\";i:200;s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";i:400;s:10:\"max_height\";i:400;s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Galeria', 'galeria', 'publish', 'closed', 'closed', '', 'field_5cb287b8202e7', '', '', '2019-04-13 22:10:23', '2019-04-14 01:10:23', '', 118, 'http://localhost:8080/?post_type=acf-field&#038;p=119', 0, 'acf-field', '', 0),
(120, 1, '2019-04-13 22:10:43', '2019-04-14 01:10:43', '<!-- wp:paragraph -->\n<p>funciona como que no</p>\n<!-- /wp:paragraph -->', 'blog', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2019-04-13 22:10:43', '2019-04-14 01:10:43', '', 10, 'http://localhost:8080/2019/04/13/10-revision-v1/', 0, 'revision', '', 0),
(121, 1, '2019-04-13 22:26:24', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgVGh1bWJuYWlscyIsIm1vZHVsZV9pZCI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY19nYWxsZXJ5IiwiZW50aXR5X3R5cGVzIjpbImltYWdlIl0sInByZXZpZXdfaW1hZ2VfcmVscGF0aCI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY19nYWxsZXJ5I3RodW1iX3ByZXZpZXcuanBnIiwiZGVmYXVsdF9zb3VyY2UiOiJnYWxsZXJpZXMiLCJ2aWV3X29yZGVyIjoxMDAwMCwiYWxpYXNlcyI6WyJiYXNpY190aHVtYm5haWwiLCJiYXNpY190aHVtYm5haWxzIiwibmV4dGdlbl9iYXNpY190aHVtYm5haWxzIl0sIm5hbWUiOiJwaG90b2NyYXRpLW5leHRnZW5fYmFzaWNfdGh1bWJuYWlscyIsImluc3RhbGxlZF9hdF92ZXJzaW9uIjoiMy4xLjE3IiwiaWRfZmllbGQiOiJJRCIsInNldHRpbmdzIjp7InVzZV9saWdodGJveF9lZmZlY3QiOnRydWUsImRpc3BsYXlfdmlldyI6ImRlZmF1bHQtdmlldy5waHAiLCJpbWFnZXNfcGVyX3BhZ2UiOiIyNCIsIm51bWJlcl9vZl9jb2x1bW5zIjowLCJ0aHVtYm5haWxfd2lkdGgiOjI0MCwidGh1bWJuYWlsX2hlaWdodCI6MTYwLCJzaG93X2FsbF9pbl9saWdodGJveCI6MCwiYWpheF9wYWdpbmF0aW9uIjoxLCJ1c2VfaW1hZ2Vicm93c2VyX2VmZmVjdCI6MCwidGVtcGxhdGUiOiIiLCJkaXNwbGF5X25vX2ltYWdlc19lcnJvciI6MSwiZGlzYWJsZV9wYWdpbmF0aW9uIjowLCJzaG93X3NsaWRlc2hvd19saW5rIjowLCJzbGlkZXNob3dfbGlua190ZXh0IjoiVmlldyBTbGlkZXNob3ciLCJvdmVycmlkZV90aHVtYm5haWxfc2V0dGluZ3MiOjAsInRodW1ibmFpbF9xdWFsaXR5IjoiMTAwIiwidGh1bWJuYWlsX2Nyb3AiOjEsInRodW1ibmFpbF93YXRlcm1hcmsiOjAsIm5nZ190cmlnZ2Vyc19kaXNwbGF5IjoibmV2ZXIiLCJfZXJyb3JzIjpbXX0sImhpZGRlbl9mcm9tX3VpIjpmYWxzZSwiaGlkZGVuX2Zyb21faWd3IjpmYWxzZSwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'NextGEN Basic Thumbnails', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-04-13 22:26:24', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgVGh1bWJuYWlscyIsIm1vZHVsZV9pZCI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY19nYWxsZXJ5IiwiZW50aXR5X3R5cGVzIjpbImltYWdlIl0sInByZXZpZXdfaW1hZ2VfcmVscGF0aCI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY19nYWxsZXJ5I3RodW1iX3ByZXZpZXcuanBnIiwiZGVmYXVsdF9zb3VyY2UiOiJnYWxsZXJpZXMiLCJ2aWV3X29yZGVyIjoxMDAwMCwiYWxpYXNlcyI6WyJiYXNpY190aHVtYm5haWwiLCJiYXNpY190aHVtYm5haWxzIiwibmV4dGdlbl9iYXNpY190aHVtYm5haWxzIl0sIm5hbWUiOiJwaG90b2NyYXRpLW5leHRnZW5fYmFzaWNfdGh1bWJuYWlscyIsImluc3RhbGxlZF9hdF92ZXJzaW9uIjoiMy4xLjE3IiwiaWRfZmllbGQiOiJJRCIsInNldHRpbmdzIjp7InVzZV9saWdodGJveF9lZmZlY3QiOnRydWUsImRpc3BsYXlfdmlldyI6ImRlZmF1bHQtdmlldy5waHAiLCJpbWFnZXNfcGVyX3BhZ2UiOiIyNCIsIm51bWJlcl9vZl9jb2x1bW5zIjowLCJ0aHVtYm5haWxfd2lkdGgiOjI0MCwidGh1bWJuYWlsX2hlaWdodCI6MTYwLCJzaG93X2FsbF9pbl9saWdodGJveCI6MCwiYWpheF9wYWdpbmF0aW9uIjoxLCJ1c2VfaW1hZ2Vicm93c2VyX2VmZmVjdCI6MCwidGVtcGxhdGUiOiIiLCJkaXNwbGF5X25vX2ltYWdlc19lcnJvciI6MSwiZGlzYWJsZV9wYWdpbmF0aW9uIjowLCJzaG93X3NsaWRlc2hvd19saW5rIjowLCJzbGlkZXNob3dfbGlua190ZXh0IjoiVmlldyBTbGlkZXNob3ciLCJvdmVycmlkZV90aHVtYm5haWxfc2V0dGluZ3MiOjAsInRodW1ibmFpbF9xdWFsaXR5IjoiMTAwIiwidGh1bWJuYWlsX2Nyb3AiOjEsInRodW1ibmFpbF93YXRlcm1hcmsiOjAsIm5nZ190cmlnZ2Vyc19kaXNwbGF5IjoibmV2ZXIiLCJfZXJyb3JzIjpbXX0sImhpZGRlbl9mcm9tX3VpIjpmYWxzZSwiaGlkZGVuX2Zyb21faWd3IjpmYWxzZSwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://localhost:8080/?post_type=display_type&p=121', 0, 'display_type', '', 0),
(122, 1, '2019-04-13 22:26:24', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgU2xpZGVzaG93IiwibW9kdWxlX2lkIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX2dhbGxlcnkiLCJlbnRpdHlfdHlwZXMiOlsiaW1hZ2UiXSwicHJldmlld19pbWFnZV9yZWxwYXRoIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX2dhbGxlcnkjc2xpZGVzaG93X3ByZXZpZXcuanBnIiwiZGVmYXVsdF9zb3VyY2UiOiJnYWxsZXJpZXMiLCJ2aWV3X29yZGVyIjoxMDAxMCwiYWxpYXNlcyI6WyJiYXNpY19zbGlkZXNob3ciLCJuZXh0Z2VuX2Jhc2ljX3NsaWRlc2hvdyJdLCJuYW1lIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX3NsaWRlc2hvdyIsImluc3RhbGxlZF9hdF92ZXJzaW9uIjoiMy4xLjE3IiwiaWRfZmllbGQiOiJJRCIsInNldHRpbmdzIjp7InVzZV9saWdodGJveF9lZmZlY3QiOnRydWUsImdhbGxlcnlfd2lkdGgiOjc1MCwiZ2FsbGVyeV9oZWlnaHQiOjUwMCwic2hvd190aHVtYm5haWxfbGluayI6MCwidGh1bWJuYWlsX2xpbmtfdGV4dCI6IlZpZXcgVGh1bWJuYWlscyIsInRlbXBsYXRlIjoiIiwiZGlzcGxheV92aWV3IjoiZGVmYXVsdCIsImF1dG9wbGF5IjoxLCJwYXVzZW9uaG92ZXIiOjEsImFycm93cyI6MCwiaW50ZXJ2YWwiOjMwMDAsInRyYW5zaXRpb25fc3BlZWQiOjMwMCwidHJhbnNpdGlvbl9zdHlsZSI6ImZhZGUiLCJuZ2dfdHJpZ2dlcnNfZGlzcGxheSI6Im5ldmVyIiwiX2Vycm9ycyI6W119LCJoaWRkZW5fZnJvbV91aSI6ZmFsc2UsImhpZGRlbl9mcm9tX2lndyI6ZmFsc2UsIl9fZGVmYXVsdHNfc2V0Ijp0cnVlfQ==', 'NextGEN Basic Slideshow', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-04-13 22:26:24', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgU2xpZGVzaG93IiwibW9kdWxlX2lkIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX2dhbGxlcnkiLCJlbnRpdHlfdHlwZXMiOlsiaW1hZ2UiXSwicHJldmlld19pbWFnZV9yZWxwYXRoIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX2dhbGxlcnkjc2xpZGVzaG93X3ByZXZpZXcuanBnIiwiZGVmYXVsdF9zb3VyY2UiOiJnYWxsZXJpZXMiLCJ2aWV3X29yZGVyIjoxMDAxMCwiYWxpYXNlcyI6WyJiYXNpY19zbGlkZXNob3ciLCJuZXh0Z2VuX2Jhc2ljX3NsaWRlc2hvdyJdLCJuYW1lIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX3NsaWRlc2hvdyIsImluc3RhbGxlZF9hdF92ZXJzaW9uIjoiMy4xLjE3IiwiaWRfZmllbGQiOiJJRCIsInNldHRpbmdzIjp7InVzZV9saWdodGJveF9lZmZlY3QiOnRydWUsImdhbGxlcnlfd2lkdGgiOjc1MCwiZ2FsbGVyeV9oZWlnaHQiOjUwMCwic2hvd190aHVtYm5haWxfbGluayI6MCwidGh1bWJuYWlsX2xpbmtfdGV4dCI6IlZpZXcgVGh1bWJuYWlscyIsInRlbXBsYXRlIjoiIiwiZGlzcGxheV92aWV3IjoiZGVmYXVsdCIsImF1dG9wbGF5IjoxLCJwYXVzZW9uaG92ZXIiOjEsImFycm93cyI6MCwiaW50ZXJ2YWwiOjMwMDAsInRyYW5zaXRpb25fc3BlZWQiOjMwMCwidHJhbnNpdGlvbl9zdHlsZSI6ImZhZGUiLCJuZ2dfdHJpZ2dlcnNfZGlzcGxheSI6Im5ldmVyIiwiX2Vycm9ycyI6W119LCJoaWRkZW5fZnJvbV91aSI6ZmFsc2UsImhpZGRlbl9mcm9tX2lndyI6ZmFsc2UsIl9fZGVmYXVsdHNfc2V0Ijp0cnVlfQ==', 0, 'http://localhost:8080/?post_type=display_type&p=122', 0, 'display_type', '', 0),
(123, 1, '2019-04-13 22:26:24', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgSW1hZ2VCcm93c2VyIiwiZW50aXR5X3R5cGVzIjpbImltYWdlIl0sInByZXZpZXdfaW1hZ2VfcmVscGF0aCI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY19pbWFnZWJyb3dzZXIjcHJldmlldy5qcGciLCJkZWZhdWx0X3NvdXJjZSI6ImdhbGxlcmllcyIsInZpZXdfb3JkZXIiOjEwMDIwLCJhbGlhc2VzIjpbImJhc2ljX2ltYWdlYnJvd3NlciIsImltYWdlYnJvd3NlciIsIm5leHRnZW5fYmFzaWNfaW1hZ2Vicm93c2VyIl0sIm5hbWUiOiJwaG90b2NyYXRpLW5leHRnZW5fYmFzaWNfaW1hZ2Vicm93c2VyIiwiaW5zdGFsbGVkX2F0X3ZlcnNpb24iOiIzLjEuMTciLCJpZF9maWVsZCI6IklEIiwic2V0dGluZ3MiOnsidXNlX2xpZ2h0Ym94X2VmZmVjdCI6dHJ1ZSwiZGlzcGxheV92aWV3IjoiZGVmYXVsdC12aWV3LnBocCIsInRlbXBsYXRlIjoiIiwiYWpheF9wYWdpbmF0aW9uIjoiMSIsIm5nZ190cmlnZ2Vyc19kaXNwbGF5IjoibmV2ZXIiLCJfZXJyb3JzIjpbXX0sImhpZGRlbl9mcm9tX3VpIjpmYWxzZSwiaGlkZGVuX2Zyb21faWd3IjpmYWxzZSwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'NextGEN Basic ImageBrowser', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-04-13 22:26:24', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgSW1hZ2VCcm93c2VyIiwiZW50aXR5X3R5cGVzIjpbImltYWdlIl0sInByZXZpZXdfaW1hZ2VfcmVscGF0aCI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY19pbWFnZWJyb3dzZXIjcHJldmlldy5qcGciLCJkZWZhdWx0X3NvdXJjZSI6ImdhbGxlcmllcyIsInZpZXdfb3JkZXIiOjEwMDIwLCJhbGlhc2VzIjpbImJhc2ljX2ltYWdlYnJvd3NlciIsImltYWdlYnJvd3NlciIsIm5leHRnZW5fYmFzaWNfaW1hZ2Vicm93c2VyIl0sIm5hbWUiOiJwaG90b2NyYXRpLW5leHRnZW5fYmFzaWNfaW1hZ2Vicm93c2VyIiwiaW5zdGFsbGVkX2F0X3ZlcnNpb24iOiIzLjEuMTciLCJpZF9maWVsZCI6IklEIiwic2V0dGluZ3MiOnsidXNlX2xpZ2h0Ym94X2VmZmVjdCI6dHJ1ZSwiZGlzcGxheV92aWV3IjoiZGVmYXVsdC12aWV3LnBocCIsInRlbXBsYXRlIjoiIiwiYWpheF9wYWdpbmF0aW9uIjoiMSIsIm5nZ190cmlnZ2Vyc19kaXNwbGF5IjoibmV2ZXIiLCJfZXJyb3JzIjpbXX0sImhpZGRlbl9mcm9tX3VpIjpmYWxzZSwiaGlkZGVuX2Zyb21faWd3IjpmYWxzZSwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://localhost:8080/?post_type=display_type&p=123', 0, 'display_type', '', 0),
(124, 1, '2019-04-13 22:26:24', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgU2luZ2xlUGljIiwiZW50aXR5X3R5cGVzIjpbImltYWdlIl0sInByZXZpZXdfaW1hZ2VfcmVscGF0aCI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY19zaW5nbGVwaWMjcHJldmlldy5naWYiLCJkZWZhdWx0X3NvdXJjZSI6ImdhbGxlcmllcyIsInZpZXdfb3JkZXIiOjEwMDYwLCJoaWRkZW5fZnJvbV91aSI6dHJ1ZSwiaGlkZGVuX2Zyb21faWd3Ijp0cnVlLCJhbGlhc2VzIjpbImJhc2ljX3NpbmdsZXBpYyIsInNpbmdsZXBpYyIsIm5leHRnZW5fYmFzaWNfc2luZ2xlcGljIl0sIm5hbWUiOiJwaG90b2NyYXRpLW5leHRnZW5fYmFzaWNfc2luZ2xlcGljIiwiaW5zdGFsbGVkX2F0X3ZlcnNpb24iOiIzLjEuMTciLCJpZF9maWVsZCI6IklEIiwic2V0dGluZ3MiOnsidXNlX2xpZ2h0Ym94X2VmZmVjdCI6dHJ1ZSwid2lkdGgiOiIiLCJoZWlnaHQiOiIiLCJtb2RlIjoiIiwiZGlzcGxheV93YXRlcm1hcmsiOjAsImRpc3BsYXlfcmVmbGVjdGlvbiI6MCwiZmxvYXQiOiIiLCJsaW5rIjoiIiwibGlua190YXJnZXQiOiJfYmxhbmsiLCJxdWFsaXR5IjoxMDAsImNyb3AiOjAsInRlbXBsYXRlIjoiIiwibmdnX3RyaWdnZXJzX2Rpc3BsYXkiOiJuZXZlciIsIl9lcnJvcnMiOltdfSwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'NextGEN Basic SinglePic', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-04-13 22:26:24', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgU2luZ2xlUGljIiwiZW50aXR5X3R5cGVzIjpbImltYWdlIl0sInByZXZpZXdfaW1hZ2VfcmVscGF0aCI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY19zaW5nbGVwaWMjcHJldmlldy5naWYiLCJkZWZhdWx0X3NvdXJjZSI6ImdhbGxlcmllcyIsInZpZXdfb3JkZXIiOjEwMDYwLCJoaWRkZW5fZnJvbV91aSI6dHJ1ZSwiaGlkZGVuX2Zyb21faWd3Ijp0cnVlLCJhbGlhc2VzIjpbImJhc2ljX3NpbmdsZXBpYyIsInNpbmdsZXBpYyIsIm5leHRnZW5fYmFzaWNfc2luZ2xlcGljIl0sIm5hbWUiOiJwaG90b2NyYXRpLW5leHRnZW5fYmFzaWNfc2luZ2xlcGljIiwiaW5zdGFsbGVkX2F0X3ZlcnNpb24iOiIzLjEuMTciLCJpZF9maWVsZCI6IklEIiwic2V0dGluZ3MiOnsidXNlX2xpZ2h0Ym94X2VmZmVjdCI6dHJ1ZSwid2lkdGgiOiIiLCJoZWlnaHQiOiIiLCJtb2RlIjoiIiwiZGlzcGxheV93YXRlcm1hcmsiOjAsImRpc3BsYXlfcmVmbGVjdGlvbiI6MCwiZmxvYXQiOiIiLCJsaW5rIjoiIiwibGlua190YXJnZXQiOiJfYmxhbmsiLCJxdWFsaXR5IjoxMDAsImNyb3AiOjAsInRlbXBsYXRlIjoiIiwibmdnX3RyaWdnZXJzX2Rpc3BsYXkiOiJuZXZlciIsIl9lcnJvcnMiOltdfSwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://localhost:8080/?post_type=display_type&p=124', 0, 'display_type', '', 0),
(125, 1, '2019-04-13 22:26:24', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgVGFnQ2xvdWQiLCJlbnRpdHlfdHlwZXMiOlsiaW1hZ2UiXSwicHJldmlld19pbWFnZV9yZWxwYXRoIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX3RhZ2Nsb3VkI3ByZXZpZXcuZ2lmIiwiZGVmYXVsdF9zb3VyY2UiOiJ0YWdzIiwidmlld19vcmRlciI6MTAxMDAsImFsaWFzZXMiOlsiYmFzaWNfdGFnY2xvdWQiLCJ0YWdjbG91ZCIsIm5leHRnZW5fYmFzaWNfdGFnY2xvdWQiXSwibmFtZSI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY190YWdjbG91ZCIsImluc3RhbGxlZF9hdF92ZXJzaW9uIjoiMy4xLjE3IiwiaWRfZmllbGQiOiJJRCIsInNldHRpbmdzIjp7InVzZV9saWdodGJveF9lZmZlY3QiOnRydWUsImdhbGxlcnlfZGlzcGxheV90eXBlIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX3RodW1ibmFpbHMiLCJudW1iZXIiOjQ1LCJuZ2dfdHJpZ2dlcnNfZGlzcGxheSI6Im5ldmVyIiwiX2Vycm9ycyI6W119LCJoaWRkZW5fZnJvbV91aSI6ZmFsc2UsImhpZGRlbl9mcm9tX2lndyI6ZmFsc2UsIl9fZGVmYXVsdHNfc2V0Ijp0cnVlfQ==', 'NextGEN Basic TagCloud', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-04-13 22:26:24', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgVGFnQ2xvdWQiLCJlbnRpdHlfdHlwZXMiOlsiaW1hZ2UiXSwicHJldmlld19pbWFnZV9yZWxwYXRoIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX3RhZ2Nsb3VkI3ByZXZpZXcuZ2lmIiwiZGVmYXVsdF9zb3VyY2UiOiJ0YWdzIiwidmlld19vcmRlciI6MTAxMDAsImFsaWFzZXMiOlsiYmFzaWNfdGFnY2xvdWQiLCJ0YWdjbG91ZCIsIm5leHRnZW5fYmFzaWNfdGFnY2xvdWQiXSwibmFtZSI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY190YWdjbG91ZCIsImluc3RhbGxlZF9hdF92ZXJzaW9uIjoiMy4xLjE3IiwiaWRfZmllbGQiOiJJRCIsInNldHRpbmdzIjp7InVzZV9saWdodGJveF9lZmZlY3QiOnRydWUsImdhbGxlcnlfZGlzcGxheV90eXBlIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX3RodW1ibmFpbHMiLCJudW1iZXIiOjQ1LCJuZ2dfdHJpZ2dlcnNfZGlzcGxheSI6Im5ldmVyIiwiX2Vycm9ycyI6W119LCJoaWRkZW5fZnJvbV91aSI6ZmFsc2UsImhpZGRlbl9mcm9tX2lndyI6ZmFsc2UsIl9fZGVmYXVsdHNfc2V0Ijp0cnVlfQ==', 0, 'http://localhost:8080/?post_type=display_type&p=125', 0, 'display_type', '', 0),
(126, 1, '2019-04-13 22:26:24', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgQ29tcGFjdCBBbGJ1bSIsIm1vZHVsZV9pZCI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY19hbGJ1bSIsImVudGl0eV90eXBlcyI6WyJhbGJ1bSIsImdhbGxlcnkiXSwicHJldmlld19pbWFnZV9yZWxwYXRoIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX2FsYnVtI2NvbXBhY3RfcHJldmlldy5qcGciLCJkZWZhdWx0X3NvdXJjZSI6ImFsYnVtcyIsInZpZXdfb3JkZXIiOjEwMjAwLCJhbGlhc2VzIjpbImJhc2ljX2NvbXBhY3RfYWxidW0iLCJuZXh0Z2VuX2Jhc2ljX2FsYnVtIiwiYmFzaWNfYWxidW1fY29tcGFjdCIsImNvbXBhY3RfYWxidW0iXSwibmFtZSI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY19jb21wYWN0X2FsYnVtIiwiaW5zdGFsbGVkX2F0X3ZlcnNpb24iOiIzLjEuMTciLCJpZF9maWVsZCI6IklEIiwic2V0dGluZ3MiOnsidXNlX2xpZ2h0Ym94X2VmZmVjdCI6dHJ1ZSwiZGlzcGxheV92aWV3IjoiZGVmYXVsdC12aWV3LnBocCIsImdhbGxlcmllc19wZXJfcGFnZSI6MCwiZW5hYmxlX2JyZWFkY3J1bWJzIjoxLCJkaXNhYmxlX3BhZ2luYXRpb24iOjAsImVuYWJsZV9kZXNjcmlwdGlvbnMiOjAsInRlbXBsYXRlIjoiIiwib3Blbl9nYWxsZXJ5X2luX2xpZ2h0Ym94IjowLCJvdmVycmlkZV90aHVtYm5haWxfc2V0dGluZ3MiOjEsInRodW1ibmFpbF9xdWFsaXR5IjoxMDAsInRodW1ibmFpbF9jcm9wIjoxLCJ0aHVtYm5haWxfd2F0ZXJtYXJrIjowLCJ0aHVtYm5haWxfd2lkdGgiOjI0MCwidGh1bWJuYWlsX2hlaWdodCI6MTYwLCJnYWxsZXJ5X2Rpc3BsYXlfdHlwZSI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY190aHVtYm5haWxzIiwiZ2FsbGVyeV9kaXNwbGF5X3RlbXBsYXRlIjoiIiwibmdnX3RyaWdnZXJzX2Rpc3BsYXkiOiJuZXZlciIsIl9lcnJvcnMiOltdfSwiaGlkZGVuX2Zyb21fdWkiOmZhbHNlLCJoaWRkZW5fZnJvbV9pZ3ciOmZhbHNlLCJfX2RlZmF1bHRzX3NldCI6dHJ1ZX0=', 'NextGEN Basic Compact Album', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-04-13 22:26:24', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgQ29tcGFjdCBBbGJ1bSIsIm1vZHVsZV9pZCI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY19hbGJ1bSIsImVudGl0eV90eXBlcyI6WyJhbGJ1bSIsImdhbGxlcnkiXSwicHJldmlld19pbWFnZV9yZWxwYXRoIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX2FsYnVtI2NvbXBhY3RfcHJldmlldy5qcGciLCJkZWZhdWx0X3NvdXJjZSI6ImFsYnVtcyIsInZpZXdfb3JkZXIiOjEwMjAwLCJhbGlhc2VzIjpbImJhc2ljX2NvbXBhY3RfYWxidW0iLCJuZXh0Z2VuX2Jhc2ljX2FsYnVtIiwiYmFzaWNfYWxidW1fY29tcGFjdCIsImNvbXBhY3RfYWxidW0iXSwibmFtZSI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY19jb21wYWN0X2FsYnVtIiwiaW5zdGFsbGVkX2F0X3ZlcnNpb24iOiIzLjEuMTciLCJpZF9maWVsZCI6IklEIiwic2V0dGluZ3MiOnsidXNlX2xpZ2h0Ym94X2VmZmVjdCI6dHJ1ZSwiZGlzcGxheV92aWV3IjoiZGVmYXVsdC12aWV3LnBocCIsImdhbGxlcmllc19wZXJfcGFnZSI6MCwiZW5hYmxlX2JyZWFkY3J1bWJzIjoxLCJkaXNhYmxlX3BhZ2luYXRpb24iOjAsImVuYWJsZV9kZXNjcmlwdGlvbnMiOjAsInRlbXBsYXRlIjoiIiwib3Blbl9nYWxsZXJ5X2luX2xpZ2h0Ym94IjowLCJvdmVycmlkZV90aHVtYm5haWxfc2V0dGluZ3MiOjEsInRodW1ibmFpbF9xdWFsaXR5IjoxMDAsInRodW1ibmFpbF9jcm9wIjoxLCJ0aHVtYm5haWxfd2F0ZXJtYXJrIjowLCJ0aHVtYm5haWxfd2lkdGgiOjI0MCwidGh1bWJuYWlsX2hlaWdodCI6MTYwLCJnYWxsZXJ5X2Rpc3BsYXlfdHlwZSI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY190aHVtYm5haWxzIiwiZ2FsbGVyeV9kaXNwbGF5X3RlbXBsYXRlIjoiIiwibmdnX3RyaWdnZXJzX2Rpc3BsYXkiOiJuZXZlciIsIl9lcnJvcnMiOltdfSwiaGlkZGVuX2Zyb21fdWkiOmZhbHNlLCJoaWRkZW5fZnJvbV9pZ3ciOmZhbHNlLCJfX2RlZmF1bHRzX3NldCI6dHJ1ZX0=', 0, 'http://localhost:8080/?post_type=display_type&p=126', 0, 'display_type', '', 0),
(127, 1, '2019-04-13 22:26:24', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgRXh0ZW5kZWQgQWxidW0iLCJtb2R1bGVfaWQiOiJwaG90b2NyYXRpLW5leHRnZW5fYmFzaWNfYWxidW0iLCJlbnRpdHlfdHlwZXMiOlsiYWxidW0iLCJnYWxsZXJ5Il0sInByZXZpZXdfaW1hZ2VfcmVscGF0aCI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY19hbGJ1bSNleHRlbmRlZF9wcmV2aWV3LmpwZyIsImRlZmF1bHRfc291cmNlIjoiYWxidW1zIiwidmlld19vcmRlciI6MTAyMTAsImFsaWFzZXMiOlsiYmFzaWNfZXh0ZW5kZWRfYWxidW0iLCJuZXh0Z2VuX2Jhc2ljX2V4dGVuZGVkX2FsYnVtIiwiZXh0ZW5kZWRfYWxidW0iXSwibmFtZSI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY19leHRlbmRlZF9hbGJ1bSIsImluc3RhbGxlZF9hdF92ZXJzaW9uIjoiMy4xLjE3IiwiaWRfZmllbGQiOiJJRCIsInNldHRpbmdzIjp7InVzZV9saWdodGJveF9lZmZlY3QiOnRydWUsImRpc3BsYXlfdmlldyI6ImRlZmF1bHQtdmlldy5waHAiLCJnYWxsZXJpZXNfcGVyX3BhZ2UiOjAsImVuYWJsZV9icmVhZGNydW1icyI6MSwiZGlzYWJsZV9wYWdpbmF0aW9uIjowLCJlbmFibGVfZGVzY3JpcHRpb25zIjowLCJ0ZW1wbGF0ZSI6IiIsIm9wZW5fZ2FsbGVyeV9pbl9saWdodGJveCI6MCwib3ZlcnJpZGVfdGh1bWJuYWlsX3NldHRpbmdzIjoxLCJ0aHVtYm5haWxfcXVhbGl0eSI6MTAwLCJ0aHVtYm5haWxfY3JvcCI6MSwidGh1bWJuYWlsX3dhdGVybWFyayI6MCwidGh1bWJuYWlsX3dpZHRoIjozMDAsInRodW1ibmFpbF9oZWlnaHQiOjIwMCwiZ2FsbGVyeV9kaXNwbGF5X3R5cGUiOiJwaG90b2NyYXRpLW5leHRnZW5fYmFzaWNfdGh1bWJuYWlscyIsImdhbGxlcnlfZGlzcGxheV90ZW1wbGF0ZSI6IiIsIm5nZ190cmlnZ2Vyc19kaXNwbGF5IjoibmV2ZXIiLCJfZXJyb3JzIjpbXX0sImhpZGRlbl9mcm9tX3VpIjpmYWxzZSwiaGlkZGVuX2Zyb21faWd3IjpmYWxzZSwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'NextGEN Basic Extended Album', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-04-13 22:26:24', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgRXh0ZW5kZWQgQWxidW0iLCJtb2R1bGVfaWQiOiJwaG90b2NyYXRpLW5leHRnZW5fYmFzaWNfYWxidW0iLCJlbnRpdHlfdHlwZXMiOlsiYWxidW0iLCJnYWxsZXJ5Il0sInByZXZpZXdfaW1hZ2VfcmVscGF0aCI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY19hbGJ1bSNleHRlbmRlZF9wcmV2aWV3LmpwZyIsImRlZmF1bHRfc291cmNlIjoiYWxidW1zIiwidmlld19vcmRlciI6MTAyMTAsImFsaWFzZXMiOlsiYmFzaWNfZXh0ZW5kZWRfYWxidW0iLCJuZXh0Z2VuX2Jhc2ljX2V4dGVuZGVkX2FsYnVtIiwiZXh0ZW5kZWRfYWxidW0iXSwibmFtZSI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY19leHRlbmRlZF9hbGJ1bSIsImluc3RhbGxlZF9hdF92ZXJzaW9uIjoiMy4xLjE3IiwiaWRfZmllbGQiOiJJRCIsInNldHRpbmdzIjp7InVzZV9saWdodGJveF9lZmZlY3QiOnRydWUsImRpc3BsYXlfdmlldyI6ImRlZmF1bHQtdmlldy5waHAiLCJnYWxsZXJpZXNfcGVyX3BhZ2UiOjAsImVuYWJsZV9icmVhZGNydW1icyI6MSwiZGlzYWJsZV9wYWdpbmF0aW9uIjowLCJlbmFibGVfZGVzY3JpcHRpb25zIjowLCJ0ZW1wbGF0ZSI6IiIsIm9wZW5fZ2FsbGVyeV9pbl9saWdodGJveCI6MCwib3ZlcnJpZGVfdGh1bWJuYWlsX3NldHRpbmdzIjoxLCJ0aHVtYm5haWxfcXVhbGl0eSI6MTAwLCJ0aHVtYm5haWxfY3JvcCI6MSwidGh1bWJuYWlsX3dhdGVybWFyayI6MCwidGh1bWJuYWlsX3dpZHRoIjozMDAsInRodW1ibmFpbF9oZWlnaHQiOjIwMCwiZ2FsbGVyeV9kaXNwbGF5X3R5cGUiOiJwaG90b2NyYXRpLW5leHRnZW5fYmFzaWNfdGh1bWJuYWlscyIsImdhbGxlcnlfZGlzcGxheV90ZW1wbGF0ZSI6IiIsIm5nZ190cmlnZ2Vyc19kaXNwbGF5IjoibmV2ZXIiLCJfZXJyb3JzIjpbXX0sImhpZGRlbl9mcm9tX3VpIjpmYWxzZSwiaGlkZGVuX2Zyb21faWd3IjpmYWxzZSwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://localhost:8080/?post_type=display_type&p=127', 0, 'display_type', '', 0),
(129, 1, '2019-04-14 15:17:28', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'Untitled ngg_gallery', '', 'draft', 'closed', 'closed', '', 'mixin_nextgen_table_extras', '', '', '2019-04-14 15:17:28', '2019-04-14 18:17:28', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://localhost:8080/?p=129', 0, 'ngg_gallery', '', 0),
(130, 1, '2019-04-14 15:17:28', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'Untitled ngg_pictures', '', 'draft', 'closed', 'closed', '', 'mixin_nextgen_table_extras', '', '', '2019-04-14 15:17:28', '2019-04-14 18:17:28', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://localhost:8080/?p=130', 0, 'ngg_pictures', '', 0),
(131, 1, '2019-04-14 15:17:28', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'Untitled ngg_pictures', '', 'draft', 'closed', 'closed', '', 'mixin_nextgen_table_extras', '', '', '2019-04-14 15:17:28', '2019-04-14 18:17:28', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://localhost:8080/?p=131', 0, 'ngg_pictures', '', 0),
(132, 1, '2019-04-14 15:17:28', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'Untitled ngg_pictures', '', 'draft', 'closed', 'closed', '', 'mixin_nextgen_table_extras', '', '', '2019-04-14 15:17:28', '2019-04-14 18:17:28', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://localhost:8080/?p=132', 0, 'ngg_pictures', '', 0),
(133, 1, '2019-04-14 15:17:28', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'Untitled ngg_pictures', '', 'draft', 'closed', 'closed', '', 'mixin_nextgen_table_extras', '', '', '2019-04-14 15:17:28', '2019-04-14 18:17:28', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://localhost:8080/?p=133', 0, 'ngg_pictures', '', 0),
(134, 1, '2019-04-14 15:17:28', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'Untitled ngg_pictures', '', 'draft', 'closed', 'closed', '', 'mixin_nextgen_table_extras', '', '', '2019-04-14 15:17:28', '2019-04-14 18:17:28', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://localhost:8080/?p=134', 0, 'ngg_pictures', '', 0),
(135, 1, '2019-04-14 15:17:28', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'Untitled ngg_pictures', '', 'draft', 'closed', 'closed', '', 'mixin_nextgen_table_extras', '', '', '2019-04-14 15:17:28', '2019-04-14 18:17:28', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://localhost:8080/?p=135', 0, 'ngg_pictures', '', 0),
(136, 1, '2019-04-14 15:17:28', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'Untitled ngg_pictures', '', 'draft', 'closed', 'closed', '', 'mixin_nextgen_table_extras', '', '', '2019-04-14 15:17:28', '2019-04-14 18:17:28', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://localhost:8080/?p=136', 0, 'ngg_pictures', '', 0),
(137, 1, '2019-04-14 15:17:28', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'Untitled ngg_pictures', '', 'draft', 'closed', 'closed', '', 'mixin_nextgen_table_extras', '', '', '2019-04-14 15:17:28', '2019-04-14 18:17:28', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://localhost:8080/?p=137', 0, 'ngg_pictures', '', 0),
(138, 1, '2019-04-14 15:17:28', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'Untitled ngg_pictures', '', 'draft', 'closed', 'closed', '', 'mixin_nextgen_table_extras', '', '', '2019-04-14 15:17:28', '2019-04-14 18:17:28', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://localhost:8080/?p=138', 0, 'ngg_pictures', '', 0),
(139, 1, '2019-04-13 22:41:44', '2019-04-14 01:41:44', '<!-- wp:paragraph -->\n<p>funciona como que no</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:imagely/nextgen-gallery -->\n[ngg src=\"galleries\" display=\"basic_thumbnail\" images_per_page=\"10\"]\n<!-- /wp:imagely/nextgen-gallery -->', 'blog', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2019-04-13 22:41:44', '2019-04-14 01:41:44', '', 10, 'http://localhost:8080/2019/04/13/10-revision-v1/', 0, 'revision', '', 0),
(140, 1, '2019-04-13 22:42:39', '2019-04-14 01:42:39', '<!-- wp:paragraph -->\n<p>funciona como que no</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:imagely/nextgen-gallery -->\n[ngg src=\"galleries\" display=\"basic_thumbnail\" images_per_page=\"10\"]\n<!-- /wp:imagely/nextgen-gallery -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'blog', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2019-04-13 22:42:39', '2019-04-14 01:42:39', '', 10, 'http://localhost:8080/2019/04/13/10-revision-v1/', 0, 'revision', '', 0),
(142, 1, '2019-04-13 22:44:29', '2019-04-14 01:44:29', '<!-- wp:imagely/nextgen-gallery -->\n[ngg src=\"galleries\" display=\"basic_thumbnail\" images_per_page=\"10\"]\n<!-- /wp:imagely/nextgen-gallery -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'blog', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2019-04-13 22:44:29', '2019-04-14 01:44:29', '', 10, 'http://localhost:8080/2019/04/13/10-revision-v1/', 0, 'revision', '', 0),
(144, 1, '2019-04-13 23:38:47', '2019-04-14 02:38:47', '[ngg src=\"galleries\" ids=\"1\" display=\"basic_thumbnail\"]', 'Borrador automático', '', 'publish', 'closed', 'closed', '', 'borrador-automatico', '', '', '2019-04-13 23:44:29', '2019-04-14 02:44:29', '', 0, 'http://localhost:8080/?post_type=galeria&#038;p=144', 0, 'galeria', '', 0),
(145, 1, '2019-04-14 15:17:28', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'Untitled ngg_pictures', '', 'draft', 'closed', 'closed', '', 'mixin_nextgen_table_extras', '', '', '2019-04-14 15:17:28', '2019-04-14 18:17:28', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://localhost:8080/?p=145', 0, 'ngg_pictures', '', 0),
(146, 1, '2019-04-14 15:17:28', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'Untitled ngg_pictures', '', 'draft', 'closed', 'closed', '', 'mixin_nextgen_table_extras', '', '', '2019-04-14 15:17:28', '2019-04-14 18:17:28', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://localhost:8080/?p=146', 0, 'ngg_pictures', '', 0),
(154, 1, '2019-04-14 16:55:35', '2019-04-14 19:55:35', '<!-- wp:paragraph -->\n<p>Esta es una página de ejemplo. Es diferente de una entrada de blog porque se quedará en ese lugar y se mostrará en la navegación de tu sitio (en la mayoría de los temas). La mayoría de la gente comienza con una página de acerca de que los introduce a los visitantes potenciales del sitio. Podría decir algo como esto:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>¡Hola! Soy un Mensajero en bici durante el día, aspirante a actor de noche, y este es mi sitio Web. Vivo en los Ángeles, tengo un gran perro llamado Jack, y me gustan las piñas coladas. (Y estar atrapados en la lluvia.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>... o algo así:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>La Empresa Cosas XYZ fue fundada en 1971, y ha estado proporcionando cosas de calidad al público desde entonces. Ubicado en la ciudad de Gotham, XYZ emplea a más de 2.000 personas y hace todo tipo de cosas impresionantes para la comunidad gótica.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Como nuevo usuario de WordPress, debes ir a <a href=\"http://localhost:8080/wp-admin/\">tu Dashboard</a> para eliminar esta página, y así crear nuevas páginas para su contenido. ¡Que te diviertas!</p>\n<!-- /wp:paragraph -->', 'Página de ejemplo', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2019-04-14 16:55:35', '2019-04-14 19:55:35', '', 2, 'http://localhost:8080/2019/04/14/2-revision-v1/', 0, 'revision', '', 0),
(155, 1, '2019-04-14 16:55:35', '2019-04-14 19:55:35', '<!-- wp:heading --><h2>Quiénes somos</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Nuestra dirección de sitio web es: http://localhost:8080.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Qué datos personales recopilamos y por qué lo recogemos</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Comentarios</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Cuando los visitantes dejan comentarios en el sitio recopilamos los datos mostrados en el formulario de comentarios, y también la dirección IP del visitante y la cadena del agente de usuario del navegador para ayudar a la detección de spam.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Se puede proporcionar una cadena anonimizada creada a partir de su dirección de correo electrónico (también denominada hash) al servicio gravatar para ver si la está utilizando. La política de privacidad del servicio gravar está disponible aquí: https://automattic.com/privacy/. Después de la aprobación de tu comentario, su imagen de perfil es visible para el público en el contexto de tu comentario.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Multimedia</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Si subes imágenes al sitio web, debes evitar cargar imágenes con datos de ubicación incrustados (EXIF GPS). Los visitantes del sitio web pueden descargar y extraer los datos de la ubicación de las imágenes en el sitio Web.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Formularios de Contacto</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Cookies</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Si deja un Comentario en nuestro sitio puedes optar por guardar tu nombre, dirección de correo electrónico y sitio web en cookies. Éstos son para tu conveniencia de modo que no tengas que rellenar tus datos otra vez cuando dejes otro comentario. Estas cookies durarán un año.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Si tienes una cuenta e inicias sesión en este sitio, configuraremos una cookie temporal para determinar si tu navegador acepta cookies. Esta cookie no contiene datos personales y se descarta al cerrar el navegador.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Cuando inicies sesión, también configuraremos varias cookies para guardar tu información de inicio de sesión y sus opciones de visualización en pantalla. Las cookies de inicio de sesión duran dos días y las cookies de opciones de pantalla duran un año. Si selecciona &quot;Recordarme&quot; en tu inicio de sesión se mantendrá durante dos semanas. Si cierra la sesión de tu cuenta, se eliminarán las cookies de inicio de sesión.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Si editas o publicas un artículo, una cookie adicional se guardará en tu navegador. Esta cookie no incluye datos personales y simplemente indica el ID de correo del artículo que acabas de editar. Expira después de 1 día.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Contenido incrustado de otros sitios web</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Los artículos en este sitio pueden incluir contenido incrustado (por ejemplo, videos, imágenes, artículos, etc.). El contenido incrustado de otros sitios web se comporta de la misma manera que si el visitante hubiera visitado el otro sitio web.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Estos sitios web pueden recopilar datos sobre ti, utilizar cookies, incrustar un seguimiento adicional de terceros y supervisar tu interacción con ese contenido incrustado, incluido el seguimiento de tu interacción con el contenido incrustado si tiene una cuenta y está conectado a dicho sitio web.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Analíticas</h3><!-- /wp:heading --><!-- wp:heading --><h2>Con quién compartimos tus datos</h2><!-- /wp:heading --><!-- wp:heading --><h2>Cuánto tiempo conservamos tus datos</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Si dejas un comentario, el comentario y sus metadatos se conservan indefinidamente. Esto es para que podamos reconocer y aprobar automáticamente cualquier comentario de seguimiento en lugar de mantenerlos en una cola de moderación.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Para los usuarios que se registren en nuestro sitio web (si los hay), también almacenamos la información personal que proporcionan en su perfil de usuario. Todos los usuarios pueden ver, editar o borrar su información personal en cualquier momento (excepto que no pueden cambiar su nombre de usuario). Los administradores de sitios web también pueden ver y editar esa información.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Qué derechos tienen sobre sus datos</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Si tienes una cuenta en este sitio, o ha dejado comentarios, puedes solicitar recibir un archivo exportado de los datos personales que tengamos sobre usted, incluyendo cualquier dato que nos haya proporcionado. También puede solicitar que borremos cualquier dato personal que mantengamos sobre usted. Esto no incluye los datos que estamos obligados a mantener para fines administrativos, legales o de seguridad.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Dónde enviamos tus datos</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Los comentarios de los visitantes se pueden verificar a través de un servicio automático de detección de spam.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Tu información de contacto</h2><!-- /wp:heading --><!-- wp:heading --><h2>Información adicional</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Cómo protegemos sus datos</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Qué procedimientos de violación de datos tenemos en marcha</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>De qué terceros recibimos datos</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Qué toma de decisiones y/o perfiles automatizados haremos con los datos del usuario</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Requisitos de divulgación regulatoria de la industria</h3><!-- /wp:heading -->', 'Políticas de Privacidad', '', 'inherit', 'closed', 'closed', '', '3-revision-v1', '', '', '2019-04-14 16:55:35', '2019-04-14 19:55:35', '', 3, 'http://localhost:8080/2019/04/14/3-revision-v1/', 0, 'revision', '', 0),
(156, 1, '2019-04-14 16:59:13', '2019-04-14 19:59:13', '<form>\r\n  <div class=\"form-group\">\r\n	<label for=\"exampleFormControlInput1\">Email o Apodo:</label>\r\n	<input type=\"email\" class=\"form-control\" id=\"exampleFormControlInput1\" placeholder=\"name@example.com\">\r\n  </div>\r\n  <div class=\"form-group\">\r\n	 <label for=\"exampleFormControlTextarea1\">Escribe tu experiencia o recomendación:</label>\r\n	<textarea class=\"form-control\" id=\"exampleFormControlTextarea1\" rows=\"5\"></textarea>\r\n  </div>\r\n  <div class=\"form-group\">\r\n	<label for=\"exampleFormControlFile1\">Adjunta imagen:</label>\r\n	<input type=\"file\" class=\"form-control-file\" id=\"exampleFormControlFile1\">\r\n  </div>\r\n  <div class=\"recentco\">\r\n     <h1>Comentarios recientes</h1>\r\n     <button type=\"button\" id=\"boton\" class=\"btn btn-dark\">Publicar</button>\r\n	<br><br>\r\n	<table class=\"table table-striped table-hover\" id=\"tabla\">\r\n	<tr>\r\n	<th>Título</th>\r\n	<th>Contenido</th>\r\n	</tr>\r\n </table>\r\n</div>\r\n</form>\n1\nKWAfood \"[your-subject]\"\nKWAfood <nada@nada.cl>\nnada@nada.cl\nFrom: [your-name] <[your-email]>\r\nSubject: [your-subject]\r\n\r\nMessage Body:\r\n[your-message]\r\n\r\n-- \r\nThis e-mail was sent from a contact form on KWAfood (http://localhost:8080)\n\n\n\n\n\nKWAfood \"[your-subject]\"\nKWAfood <nada@nada.cl>\n[your-email]\nMessage Body:\r\n[your-message]\r\n\r\n-- \r\nThis e-mail was sent from a contact form on KWAfood (http://localhost:8080)\nReply-To: nada@nada.cl\n\n\n\nThank you for your message. It has been sent.\nThere was an error trying to send your message. Please try again later.\nOne or more fields have an error. Please check and try again.\nThere was an error trying to send your message. Please try again later.\nYou must accept the terms and conditions before sending your message.\nThe field is required.\nThe field is too long.\nThe field is too short.\nThe date format is incorrect.\nThe date is before the earliest one allowed.\nThe date is after the latest one allowed.\nThere was an unknown error uploading the file.\nYou are not allowed to upload files of this type.\nThe file is too big.\nThere was an error uploading the file.\nThe number format is invalid.\nThe number is smaller than the minimum allowed.\nThe number is larger than the maximum allowed.\nThe answer to the quiz is incorrect.\nYour entered code is incorrect.\nThe e-mail address entered is invalid.\nThe URL is invalid.\nThe telephone number is invalid.', 'Contact form 1', '', 'publish', 'closed', 'closed', '', 'contact-form-1', '', '', '2019-04-14 17:50:54', '2019-04-14 20:50:54', '', 0, 'http://localhost:8080/?post_type=wpcf7_contact_form&#038;p=156', 0, 'wpcf7_contact_form', '', 0),
(157, 1, '2019-04-14 17:55:07', '2019-04-14 20:55:07', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:4:\"post\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Con', 'con', 'trash', 'closed', 'closed', '', 'group_5cb39e22c9b51__trashed', '', '', '2019-04-14 17:55:15', '2019-04-14 20:55:15', '', 0, 'http://localhost:8080/?post_type=acf-field-group&#038;p=157', 0, 'acf-field-group', '', 0),
(158, 1, '2019-04-14 17:55:39', '2019-04-14 20:55:39', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'contacto_shortcode', 'contacto_shortcode', 'publish', 'closed', 'closed', '', 'field_5cb39e430b4c4', '', '', '2019-04-14 17:56:03', '2019-04-14 20:56:03', '', 52, 'http://localhost:8080/?post_type=acf-field&#038;p=158', 2, 'acf-field', '', 0),
(159, 1, '2019-04-14 17:56:33', '2019-04-14 20:56:33', '', 'home', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2019-04-14 17:56:33', '2019-04-14 20:56:33', '', 20, 'http://localhost:8080/2019/04/14/20-revision-v1/', 0, 'revision', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `kwa_termmeta`
--

CREATE TABLE `kwa_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `kwa_terms`
--

CREATE TABLE `kwa_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `kwa_terms`
--

INSERT INTO `kwa_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Sin categoría', 'sin-categoria', 0),
(2, 'Restaurante', 'restaurante', 0),
(3, 'Comida', 'comida', 0),
(4, 'Venezuela', 'venezuela', 0),
(5, 'Comida', 'comida', 0),
(6, 'venezolana', 'venezolana', 0),
(7, 'sabores', 'sabores', 0),
(8, 'restaurante', 'restaurante', 0),
(9, 'mi_menu', 'mi_menu', 0);

-- --------------------------------------------------------

--
-- Table structure for table `kwa_term_relationships`
--

CREATE TABLE `kwa_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `kwa_term_relationships`
--

INSERT INTO `kwa_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(24, 3, 0),
(24, 4, 0),
(24, 5, 0),
(24, 6, 0),
(24, 7, 0),
(24, 8, 0),
(27, 9, 0),
(28, 9, 0),
(29, 9, 0),
(30, 9, 0),
(32, 9, 0),
(73, 1, 0),
(83, 1, 0),
(112, 1, 0),
(114, 1, 0),
(116, 2, 0),
(116, 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `kwa_term_taxonomy`
--

CREATE TABLE `kwa_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `kwa_term_taxonomy`
--

INSERT INTO `kwa_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 2),
(2, 2, 'category', '', 0, 1),
(3, 3, 'category', '', 0, 2),
(4, 4, 'category', '', 0, 1),
(5, 5, 'post_tag', '', 0, 1),
(6, 6, 'post_tag', '', 0, 1),
(7, 7, 'post_tag', '', 0, 1),
(8, 8, 'post_tag', '', 0, 1),
(9, 9, 'nav_menu', '', 0, 5);

-- --------------------------------------------------------

--
-- Table structure for table `kwa_usermeta`
--

CREATE TABLE `kwa_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `kwa_usermeta`
--

INSERT INTO `kwa_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'KWAfood'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'false'),
(11, 1, 'locale', ''),
(12, 1, 'kwa_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(13, 1, 'kwa_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'wp496_privacy'),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:2:{s:64:\"1b849d48588f252a33a09f76e46fcff4a9e37b89d3e48d35bab20538941f4e7a\";a:4:{s:10:\"expiration\";i:1555368475;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:119:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_2) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/12.0.2 Safari/605.1.15\";s:5:\"login\";i:1555195675;}s:64:\"e0840c501858456e16a77e00542e51faf282e3b6b539ef53edc0f8f6776af97b\";a:4:{s:10:\"expiration\";i:1555438501;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:119:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_2) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/12.0.2 Safari/605.1.15\";s:5:\"login\";i:1555265701;}}'),
(17, 1, 'kwa_user-settings', 'libraryContent=browse&editor=tinymce&hidetb=0&editor_expand=on'),
(18, 1, 'kwa_user-settings-time', '1555203345'),
(19, 1, 'kwa_dashboard_quick_press_last_post_id', '5'),
(20, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'),
(21, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:\"add-post_tag\";}'),
(22, 1, 'nav_menu_recently_edited', '9'),
(23, 1, 'closedpostboxes_page', 'a:1:{i:0;s:23:\"acf-group_5cb286d7d2f5c\";}'),
(24, 1, 'metaboxhidden_page', 'a:0:{}'),
(25, 1, 'closedpostboxes_imagenes', 'a:0:{}'),
(26, 1, 'metaboxhidden_imagenes', 'a:1:{i:0;s:7:\"slugdiv\";}'),
(27, 1, 'plugins_per_page', '999');

-- --------------------------------------------------------

--
-- Table structure for table `kwa_users`
--

CREATE TABLE `kwa_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `kwa_users`
--

INSERT INTO `kwa_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'KWAfood', '$P$BUuOVNhrHaJrna39Y95Kite4YLjA4J0', 'kwafood', 'nada@nada.cl', '', '2019-03-25 23:42:34', '', 0, 'KWAfood');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kwa_commentmeta`
--
ALTER TABLE `kwa_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `kwa_comments`
--
ALTER TABLE `kwa_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Indexes for table `kwa_links`
--
ALTER TABLE `kwa_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `kwa_ngg_album`
--
ALTER TABLE `kwa_ngg_album`
  ADD PRIMARY KEY (`id`),
  ADD KEY `extras_post_id_key` (`extras_post_id`);

--
-- Indexes for table `kwa_ngg_gallery`
--
ALTER TABLE `kwa_ngg_gallery`
  ADD PRIMARY KEY (`gid`),
  ADD KEY `extras_post_id_key` (`extras_post_id`);

--
-- Indexes for table `kwa_ngg_pictures`
--
ALTER TABLE `kwa_ngg_pictures`
  ADD PRIMARY KEY (`pid`),
  ADD KEY `extras_post_id_key` (`extras_post_id`);

--
-- Indexes for table `kwa_options`
--
ALTER TABLE `kwa_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`);

--
-- Indexes for table `kwa_postmeta`
--
ALTER TABLE `kwa_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `kwa_posts`
--
ALTER TABLE `kwa_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `kwa_termmeta`
--
ALTER TABLE `kwa_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `kwa_terms`
--
ALTER TABLE `kwa_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indexes for table `kwa_term_relationships`
--
ALTER TABLE `kwa_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `kwa_term_taxonomy`
--
ALTER TABLE `kwa_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `kwa_usermeta`
--
ALTER TABLE `kwa_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `kwa_users`
--
ALTER TABLE `kwa_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kwa_commentmeta`
--
ALTER TABLE `kwa_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `kwa_comments`
--
ALTER TABLE `kwa_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `kwa_links`
--
ALTER TABLE `kwa_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `kwa_ngg_album`
--
ALTER TABLE `kwa_ngg_album`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `kwa_ngg_gallery`
--
ALTER TABLE `kwa_ngg_gallery`
  MODIFY `gid` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `kwa_ngg_pictures`
--
ALTER TABLE `kwa_ngg_pictures`
  MODIFY `pid` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `kwa_options`
--
ALTER TABLE `kwa_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=563;

--
-- AUTO_INCREMENT for table `kwa_postmeta`
--
ALTER TABLE `kwa_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1002;

--
-- AUTO_INCREMENT for table `kwa_posts`
--
ALTER TABLE `kwa_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=160;

--
-- AUTO_INCREMENT for table `kwa_termmeta`
--
ALTER TABLE `kwa_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `kwa_terms`
--
ALTER TABLE `kwa_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `kwa_term_taxonomy`
--
ALTER TABLE `kwa_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `kwa_usermeta`
--
ALTER TABLE `kwa_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `kwa_users`
--
ALTER TABLE `kwa_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
